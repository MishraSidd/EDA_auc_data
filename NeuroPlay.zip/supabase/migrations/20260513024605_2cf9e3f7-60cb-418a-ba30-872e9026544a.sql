CREATE TABLE public.speech_sessions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id TEXT NOT NULL,
  words_attempted INTEGER NOT NULL DEFAULT 0,
  avg_score INTEGER NOT NULL DEFAULT 0,
  session_date DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.speech_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "speech_sessions public read"
ON public.speech_sessions FOR SELECT
USING (true);

CREATE POLICY "speech_sessions public insert"
ON public.speech_sessions FOR INSERT
WITH CHECK (user_id IS NOT NULL AND length(user_id) > 0);
