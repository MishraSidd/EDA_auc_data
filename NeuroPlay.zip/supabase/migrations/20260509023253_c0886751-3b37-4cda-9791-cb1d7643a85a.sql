-- Speech Recovery Tracker: attempts log
CREATE TABLE public.speech_attempts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  session_id TEXT NOT NULL,
  word TEXT NOT NULL,
  spoken_text TEXT NOT NULL DEFAULT '',
  score INTEGER NOT NULL CHECK (score >= 0 AND score <= 100),
  difficulty TEXT NOT NULL DEFAULT 'easy',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_speech_attempts_session ON public.speech_attempts(session_id);
CREATE INDEX idx_speech_attempts_created  ON public.speech_attempts(created_at DESC);
CREATE INDEX idx_speech_attempts_word     ON public.speech_attempts(word);

ALTER TABLE public.speech_attempts ENABLE ROW LEVEL SECURITY;

-- Public read so progress/leaderboard style views work without auth
CREATE POLICY "speech_attempts public read"
  ON public.speech_attempts FOR SELECT
  USING (true);

-- Anyone can insert an attempt (anonymous practice)
CREATE POLICY "speech_attempts public insert"
  ON public.speech_attempts FOR INSERT
  WITH CHECK (session_id IS NOT NULL AND length(session_id) > 0);

-- No update/delete policies => denied by default (immutable log)
