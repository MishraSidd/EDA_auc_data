
CREATE TABLE public.assessments (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id text NOT NULL,
  questionnaire jsonb NOT NULL DEFAULT '{}'::jsonb,
  motor_stability integer NOT NULL DEFAULT 0,
  cognitive_focus integer NOT NULL DEFAULT 0,
  communication_confidence integer NOT NULL DEFAULT 0,
  fatigue_sensitivity integer NOT NULL DEFAULT 0,
  memory_index integer NOT NULL DEFAULT 0,
  adaptation_level integer NOT NULL DEFAULT 0,
  tremor_smoothness numeric NOT NULL DEFAULT 0,
  tremor_deviation numeric NOT NULL DEFAULT 0,
  tremor_velocity_var numeric NOT NULL DEFAULT 0,
  adaptive_profile jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.assessments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "assessments public read"
  ON public.assessments FOR SELECT
  USING (true);

CREATE POLICY "assessments public insert"
  ON public.assessments FOR INSERT
  WITH CHECK (user_id IS NOT NULL AND length(user_id) > 0);

CREATE INDEX idx_assessments_user_created ON public.assessments(user_id, created_at DESC);
