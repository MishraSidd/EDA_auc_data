
ALTER TABLE public.game_sessions
  ADD COLUMN IF NOT EXISTS game_name text,
  ADD COLUMN IF NOT EXISTS errors integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS accuracy_percent numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS duration_seconds integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS level_reached text,
  ADD COLUMN IF NOT EXISTS session_data jsonb NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE public.mood_logs
  ADD COLUMN IF NOT EXISTS mood_score integer;

CREATE TABLE IF NOT EXISTS public.task_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  task_name text NOT NULL,
  was_completed boolean NOT NULL DEFAULT true,
  completed_at timestamptz NOT NULL DEFAULT now(),
  delay_minutes numeric NOT NULL DEFAULT 0,
  scheduled_time text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.task_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "task_logs public read"
  ON public.task_logs FOR SELECT
  USING (true);

CREATE POLICY "task_logs public insert"
  ON public.task_logs FOR INSERT
  WITH CHECK (user_id IS NOT NULL AND length(user_id) > 0);
