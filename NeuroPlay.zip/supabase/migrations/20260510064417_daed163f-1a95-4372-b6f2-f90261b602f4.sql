
-- game_sessions
CREATE TABLE public.game_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  game text NOT NULL,
  difficulty text,
  score integer NOT NULL DEFAULT 0,
  accuracy numeric NOT NULL DEFAULT 0,
  duration_sec integer NOT NULL DEFAULT 0,
  rounds_total integer NOT NULL DEFAULT 0,
  rounds_correct integer NOT NULL DEFAULT 0,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  played_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.game_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "game_sessions public read" ON public.game_sessions FOR SELECT USING (true);
CREATE POLICY "game_sessions public insert" ON public.game_sessions FOR INSERT WITH CHECK (user_id IS NOT NULL AND length(user_id) > 0);

-- mood_logs
CREATE TABLE public.mood_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  mood_value integer NOT NULL,
  mood_label text NOT NULL,
  note text,
  logged_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.mood_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "mood_logs public read" ON public.mood_logs FOR SELECT USING (true);
CREATE POLICY "mood_logs public insert" ON public.mood_logs FOR INSERT WITH CHECK (user_id IS NOT NULL AND length(user_id) > 0);

-- daily_tasks
CREATE TABLE public.daily_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  title text NOT NULL,
  scheduled_for date NOT NULL,
  scheduled_time text,
  completed boolean NOT NULL DEFAULT false,
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.daily_tasks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "daily_tasks public read" ON public.daily_tasks FOR SELECT USING (true);
CREATE POLICY "daily_tasks public insert" ON public.daily_tasks FOR INSERT WITH CHECK (user_id IS NOT NULL AND length(user_id) > 0);

-- weekly_reports
CREATE TABLE public.weekly_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  week_start date NOT NULL,
  week_end date NOT NULL,
  sessions_played integer NOT NULL DEFAULT 0,
  avg_score numeric NOT NULL DEFAULT 0,
  avg_accuracy numeric NOT NULL DEFAULT 0,
  avg_mood numeric NOT NULL DEFAULT 0,
  tasks_completed integer NOT NULL DEFAULT 0,
  tasks_total integer NOT NULL DEFAULT 0,
  highlights text,
  trend text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.weekly_reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "weekly_reports public read" ON public.weekly_reports FOR SELECT USING (true);
CREATE POLICY "weekly_reports public insert" ON public.weekly_reports FOR INSERT WITH CHECK (user_id IS NOT NULL AND length(user_id) > 0);
