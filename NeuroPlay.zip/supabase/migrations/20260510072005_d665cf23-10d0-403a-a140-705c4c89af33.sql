
-- Mood: shift from 0-4 to 1-5
UPDATE public.mood_logs SET mood_value = mood_value + 1 WHERE user_id='demo-mary' AND mood_value < 5;

-- Normalize all game scores to accuracy (0-100)
UPDATE public.game_sessions SET score = accuracy::int WHERE user_id='demo-mary';

-- Speech Recovery: keep only the latest session
DELETE FROM public.game_sessions WHERE user_id='demo-mary' AND game='speech_recovery' AND id NOT IN (
  SELECT id FROM public.game_sessions WHERE user_id='demo-mary' AND game='speech_recovery' ORDER BY played_at DESC LIMIT 1
);

-- Memory game task: drop completion to ~43% (keep 3/7 completed)
UPDATE public.daily_tasks SET completed=false, completed_at=NULL
  WHERE user_id='demo-mary' AND title='Complete memory game'
    AND scheduled_for IN ('2026-05-07','2026-05-08','2026-05-09','2026-05-10');
