import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { encode as base64Encode } from "https://deno.land/std@0.168.0/encoding/base64.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const PRESETS: Record<string, { prompt: string; bpm: number }> = {
  upbeat: {
    prompt:
      "Cheerful upbeat 8-bit chiptune platformer game music, light percussion, major key, friendly and playful, 100 BPM, instrumental, looping",
    bpm: 100,
  },
  calm: {
    prompt:
      "Calm gentle lo-fi piano with soft synth pads, relaxing therapeutic background music, slow steady beat, 80 BPM, instrumental, soothing",
    bpm: 80,
  },
  classical: {
    prompt:
      "Light cheerful classical piano piece in major key, baroque style, steady tempo, instrumental, 110 BPM, uplifting",
    bpm: 110,
  },
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { preset = "upbeat", duration = 45 } = await req.json().catch(() => ({}));
    const config = PRESETS[preset] ?? PRESETS.upbeat;

    const apiKey = Deno.env.get("ELEVENLABS_API_KEY");
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: "ELEVENLABS_API_KEY is not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const resp = await fetch("https://api.elevenlabs.io/v1/music", {
      method: "POST",
      headers: {
        "xi-api-key": apiKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        prompt: config.prompt,
        music_length_ms: Math.round(duration * 1000),
      }),
    });

    if (!resp.ok) {
      const errText = await resp.text();
      console.error("ElevenLabs error", resp.status, errText);
      return new Response(
        JSON.stringify({ error: `Music generation failed (${resp.status})`, detail: errText }),
        { status: resp.status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const audioBuffer = await resp.arrayBuffer();
    const audioBase64 = base64Encode(audioBuffer);

    return new Response(
      JSON.stringify({
        audioContent: audioBase64,
        bpm: config.bpm,
        preset,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (e) {
    console.error("generate-music error", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});