// Edge function: compute Jaro-Winkler + Levenshtein blended pronunciation score.
// Mirrors the Python scoring.py spec from the Speech Recovery Tracker brief.
import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";

function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  const v0 = new Array(b.length + 1);
  const v1 = new Array(b.length + 1);
  for (let i = 0; i <= b.length; i++) v0[i] = i;
  for (let i = 0; i < a.length; i++) {
    v1[0] = i + 1;
    for (let j = 0; j < b.length; j++) {
      const cost = a[i] === b[j] ? 0 : 1;
      v1[j + 1] = Math.min(v1[j] + 1, v0[j + 1] + 1, v0[j] + cost);
    }
    for (let j = 0; j <= b.length; j++) v0[j] = v1[j];
  }
  return v1[b.length];
}

function jaro(s1: string, s2: string): number {
  if (s1 === s2) return 1;
  const len1 = s1.length, len2 = s2.length;
  if (!len1 || !len2) return 0;
  const matchDistance = Math.max(0, Math.floor(Math.max(len1, len2) / 2) - 1);
  const s1Matches = new Array(len1).fill(false);
  const s2Matches = new Array(len2).fill(false);
  let matches = 0;
  for (let i = 0; i < len1; i++) {
    const start = Math.max(0, i - matchDistance);
    const end = Math.min(i + matchDistance + 1, len2);
    for (let j = start; j < end; j++) {
      if (s2Matches[j]) continue;
      if (s1[i] !== s2[j]) continue;
      s1Matches[i] = true;
      s2Matches[j] = true;
      matches++;
      break;
    }
  }
  if (!matches) return 0;
  let k = 0, transpositions = 0;
  for (let i = 0; i < len1; i++) {
    if (!s1Matches[i]) continue;
    while (!s2Matches[k]) k++;
    if (s1[i] !== s2[k]) transpositions++;
    k++;
  }
  return (matches / len1 + matches / len2 + (matches - transpositions / 2) / matches) / 3;
}

function jaroWinkler(s1: string, s2: string, p = 0.1): number {
  const j = jaro(s1, s2);
  let l = 0;
  while (l < 4 && l < Math.min(s1.length, s2.length) && s1[l] === s2[l]) l++;
  return j + l * p * (1 - j);
}

function computeScore(target: string, spoken: string): number {
  const t = target.toLowerCase().trim();
  const s = spoken.toLowerCase().trim();
  if (!t || !s) return 0;
  if (t === s) return 100;
  const jw = jaroWinkler(t, s);
  const lev = 1 - levenshtein(t, s) / Math.max(t.length, s.length);
  const blended = Math.round((jw * 0.6 + lev * 0.4) * 100);
  return Math.max(0, Math.min(100, blended));
}

function getFeedback(score: number): string {
  if (score >= 90) return "Excellent pronunciation!";
  if (score >= 75) return "Great job — almost perfect!";
  if (score >= 60) return "Good effort — try once more";
  if (score >= 40) return "Getting closer — keep going";
  return "Let's try again — you can do it";
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const body = await req.json();
    const target = String(body?.target ?? "");
    const spoken = String(body?.spoken ?? "");
    if (!target) {
      return new Response(JSON.stringify({ error: "target is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const score = computeScore(target, spoken);
    return new Response(
      JSON.stringify({ score, feedback: getFeedback(score) }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});