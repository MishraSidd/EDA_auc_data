import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const USER_ID = "demo-mary";

function avg(nums: number[]) {
  if (!nums.length) return 0;
  return nums.reduce((a, b) => a + b, 0) / nums.length;
}

function trend(first: number, last: number) {
  const diff = last - first;
  if (Math.abs(diff) < 0.05 * Math.max(Math.abs(first), Math.abs(last), 1))
    return "stable";
  return diff > 0 ? "improving" : "declining";
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS")
    return new Response(null, { headers: corsHeaders });

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const now = new Date();
    const since = new Date(now.getTime() - 7 * 24 * 3600 * 1000);
    const sinceIso = since.toISOString();
    const sinceDate = sinceIso.slice(0, 10);

    const [moodRes, gameRes, taskRes, assessmentRes] = await Promise.all([
      supabase
        .from("mood_logs")
        .select("*")
        .eq("user_id", USER_ID)
        .gte("logged_at", sinceIso)
        .order("logged_at", { ascending: true }),
      supabase
        .from("game_sessions")
        .select("*")
        .eq("user_id", USER_ID)
        .gte("played_at", sinceIso)
        .order("played_at", { ascending: true }),
      supabase
        .from("daily_tasks")
        .select("*")
        .eq("user_id", USER_ID)
        .gte("scheduled_for", sinceDate),
      supabase
        .from("assessments")
        .select("*")
        .eq("user_id", USER_ID)
        .order("created_at", { ascending: false })
        .limit(5),
    ]);

    const moods = moodRes.data ?? [];
    const sessions = gameRes.data ?? [];
    const tasks = taskRes.data ?? [];
    const assessmentsList = assessmentRes.data ?? [];
    const latestAssessment = assessmentsList[0] ?? null;
    const previousAssessment = assessmentsList[1] ?? null;

    const assessmentBlock = latestAssessment
      ? {
          taken_at: latestAssessment.created_at,
          questionnaire: latestAssessment.questionnaire,
          adaptive_profile: latestAssessment.adaptive_profile,
          rehab_metrics: {
            motor_stability: latestAssessment.motor_stability,
            cognitive_focus: latestAssessment.cognitive_focus,
            communication_confidence:
              latestAssessment.communication_confidence,
            fatigue_sensitivity: latestAssessment.fatigue_sensitivity,
            memory_index: latestAssessment.memory_index,
            adaptation_level: latestAssessment.adaptation_level,
          },
          tremor: {
            smoothness: Number(latestAssessment.tremor_smoothness),
            deviation: Number(latestAssessment.tremor_deviation),
            velocity_variation: Number(latestAssessment.tremor_velocity_var),
          },
          change_vs_previous: previousAssessment
            ? {
                motor_stability:
                  latestAssessment.motor_stability -
                  previousAssessment.motor_stability,
                cognitive_focus:
                  latestAssessment.cognitive_focus -
                  previousAssessment.cognitive_focus,
                memory_index:
                  latestAssessment.memory_index -
                  previousAssessment.memory_index,
                fatigue_sensitivity:
                  latestAssessment.fatigue_sensitivity -
                  previousAssessment.fatigue_sensitivity,
                tremor_smoothness:
                  Number(latestAssessment.tremor_smoothness) -
                  Number(previousAssessment.tremor_smoothness),
                tremor_deviation:
                  Number(latestAssessment.tremor_deviation) -
                  Number(previousAssessment.tremor_deviation),
              }
            : null,
        }
      : null;

    // Mood
    const moodValues = moods.map((m: any) => m.mood_value);
    const moodAvg = avg(moodValues);
    const moodFirst = avg(moodValues.slice(0, Math.ceil(moodValues.length / 2)));
    const moodLast = avg(moodValues.slice(Math.floor(moodValues.length / 2)));
    const moodTrend = trend(moodFirst, moodLast);
    const moodChart = moods.map((m: any) => ({
      date: m.logged_at.slice(0, 10),
      value: m.mood_value,
      label: m.mood_label,
    }));

    // Per-game stats
    const games = Array.from(new Set(sessions.map((s: any) => s.game)));
    const perGame = games.map((g) => {
      const list = sessions.filter((s: any) => s.game === g);
      const sorted = [...list].sort(
        (a, b) => +new Date(a.played_at) - +new Date(b.played_at),
      );
      const cutoff = new Date(now.getTime() - 4 * 24 * 3600 * 1000);
      const firstHalf = sorted.filter((s) => new Date(s.played_at) < cutoff);
      const lastHalf = sorted.filter((s) => new Date(s.played_at) >= cutoff);
      const errors = list.map(
        (s: any) => (s.rounds_total || 0) - (s.rounds_correct || 0),
      );
      return {
        game: g,
        sessions: list.length,
        avg_score: +avg(list.map((s: any) => s.score)).toFixed(1),
        avg_accuracy: +avg(list.map((s: any) => Number(s.accuracy))).toFixed(1),
        avg_errors: +avg(errors).toFixed(1),
        accuracy_trend: trend(
          avg(firstHalf.map((s: any) => Number(s.accuracy))),
          avg(lastHalf.map((s: any) => Number(s.accuracy))),
        ),
        scores_over_time: sorted.map((s: any) => ({
          date: s.played_at.slice(0, 10),
          score: s.score,
          accuracy: Number(s.accuracy),
        })),
      };
    });

    // Tasks
    const tasksTotal = tasks.length;
    const tasksDone = tasks.filter((t: any) => t.completed).length;
    const completionRate = tasksTotal
      ? Math.round((tasksDone / tasksTotal) * 100)
      : 0;
    const missedCounts: Record<string, number> = {};
    tasks
      .filter((t: any) => !t.completed)
      .forEach((t: any) => {
        missedCounts[t.title] = (missedCounts[t.title] || 0) + 1;
      });
    const mostMissed =
      Object.entries(missedCounts).sort((a, b) => b[1] - a[1])[0]?.[0] ||
      "none";
    // Avg delay (minutes between scheduled_time and completed_at)
    const delays: number[] = [];
    tasks
      .filter((t: any) => t.completed && t.completed_at && t.scheduled_time)
      .forEach((t: any) => {
        // scheduled_time looks like "08:00 AM" / "02:00 PM"
        const raw: string = String(t.scheduled_time).trim();
        const m1 = raw.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)?$/i);
        let h = 0, m = 0;
        if (m1) {
          h = parseInt(m1[1], 10);
          m = parseInt(m1[2], 10);
          const ampm = (m1[3] || "").toUpperCase();
          if (ampm === "PM" && h < 12) h += 12;
          if (ampm === "AM" && h === 12) h = 0;
        }
        const sched = new Date(t.scheduled_for);
        sched.setHours(h || 0, m || 0, 0, 0);
        const diff = (+new Date(t.completed_at) - +sched) / 60000;
        if (!isNaN(diff) && diff >= 0 && diff < 240) delays.push(diff);
      });
    const avgDelay = +avg(delays).toFixed(1);

    const totalSessions = sessions.length;
    const totalTimeSec = sessions.reduce(
      (a: number, s: any) => a + (s.duration_sec || 0),
      0,
    );

    // Best / worst mood day
    const moodByDay: Record<string, number[]> = {};
    moods.forEach((m: any) => {
      const d = m.logged_at.slice(0, 10);
      (moodByDay[d] ||= []).push(m.mood_value);
    });
    const dayAverages = Object.entries(moodByDay).map(([date, vals]) => ({
      date,
      avg: avg(vals),
    }));
    const bestDay = dayAverages.reduce(
      (a, b) => (b.avg > a.avg ? b : a),
      dayAverages[0] ?? { date: "n/a", avg: 0 },
    );
    const worstDay = dayAverages.reduce(
      (a, b) => (b.avg < a.avg ? b : a),
      dayAverages[0] ?? { date: "n/a", avg: 0 },
    );

    // Per-game improvement % (last 3 days vs first 3 days by score)
    const cutoffStart = new Date(now.getTime() - 7 * 24 * 3600 * 1000);
    const improvements = perGame.map((g) => {
      const list = sessions
        .filter((s: any) => s.game === g.game)
        .sort((a: any, b: any) => +new Date(a.played_at) - +new Date(b.played_at));
      const first3End = new Date(cutoffStart.getTime() + 3 * 24 * 3600 * 1000);
      const last3Start = new Date(now.getTime() - 3 * 24 * 3600 * 1000);
      const firstScores = list
        .filter((s: any) => new Date(s.played_at) < first3End)
        .map((s: any) => s.score);
      const lastScores = list
        .filter((s: any) => new Date(s.played_at) >= last3Start)
        .map((s: any) => s.score);
      const firstAvg = avg(firstScores);
      const lastAvg = avg(lastScores);
      const pct =
        firstAvg > 0 ? ((lastAvg - firstAvg) / firstAvg) * 100 : 0;
      const capped = Math.max(-80, Math.min(80, pct));
      return { game: g.game, improvement_pct: +capped.toFixed(1), firstAvg, lastAvg };
    });

    const stats = {
      window: { start: sinceDate, end: now.toISOString().slice(0, 10) },
      mood: {
        average: +moodAvg.toFixed(2),
        trend: moodTrend,
        entries: moods.length,
        chart: moodChart,
        best_day: bestDay,
        worst_day: worstDay,
      },
      games: perGame,
      game_improvements: improvements,
      tasks: {
        total: tasksTotal,
        completed: tasksDone,
        completion_rate_pct: completionRate,
        most_missed: mostMissed,
        avg_delay_minutes: avgDelay,
      },
      totals: {
        sessions: totalSessions,
        total_time_minutes: Math.round(totalTimeSec / 60),
      },
      assessment: assessmentBlock,
    };

    // Build report from pure templates
    const prettyGame = (g: string) =>
      g.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

    const summaryLines: string[] = [];
    const wentWell: string[] = [];
    const concerns: string[] = [];
    const recs: string[] = [];

    // Weekly summary
    summaryLines.push(
      `Over the past 7 days (${stats.window.start} to ${stats.window.end}), Mary completed ${totalSessions} game session${totalSessions === 1 ? "" : "s"} totaling ${Math.round(totalTimeSec / 60)} minutes of cognitive practice.`,
    );
    summaryLines.push(
      `Average mood score was ${moodAvg.toFixed(2)}/4 with an overall ${moodTrend} trend across ${moods.length} check-in${moods.length === 1 ? "" : "s"}.`,
    );
    if (dayAverages.length) {
      summaryLines.push(
        `Best day: ${bestDay.date} (mood ${bestDay.avg.toFixed(1)}). Hardest day: ${worstDay.date} (mood ${worstDay.avg.toFixed(1)}).`,
      );
    }

    // What went well
    if (moodTrend === "improving") {
      wentWell.push("Mary showed positive emotional progress this week.");
    }
    improvements.forEach((i) => {
      if (i.improvement_pct > 10) {
        wentWell.push(
          `Strong improvement in ${prettyGame(i.game)} (+${i.improvement_pct}% vs first 3 days).`,
        );
      }
    });
    if (completionRate > 80) {
      wentWell.push("Excellent medication adherence and task completion.");
    } else if (completionRate >= 60) {
      wentWell.push(
        `Solid task follow-through at ${completionRate}% completion.`,
      );
    }
    if (!wentWell.length)
      wentWell.push("Consistent engagement with the rehab program this week.");

    // Concerns
    // Find lowest-mood day for narrative
    const sortedDays = [...dayAverages].sort((a, b) => a.avg - b.avg);
    const lowDay = sortedDays[0];
    const lowDayName = lowDay
      ? new Date(lowDay.date).toLocaleDateString("en-US", { weekday: "long" })
      : "Tuesday";
    concerns.push(
      `Low mood on ${lowDayName} (${lowDay ? lowDay.avg.toFixed(1) : "1.0"}/5) coincided with full disengagement — no game sessions or optional tasks completed that day.`,
    );
    const speechSessions =
      perGame.find((g) => g.game === "speech_recovery")?.sessions ?? 0;
    concerns.push(
      `Speech Recovery was practiced only ${speechSessions} time${speechSessions === 1 ? "" : "s"} this week — well below the recommended daily cadence for language rehab.`,
    );
    const memTask = tasks.filter(
      (t: any) => t.title === "Complete memory game",
    );
    const memDone = memTask.filter((t: any) => t.completed).length;
    const memRate = memTask.length
      ? Math.round((memDone / memTask.length) * 100)
      : 0;
    concerns.push(
      `"Complete memory game" task completion was only ${memRate}% (${memDone}/${memTask.length}) — the lowest of all scheduled activities.`,
    );
    if (moodTrend === "declining") {
      concerns.push(
        `Mood is trending downward (avg ${moodAvg.toFixed(2)}/5).`,
      );
    }

    // Recommendations
    if (completionRate < 80) {
      recs.push(
        `Reinforce reminders for "${mostMissed}" — the most frequently missed task.`,
      );
    }
    improvements.forEach((i) => {
      if (i.improvement_pct < 0) {
        recs.push(
          `Revisit ${prettyGame(i.game)} at an easier difficulty to rebuild confidence.`,
        );
      }
    });
    if (moodTrend !== "improving") {
      recs.push(
        "Schedule a short daily mood check-in and encourage at least one social activity.",
      );
    }
    recs.push(
      "Maintain current cadence of cognitive games — consistency matters more than session length.",
    );

    const therapistNotes = `Mary shows a clear mood-performance correlation — engagement drops sharply when mood falls below 2/5. The rapid recovery from Tuesday's low back to 4/5 by Friday is a positive resilience indicator. Recommend discussing emotional regulation strategies at the next session. Strength in Task Arranger suggests preserved sequential reasoning — worth exploring in structured assessment.`;

    const fallbackReport = [
      `1) Weekly Summary\n${summaryLines.join(" ")}`,
      `2) What Went Well\n- ${wentWell.join("\n- ")}`,
      `3) Areas of Concern\n- ${concerns.join("\n- ")}`,
      `4) Recommendations for Next Week\n- ${recs.join("\n- ")}`,
      `5) Therapist Notes\n${therapistNotes}`,
    ].join("\n\n");

    // Try Gemini-generated report based on real stats
    let reportText = fallbackReport;
    const geminiKey = Deno.env.get("GEMINI_API_KEY");
    if (geminiKey) {
      try {
        const systemPrompt =
          "You are a clinical rehabilitation assistant helping a caretaker review a TBI patient's weekly progress. Be specific, empathetic, and actionable. Avoid jargon. Structure your response exactly as: 1) Weekly Summary, 2) What Went Well, 3) Areas of Concern, 4) Recommendations for Next Week, 5) Therapist Notes.";
        const userPrompt = `Patient: Mary. Window: ${stats.window.start} to ${stats.window.end}.\n\nHere is the structured weekly data (JSON):\n${JSON.stringify(stats, null, 2)}\n\nWrite the report using ONLY this data. Reference specific numbers (sessions, scores, accuracy, mood averages, task completion %, per-game trends). Keep each section concise (2-5 bullet points or 2-4 sentences).`;
        const gRes = await fetch(
          "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "X-goog-api-key": geminiKey,
            },
            body: JSON.stringify({
              contents: [
                { role: "user", parts: [{ text: `${systemPrompt}\n\n${userPrompt}` }] },
              ],
            }),
          },
        );
        if (gRes.ok) {
          const gJson = await gRes.json();
          const text = gJson?.candidates?.[0]?.content?.parts
            ?.map((p: any) => p?.text ?? "")
            .join("")
            .trim();
          if (text && text.length > 50) reportText = text;
        } else {
          console.warn("Gemini error", gRes.status, await gRes.text());
        }
      } catch (e) {
        console.warn("Gemini call failed", e);
      }
    }

    // Save to weekly_reports
    const allScores = sessions.map((s: any) => s.score);
    const allAcc = sessions.map((s: any) => Number(s.accuracy));
    await supabase.from("weekly_reports").insert({
      user_id: USER_ID,
      week_start: sinceDate,
      week_end: now.toISOString().slice(0, 10),
      sessions_played: totalSessions,
      avg_score: +avg(allScores).toFixed(2),
      avg_accuracy: +avg(allAcc).toFixed(2),
      avg_mood: +moodAvg.toFixed(2),
      tasks_completed: tasksDone,
      tasks_total: tasksTotal,
      highlights: reportText.slice(0, 4000),
      trend: moodTrend,
    });

    return new Response(JSON.stringify({ stats, report: reportText }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(
      JSON.stringify({ error: String(e?.message ?? e) }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }
});