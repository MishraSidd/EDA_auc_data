// Lightweight in-browser audio analysis for the Echo Surfer game.
// - decodes an audio file/url
// - runs a simple spectral-flux onset detector
// - classifies each onset into one of 4 frequency bins (buttons 1-4)

export interface Onset {
  time: number; // seconds
  button: 0 | 1 | 2 | 3; // 0 = low ... 3 = high
}

export interface AnalysisResult {
  onsets: Onset[];
  duration: number;
  envelope: Float32Array;
  buttonPitches: number[]; // 4 entries, Hz; NaN if no data
  audioBuffer: AudioBuffer;
}

const FFT_SIZE = 1024;
const HOP = 512;

export async function analyseAudio(source: ArrayBuffer | string): Promise<AnalysisResult> {
  const buf = typeof source === "string" ? await (await fetch(source)).arrayBuffer() : source;
  const Ctx = window.OfflineAudioContext || (window as any).webkitOfflineAudioContext;
  // First decode with a temp realtime ctx (offline ctx requires known sr — we use 44.1k)
  const tmp = new (window.AudioContext || (window as any).webkitAudioContext)();
  const audioBuf = await tmp.decodeAudioData(buf.slice(0));
  await tmp.close?.();

  const data = audioBuf.getChannelData(0);
  const sr = audioBuf.sampleRate;

  // Compute spectral flux per hop using a naive DFT magnitude on a windowed slice.
  // For perf we only compute a limited number of bins: split into 4 bands.
  const bandFreqs = [
    [20, 200],
    [200, 800],
    [800, 2500],
    [2500, 8000],
  ];

  const numFrames = Math.floor((data.length - FFT_SIZE) / HOP);
  const bandEnergy: number[][] = [[], [], [], []];
  const totalFlux: number[] = [];

  // Use real DFT via lightweight Goertzel-ish sum across band sample bins
  // Simpler: bin energies via time-domain band-pass approximation isn't trivial.
  // We'll do a small FFT manually with the WebAudio AnalyserNode through OfflineAudioContext.
  const offline = new Ctx(1, audioBuf.length, sr);
  const src = offline.createBufferSource();
  src.buffer = audioBuf;
  const analyser = offline.createAnalyser();
  analyser.fftSize = FFT_SIZE;
  analyser.smoothingTimeConstant = 0;
  src.connect(analyser);
  analyser.connect(offline.destination);

  // We can't sample analyser between offline render frames. So instead do a manual approach:
  // chunk the audio, build mag spectra via real FFT.

  // Implement a tiny radix-2 FFT.
  const N = FFT_SIZE;
  const cosT = new Float32Array(N);
  const sinT = new Float32Array(N);
  for (let k = 0; k < N; k++) {
    cosT[k] = Math.cos((-2 * Math.PI * k) / N);
    sinT[k] = Math.sin((-2 * Math.PI * k) / N);
  }

  function fft(re: Float32Array, im: Float32Array) {
    const n = re.length;
    // bit reverse
    let j = 0;
    for (let i = 1; i < n; i++) {
      let bit = n >> 1;
      for (; j & bit; bit >>= 1) j ^= bit;
      j ^= bit;
      if (i < j) {
        [re[i], re[j]] = [re[j], re[i]];
        [im[i], im[j]] = [im[j], im[i]];
      }
    }
    for (let len = 2; len <= n; len <<= 1) {
      const ang = (-2 * Math.PI) / len;
      const wRe = Math.cos(ang);
      const wIm = Math.sin(ang);
      for (let i = 0; i < n; i += len) {
        let curRe = 1;
        let curIm = 0;
        for (let k2 = 0; k2 < len / 2; k2++) {
          const tRe = curRe * re[i + k2 + len / 2] - curIm * im[i + k2 + len / 2];
          const tIm = curRe * im[i + k2 + len / 2] + curIm * re[i + k2 + len / 2];
          re[i + k2 + len / 2] = re[i + k2] - tRe;
          im[i + k2 + len / 2] = im[i + k2] - tIm;
          re[i + k2] = re[i + k2] + tRe;
          im[i + k2] = im[i + k2] + tIm;
          const nRe = curRe * wRe - curIm * wIm;
          curIm = curRe * wIm + curIm * wRe;
          curRe = nRe;
        }
      }
    }
  }

  // Hann window
  const win = new Float32Array(N);
  for (let i = 0; i < N; i++) win[i] = 0.5 * (1 - Math.cos((2 * Math.PI * i) / (N - 1)));

  let prevMag = new Float32Array(N / 2);
  const re = new Float32Array(N);
  const im = new Float32Array(N);

  for (let f = 0; f < numFrames; f++) {
    const off = f * HOP;
    for (let i = 0; i < N; i++) {
      re[i] = (data[off + i] || 0) * win[i];
      im[i] = 0;
    }
    fft(re, im);
    let flux = 0;
    const mag = new Float32Array(N / 2);
    for (let k = 0; k < N / 2; k++) {
      const m = Math.hypot(re[k], im[k]);
      mag[k] = m;
      const d = m - prevMag[k];
      if (d > 0) flux += d;
    }
    prevMag = mag;
    totalFlux.push(flux);

    // band energies
    for (let b = 0; b < 4; b++) {
      const [lo, hi] = bandFreqs[b];
      const k0 = Math.max(1, Math.floor((lo * N) / sr));
      const k1 = Math.min(N / 2 - 1, Math.ceil((hi * N) / sr));
      let e = 0;
      for (let k = k0; k <= k1; k++) e += mag[k] * mag[k];
      bandEnergy[b].push(e);
    }
  }

  // Pick onsets: peaks of flux above adaptive threshold + min spacing
  const minSpacingFrames = Math.max(3, Math.floor(0.12 / (HOP / sr))); // 120 ms
  const meanFlux = totalFlux.reduce((a, b) => a + b, 0) / Math.max(1, totalFlux.length);
  const stdFlux = Math.sqrt(
    totalFlux.reduce((a, b) => a + (b - meanFlux) ** 2, 0) / Math.max(1, totalFlux.length),
  );
  const threshold = meanFlux + 0.6 * stdFlux;

  const onsets: Onset[] = [];
  let lastIdx = -minSpacingFrames;
  const peakFrames: number[] = [];
  for (let i = 1; i < totalFlux.length - 1; i++) {
    const v = totalFlux[i];
    if (v < threshold) continue;
    if (v <= totalFlux[i - 1] || v < totalFlux[i + 1]) continue;
    if (i - lastIdx < minSpacingFrames) continue;
    lastIdx = i;
    peakFrames.push(i);
  }

  // Mirror python: np.array_split(peaks, 4) — chronological equal groups -> buttons 0..3
  // This guarantees every button gets a roughly equal share of onsets.
  const nB = 4;
  const total = peakFrames.length;
  const base = Math.floor(total / nB);
  const rem = total % nB;
  let cursor = 0;
  for (let b = 0; b < nB; b++) {
    const size = base + (b < rem ? 1 : 0);
    for (let k = 0; k < size; k++) {
      const fi = peakFrames[cursor++];
      onsets.push({ time: (fi * HOP) / sr, button: b as 0 | 1 | 2 | 3 });
    }
  }
  // keep onsets sorted by time for downstream consumers
  onsets.sort((a, b) => a.time - b.time);
  console.log("[audioAnalysis] onsets per button:",
    [0,1,2,3].map((b) => onsets.filter((o) => o.button === b).length));

  const envelope = getEnvelope(audioBuf);
  const buttonPitches = getButtonPitches(audioBuf, onsets);
  return { onsets, duration: audioBuf.duration, envelope, buttonPitches, audioBuffer: audioBuf };
}

// --- smoothed amplitude envelope, mirrors python get_sine_wave_representation ---
export function getEnvelope(buffer: AudioBuffer, numPoints = 800): Float32Array {
  const data = buffer.getChannelData(0);
  const sr = buffer.sampleRate;
  const win = Math.max(3, Math.floor(0.03 * sr) | 1); // 30ms window, odd
  const half = win >> 1;
  // running average of |data|
  const N = data.length;
  const env = new Float32Array(N);
  let acc = 0;
  for (let i = 0; i < Math.min(win, N); i++) acc += Math.abs(data[i]);
  for (let i = 0; i < N; i++) {
    if (i > half && i + half < N) {
      acc += Math.abs(data[i + half]) - Math.abs(data[i - half - 1]);
    }
    env[i] = acc / win;
  }
  // normalize
  let max = 1e-9;
  for (let i = 0; i < N; i++) if (env[i] > max) max = env[i];
  for (let i = 0; i < N; i++) env[i] /= max;
  // downsample
  const out = new Float32Array(numPoints);
  for (let i = 0; i < numPoints; i++) {
    const idx = Math.floor((i / (numPoints - 1)) * (N - 1));
    out[i] = env[idx];
  }
  return out;
}

// --- per-button dominant pitch via autocorrelation on a short window after each onset ---
export function getButtonPitches(buffer: AudioBuffer, onsets: Onset[]): number[] {
  const data = buffer.getChannelData(0);
  const sr = buffer.sampleRate;
  const winSamples = Math.floor(0.08 * sr); // 80 ms
  const minHz = 80;
  const maxHz = 1500;
  const minLag = Math.floor(sr / maxHz);
  const maxLag = Math.floor(sr / minHz);

  const groups: number[][] = [[], [], [], []];
  for (const o of onsets) {
    const start = Math.floor(o.time * sr);
    const end = Math.min(data.length, start + winSamples);
    if (end - start < maxLag + 8) continue;
    // autocorrelation peak
    let bestLag = -1;
    let bestVal = 0;
    for (let lag = minLag; lag <= maxLag; lag++) {
      let sum = 0;
      for (let i = start; i < end - lag; i++) sum += data[i] * data[i + lag];
      if (sum > bestVal) {
        bestVal = sum;
        bestLag = lag;
      }
    }
    if (bestLag > 0) groups[o.button].push(sr / bestLag);
  }
  // band-center fallbacks (Hz) by button index 0..3
  const fallback = [110, 330, 660, 1320];
  return groups.map((g, i) => {
    if (!g.length) return fallback[i];
    g.sort((a, b) => a - b);
    return g[Math.floor(g.length / 2)];
  });
}