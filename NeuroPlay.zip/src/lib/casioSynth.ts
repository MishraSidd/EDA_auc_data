// Sample-based polyphonic note player using uploaded WAV files.
export type NoteKey = "A" | "B" | "C" | "D" | "E";

const SAMPLE_URLS: Record<NoteKey, string> = {
  A: "/sounds/A.wav",
  B: "/sounds/B.wav",
  C: "/sounds/C.wav",
  D: "/sounds/D.wav",
  E: "/sounds/E.wav",
};

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
const buffers: Partial<Record<NoteKey, AudioBuffer>> = {};
let loadPromise: Promise<void> | null = null;
let masterVolume = 0.35;

function ensureCtx(): AudioContext {
  if (!ctx) {
    const C = window.AudioContext || (window as any).webkitAudioContext;
    ctx = new C();
    master = ctx.createGain();
    master.gain.value = masterVolume;
    master.connect(ctx.destination);
  }
  if (ctx.state === "suspended") ctx.resume();
  return ctx;
}

function loadAll(): Promise<void> {
  if (loadPromise) return loadPromise;
  const c = ensureCtx();
  loadPromise = Promise.all(
    (Object.keys(SAMPLE_URLS) as NoteKey[]).map(async (k) => {
      try {
        const res = await fetch(SAMPLE_URLS[k]);
        const ab = await res.arrayBuffer();
        buffers[k] = await c.decodeAudioData(ab);
      } catch (e) {
        console.warn("[casioSynth] failed to load sample", k, e);
      }
    })
  ).then(() => undefined);
  return loadPromise;
}

export function unlockCasioAudio() {
  ensureCtx();
  loadAll();
}

export function setCasioVolume(value: number) {
  masterVolume = Math.max(0, Math.min(1, value));
  if (master) {
    const c = ensureCtx();
    master.gain.setTargetAtTime(masterVolume, c.currentTime, 0.02);
  }
}

export function playCasioNote(key: NoteKey, opts?: { velocity?: number }) {
  const c = ensureCtx();
  const buf = buffers[key];
  if (!buf) {
    loadAll();
    return;
  }
  const vel = opts?.velocity ?? 1.0;
  const src = c.createBufferSource();
  src.buffer = buf;
  const g = c.createGain();
  g.gain.value = vel;
  src.connect(g).connect(master!);
  src.start();
}
