// Centralized helpers that persist game / mood / task activity to the
// database and surface a tiny "Session saved" toast for testing visibility.
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { getUserId } from "@/features/assessment/useAdaptiveProfile";

export interface GameSessionInput {
  gameName: string;
  score: number;
  errors?: number;
  accuracyPercent?: number;
  durationSeconds?: number;
  levelReached?: string | number;
  difficulty?: string;
  roundsTotal?: number;
  roundsCorrect?: number;
  sessionData?: Record<string, unknown>;
}

function notifySaved(label = "Session saved ✓") {
  try { toast.success(label); } catch { /* noop */ }
}

function notifyFail(err: unknown) {
  console.warn("[sessionTracker] save failed", err);
  try { toast.error("Couldn't save session"); } catch { /* noop */ }
}

export async function saveGameSession(input: GameSessionInput) {
  try {
    const { error } = await supabase.from("game_sessions").insert({
      user_id: getUserId(),
      game: input.gameName,
      game_name: input.gameName,
      score: Math.round(input.score ?? 0),
      errors: Math.round(input.errors ?? 0),
      accuracy: Number(input.accuracyPercent ?? 0),
      accuracy_percent: Number(input.accuracyPercent ?? 0),
      duration_sec: Math.round(input.durationSeconds ?? 0),
      duration_seconds: Math.round(input.durationSeconds ?? 0),
      level_reached: input.levelReached != null ? String(input.levelReached) : null,
      difficulty: input.difficulty ?? null,
      rounds_total: Math.round(input.roundsTotal ?? 0),
      rounds_correct: Math.round(input.roundsCorrect ?? 0),
      session_data: (input.sessionData ?? {}) as never,
      metadata: (input.sessionData ?? {}) as never,
    });
    if (error) throw error;
    notifySaved();
  } catch (e) { notifyFail(e); }
}

export async function saveMoodLog(score: number, label: string) {
  try {
    const { error } = await supabase.from("mood_logs").insert({
      user_id: getUserId(),
      mood_value: score,
      mood_score: score,
      mood_label: label,
    });
    if (error) throw error;
    notifySaved("Mood saved ✓");
  } catch (e) { notifyFail(e); }
}

export async function saveTaskLog(input: {
  taskName: string;
  wasCompleted: boolean;
  scheduledTime?: string;
}) {
  try {
    const completedAt = new Date();
    let delayMinutes = 0;
    if (input.scheduledTime) {
      // scheduledTime is like "08:00 AM" — anchor to today.
      const t = parseTimeOfDay(input.scheduledTime, completedAt);
      if (t) delayMinutes = Math.round((completedAt.getTime() - t.getTime()) / 60000);
    }
    const { error } = await supabase.from("task_logs").insert({
      user_id: getUserId(),
      task_name: input.taskName,
      was_completed: input.wasCompleted,
      completed_at: completedAt.toISOString(),
      delay_minutes: delayMinutes,
      scheduled_time: input.scheduledTime ?? null,
    });
    if (error) throw error;
    notifySaved("Task saved ✓");
  } catch (e) { notifyFail(e); }
}

function parseTimeOfDay(s: string, anchor: Date): Date | null {
  const m = s.trim().match(/^(\d{1,2}):(\d{2})\s*(AM|PM)?$/i);
  if (!m) return null;
  let h = parseInt(m[1], 10);
  const min = parseInt(m[2], 10);
  const mer = m[3]?.toUpperCase();
  if (mer === "PM" && h < 12) h += 12;
  if (mer === "AM" && h === 12) h = 0;
  const d = new Date(anchor);
  d.setHours(h, min, 0, 0);
  return d;
}