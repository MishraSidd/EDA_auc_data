// Scoring engine: compares player keypress events to a scoring_scheme.json.

export type NoteKey = "A" | "B" | "C" | "D" | "E";

export interface SchemeNote {
  key?: NoteKey;            // legacy single-key
  keys?: NoteKey[];         // chord (preferred)
  time: number;     // seconds from gameplay start
  duration: number; // sustain seconds
}

export interface Scheme {
  notes: SchemeNote[];
  bpm?: number;
  song_length?: number;
  expected_sequence?: string[];
}

export interface PressEvent {
  key: NoteKey;
  time: number;     // seconds from gameplay start
  hold: number;     // seconds held
}

export type Quality = "perfect" | "good" | "okay" | "miss";

export interface NoteResult {
  expected: SchemeNote;
  expectedKeys: NoteKey[];
  matched?: PressEvent[];   // one per chord key (when matched)
  quality: Quality;
  points: number;
  delta: number; // ms (+late / -early), 0 if miss
}

export interface ScoreSummary {
  total: number;
  accuracy: number;     // 0..100
  combo: number;        // best combo
  perfect: number;
  good: number;
  okay: number;
  miss: number;
  durationAccuracy: number; // 0..100, how close avg hold matches avg expected duration
  avgHold: number;          // seconds
  avgExpected: number;      // seconds
  results: NoteResult[];
}

const POINTS: Record<Quality, number> = { perfect: 100, good: 70, okay: 40, miss: 0 };
const CHORD_SPREAD_MS = 120;   // max delta between earliest/latest press in a chord
const MATCH_WINDOW_MS = 350;   // max distance from expected note time

function loopDurationOf(scheme: Scheme): number {
  if (scheme.song_length && scheme.song_length > 0) return scheme.song_length;
  const last = scheme.notes[scheme.notes.length - 1];
  return last ? last.time + Math.max(0.4, last.duration) + 0.4 : 0;
}

function expandNotesForDuration(scheme: Scheme, duration?: number): SchemeNote[] {
  if (!duration || duration <= 0 || scheme.notes.length === 0) return scheme.notes;
  const loopDuration = loopDurationOf(scheme);
  if (!loopDuration) return scheme.notes;
  const expanded: SchemeNote[] = [];
  for (let base = 0; base <= duration + loopDuration; base += loopDuration) {
    for (const note of scheme.notes) {
      const time = base + note.time;
      if (time <= duration) expanded.push({ ...note, time });
    }
  }
  return expanded;
}

export function expectedKeysOf(n: SchemeNote): NoteKey[] {
  if (n.keys && n.keys.length) return n.keys;
  if (n.key) return [n.key];
  return [];
}

export function classify(deltaMs: number, correctKey: boolean): Quality {
  if (!correctKey) return "miss";
  const a = Math.abs(deltaMs);
  if (a <= 50) return "perfect";
  if (a <= 120) return "good";
  if (a <= 200) return "okay";
  return "miss";
}

/** Greedy nearest-press matching. */
export function scoreRun(scheme: Scheme, presses: PressEvent[], opts?: { duration?: number }): ScoreSummary {
  const expectedNotes = expandNotesForDuration(scheme, opts?.duration);
  const used = new Set<number>();
  const results: NoteResult[] = [];
  let total = 0;
  let combo = 0;
  let bestCombo = 0;
  const counts: Record<Quality, number> = { perfect: 0, good: 0, okay: 0, miss: 0 };

  for (const expected of expectedNotes) {
    const reqKeys = expectedKeysOf(expected);
    // For each required key, find the closest unused press within the window
    const picked: { idx: number; press: PressEvent }[] = [];
    let failed = false;
    for (const key of reqKeys) {
      let bestIdx = -1;
      let bestDelta = Infinity;
      presses.forEach((p, i) => {
        if (used.has(i)) return;
        if (picked.some((x) => x.idx === i)) return;
        if (p.key !== key) return;
        const d = Math.abs(p.time - expected.time) * 1000;
        if (d < bestDelta && d <= MATCH_WINDOW_MS) { bestDelta = d; bestIdx = i; }
      });
      if (bestIdx === -1) { failed = true; break; }
      picked.push({ idx: bestIdx, press: presses[bestIdx] });
    }
    // Validate chord simultaneity
    if (!failed && picked.length > 1) {
      const times = picked.map((x) => x.press.time);
      const spread = (Math.max(...times) - Math.min(...times)) * 1000;
      if (spread > CHORD_SPREAD_MS) failed = true;
    }
    if (failed) {
      results.push({ expected, expectedKeys: reqKeys, quality: "miss", points: 0, delta: 0 });
      counts.miss++;
      combo = 0;
      continue;
    }
    picked.forEach((x) => used.add(x.idx));
    const avgDelta = picked.reduce((s, x) => s + (x.press.time - expected.time), 0) / picked.length * 1000;
    const q = classify(avgDelta, true);
    counts[q]++;
    const pts = POINTS[q] * reqKeys.length; // chords worth more
    total += pts;
    if (q === "miss") combo = 0;
    else { combo++; if (combo > bestCombo) bestCombo = combo; }
    results.push({
      expected, expectedKeys: reqKeys,
      matched: picked.map((x) => x.press),
      quality: q, points: pts, delta: avgDelta,
    });
  }

  const maxPossible = expectedNotes.reduce(
    (s, n) => s + POINTS.perfect * expectedKeysOf(n).length, 0,
  );
  const timingAccuracy = maxPossible > 0 ? (total / maxPossible) * 100 : 0;

  // Duration match: compare AVERAGE hold vs AVERAGE expected duration across matched notes
  const matchedHolds: number[] = [];
  results.forEach((r) => r.matched?.forEach((p) => matchedHolds.push(p.hold)));
  const avgHold = matchedHolds.length
    ? matchedHolds.reduce((s, h) => s + h, 0) / matchedHolds.length
    : 0;
  const avgExpected = expectedNotes.length
    ? expectedNotes.reduce((s, n) => s + n.duration * expectedKeysOf(n).length, 0) /
      expectedNotes.reduce((s, n) => s + expectedKeysOf(n).length, 0)
    : 0;
  const durationAccuracy = avgExpected > 0
    ? Math.max(0, Math.min(100, 100 * (1 - Math.abs(avgHold - avgExpected) / avgExpected)))
    : 0;

  // Final accuracy = 70% timing + 30% duration match
  const accuracy = Math.round(0.7 * timingAccuracy + 0.3 * durationAccuracy);
  // Bonus points for duration accuracy
  const durationBonus = Math.round((durationAccuracy / 100) * expectedNotes.length * 30);
  return {
    total: total + durationBonus,
    accuracy,
    combo: bestCombo,
    ...counts,
    durationAccuracy: Math.round(durationAccuracy),
    avgHold,
    avgExpected,
    results,
  };
}
