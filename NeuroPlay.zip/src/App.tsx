import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index.tsx";
import NotFound from "./pages/NotFound.tsx";
import EchoSurfer from "./pages/EchoSurfer.tsx";
import IndexV2 from "./pages/IndexV2.tsx";
import TaskArranger from "./pages/TaskArranger.tsx";
import Onboarding from "./pages/Onboarding.tsx";
import TremorAssessment from "./pages/TremorAssessment.tsx";
import Caregiver from "./pages/Caregiver.tsx";
import Games from "./pages/Games.tsx";
import Profile from "./pages/Profile.tsx";
// Added games (self-contained, no shared component changes)
import MemoryRecallGame from "./games/MemoryRecallGame";
import SpatialGridGame from "./games/SpatialGridGame";
import SpeechRecoveryGame from "./games/SpeechRecoveryGame";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/v2" element={<IndexV2 />} />
          <Route path="/games/beat-runner" element={<EchoSurfer />} />
          <Route path="/games/echo-surfer" element={<EchoSurfer />} />
          <Route path="/games/task-arranger" element={<TaskArranger />} />
          <Route path="/onboarding" element={<Onboarding />} />
          <Route path="/assessment/tremor" element={<TremorAssessment />} />
          <Route path="/caregiver" element={<Caregiver />} />
          <Route path="/games" element={<Games />} />
          <Route path="/profile" element={<Profile />} />
          {/* New self-contained games */}
          <Route path="/games/memory-recall" element={<MemoryRecallGame />} />
          <Route path="/games/spatial-grid" element={<SpatialGridGame />} />
          {/* Speech Practice (own top-level section) */}
          <Route path="/speech" element={<SpeechRecoveryGame />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
