import Phaser from "phaser";
import { playCasioNote, type NoteKey } from "@/lib/casioSynth";
import type { Scheme, PressEvent } from "@/lib/scoring";
import { expectedKeysOf } from "@/lib/scoring";

const KEYS: NoteKey[] = ["A", "B", "C", "D", "E"];
// Physical keyboard key -> casio note key
const KEY_BINDINGS: { phys: string; note: NoteKey }[] = [
  { phys: "A", note: "A" },
  { phys: "S", note: "B" },
  { phys: "D", note: "C" },
  { phys: "J", note: "D" },
  { phys: "K", note: "E" },
];
const CUE_LOOKAHEAD_DEFAULT = 4.0;
const HIT_WINDOW_SECONDS = 0.35;

// Per-key ribbon shaping: target Y delta (relative to baseline) and curve style
const KEY_SHAPE: Record<NoteKey, { dy: number; sharp: number }> = {
  A: { dy:  90, sharp: 0.3 }, // gentle down
  B: { dy: -90, sharp: 0.3 }, // smooth up
  C: { dy:   0, sharp: 0.1 }, // stabilize
  D: { dy: -160, sharp: 0.5 }, // big up arc
  E: { dy: -40, sharp: 1.0 }, // sharp spike (handled specially)
};

interface EchoConfig {
  scheme: Scheme;
  onPress: (e: PressEvent) => void;
  onFinish: () => void;
  duration: number; // total game seconds
  trainMode?: boolean;
  cueLookahead?: number;
}

export class EchoSurferScene extends Phaser.Scene {
  private cfg!: EchoConfig;
  private startMs = 0;
  private targetY = 0;
  private currentY = 0;
  private baselineY = 0;
  private ribbonGfx!: Phaser.GameObjects.Graphics;
  private bgGfx!: Phaser.GameObjects.Graphics;
  private markerGfx!: Phaser.GameObjects.Graphics;
  private particles: { x: number; y: number; vx: number; vy: number; life: number; max: number; hue: number }[] = [];
  private stars: { x: number; y: number; r: number; tw: number; speed: number }[] = [];
  private ribbonHistory: { y: number; intensity: number; hue: number }[] = [];
  // Sine-wave state (replaces rigid polyline ribbon)
  private wavePhase = 0;
  private waveAmp = 30;
  private waveAmpTarget = 30;
  private waveFreq = 0.014;       // radians per pixel
  private wavePhaseShift = 0;
  private wavePhaseShiftTarget = 0;
  private waveBaselineOffset = 0;
  private waveBaselineTarget = 0;
  private surfer!: Phaser.GameObjects.Container;
  private hudText!: Phaser.GameObjects.Text;
  private comboText!: Phaser.GameObjects.Text;
  private accuracyShake = 0;
  private glowIntensity = 0.5;
  private holdStarts: Partial<Record<NoteKey, number>> = {};
  private finished = false;
  private countdown = 3;
  private countdownTimer = 0;
  private active = false;
  private nebulae: { x: number; y: number; r: number; hue: number; drift: number }[] = [];
  private moonX = 0;
  private moonY = 0;
  private moonR = 0;
  private cueTexts: Phaser.GameObjects.Text[] = [];
  private pressNowText!: Phaser.GameObjects.Text;
  private trainMode = true;
  private cueLookahead = CUE_LOOKAHEAD_DEFAULT;
  private nextNoteIdx = 0;
  private loopStart = 0;
  private loopDuration = 0;
  private pausedAt = 0;

  constructor() {
    super({ key: "EchoSurferScene" });
  }

  init(data: EchoConfig) {
    this.cfg = data;
    this.trainMode = data.trainMode !== false;
    this.cueLookahead = data.cueLookahead && data.cueLookahead > 0 ? data.cueLookahead : CUE_LOOKAHEAD_DEFAULT;
    this.finished = false;
    this.active = false;
    this.countdown = 3;
    this.countdownTimer = 0;
    this.ribbonHistory = [];
    this.particles = [];
    this.holdStarts = {};
  }

  create() {
    const W = this.scale.width;
    const H = this.scale.height;
    this.baselineY = H * 0.55;
    this.currentY = this.baselineY;
    this.targetY = this.baselineY;

    this.bgGfx = this.add.graphics();
    this.ribbonGfx = this.add.graphics();
    this.markerGfx = this.add.graphics().setDepth(8);

    // Stars
    for (let i = 0; i < 220; i++) {
      this.stars.push({
        x: Math.random() * W,
        y: Math.random() * H,
        r: Math.random() * 1.5 + 0.2,
        tw: Math.random() * Math.PI * 2,
        speed: 4 + Math.random() * 18,
      });
    }
    // Nebulae / galaxies
    for (let i = 0; i < 5; i++) {
      this.nebulae.push({
        x: Math.random() * W,
        y: Math.random() * H * 0.7,
        r: 80 + Math.random() * 140,
        hue: 220 + Math.random() * 140,
        drift: 2 + Math.random() * 6,
      });
    }
    this.moonX = W * 0.78;
    this.moonY = H * 0.22;
    this.moonR = Math.min(W, H) * 0.11;

    // Compute looped scheme duration for cue scheduling
    const last = this.cfg.scheme.notes[this.cfg.scheme.notes.length - 1];
    this.loopDuration = this.cfg.scheme.song_length && this.cfg.scheme.song_length > 0
      ? this.cfg.scheme.song_length
      : last ? last.time + Math.max(0.4, last.duration) + 0.4 : 6;

    // Surfer container — locked at horizontal center
    this.surfer = this.add.container(W * 0.35, this.baselineY);
    this.drawSurfer();

    // HUD
    this.hudText = this.add.text(16, 14, "", {
      fontFamily: "system-ui, sans-serif",
      fontSize: "16px",
      color: "#e0f2fe",
    }).setScrollFactor(0).setDepth(10);
    this.comboText = this.add.text(W / 2, 60, "", {
      fontFamily: "system-ui, sans-serif",
      fontSize: "32px",
      color: "#fde047",
      fontStyle: "bold",
    }).setOrigin(0.5).setDepth(10);

    // Pool of cue text objects (key letters that fly in toward the surfer)
    for (let i = 0; i < 8; i++) {
      const t = this.add.text(0, 0, "", {
        fontFamily: "system-ui, sans-serif",
        fontSize: "44px",
        color: "#ffffff",
        fontStyle: "bold",
      }).setOrigin(0.5).setDepth(9).setVisible(false);
      this.cueTexts.push(t);
    }
    this.pressNowText = this.add.text(0, 0, "PRESS", {
      fontFamily: "system-ui, sans-serif",
      fontSize: "18px",
      color: "#fde047",
      fontStyle: "bold",
    }).setOrigin(0.5).setDepth(10).setVisible(false);

    // Keyboard
    KEY_BINDINGS.forEach(({ phys, note }) => {
      const phaserKey = (Phaser.Input.Keyboard.KeyCodes as any)[phys];
      const obj = this.input.keyboard!.addKey(phaserKey);
      obj.on("down", () => this.onKeyDown(note));
      obj.on("up", () => this.onKeyUp(note));
    });

    // Resize
    this.scale.on("resize", (gs: Phaser.Structs.Size) => {
      this.surfer.x = gs.width * 0.35;
      this.moonX = gs.width * 0.78;
      this.moonY = gs.height * 0.22;
      this.moonR = Math.min(gs.width, gs.height) * 0.11;
      this.baselineY = gs.height * 0.55;
    });
  }

  setTrainMode(on: boolean) {
    this.trainMode = on;
    if (!on) this.cueTexts.forEach((t) => t.setVisible(false));
    if (!on && this.pressNowText) this.pressNowText.setVisible(false);
  }

  setCueLookahead(seconds: number) {
    this.cueLookahead = Math.max(1.0, Math.min(10, seconds));
  }

  /** Pop a floating feedback label (e.g. "Good!", "Combo x3") near the surfer. */
  showFeedback(text: string, color = "#fde047") {
    const t = this.add.text(this.surfer.x, this.baselineY - 180, text, {
      fontFamily: "system-ui, sans-serif",
      fontSize: "34px",
      color,
      fontStyle: "bold",
      stroke: "#000",
      strokeThickness: 4,
    }).setOrigin(0.5).setDepth(20);
    this.tweens.add({
      targets: t,
      y: t.y - 60,
      alpha: 0,
      scale: 1.4,
      duration: 900,
      ease: "Cubic.easeOut",
      onComplete: () => t.destroy(),
    });
  }

  private drawSurfer() {
    this.surfer.removeAll(true);
    const g = this.add.graphics();
    // Hover board
    g.fillStyle(0x60a5fa, 1);
    g.fillRoundedRect(-26, 8, 52, 6, 3);
    g.fillStyle(0x93c5fd, 0.7);
    g.fillRoundedRect(-22, 14, 44, 3, 2);
    // Glow under board
    g.fillStyle(0x22d3ee, 0.35);
    g.fillEllipse(0, 22, 60, 8);
    // Stickman body
    g.lineStyle(2.5, 0xffffff, 1);
    g.strokeCircle(0, -22, 6);            // head
    g.beginPath();
    g.moveTo(0, -16); g.lineTo(0, 4);     // torso
    g.moveTo(0, -8); g.lineTo(-8, -2);    // arm L
    g.moveTo(0, -8); g.lineTo(10, -14);   // arm R (raised)
    g.moveTo(0, 4); g.lineTo(-9, 8);      // leg L
    g.moveTo(0, 4); g.lineTo(9, 8);       // leg R
    g.strokePath();
    this.surfer.add(g);
  }

  startGame() {
    this.startMs = performance.now();
    this.active = true;
    this.finished = false;
    // clear lingering countdown digit
    if (this.comboText) this.comboText.setText("");
  }

  /** Pause the game clock + scene update loop. Safe to call repeatedly. */
  pauseGame() {
    if (!this.active || this.pausedAt) return;
    this.pausedAt = performance.now();
    this.scene.pause();
  }

  /** Resume; shift startMs forward so elapsed time excludes the pause. */
  resumeGame() {
    if (!this.pausedAt) return;
    this.startMs += performance.now() - this.pausedAt;
    this.pausedAt = 0;
    this.scene.resume();
  }

  private now() {
    return (performance.now() - this.startMs) / 1000;
  }

  private onKeyDown(k: NoteKey) {
    if (this.holdStarts[k] !== undefined) return; // ignore repeat
    playCasioNote(k);
    this.holdStarts[k] = this.now();
    // Shape sine wave on press
    const shape = KEY_SHAPE[k];
    // Amplitude jolt scales with key intensity, then decays back
    this.waveAmpTarget = Math.min(140, 30 + Math.abs(shape.dy) * 0.6);
    // Phase nudge gives the wave a visible "kick" — direction follows shape sign
    this.wavePhaseShiftTarget += shape.dy >= 0 ? 0.55 : -0.55;
    // Baseline drifts subtly so different keys feel distinct
    this.waveBaselineTarget = shape.dy * 0.25;
    if (k === "E") {
      // sharp spike: brief amplitude burst
      this.waveAmpTarget = 150;
    }
    // particles burst
    const sx = this.surfer.x;
    const sy = this.surfer.y;
    const hue = this.hueFor(k);
    for (let i = 0; i < 14; i++) {
      const a = Math.random() * Math.PI * 2;
      const sp = 60 + Math.random() * 140;
      this.particles.push({
        x: sx, y: sy,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 30,
        life: 0, max: 0.6 + Math.random() * 0.4,
        hue,
      });
    }
    this.glowIntensity = Math.min(1.2, this.glowIntensity + 0.15);
  }

  private onKeyUp(k: NoteKey) {
    const startedAt = this.holdStarts[k];
    if (startedAt === undefined || !this.active) {
      this.holdStarts[k] = undefined;
      return;
    }
    const t = this.now();
    const hold = Math.max(0.04, t - startedAt);
    this.holdStarts[k] = undefined;
    this.cfg.onPress({ key: k, time: startedAt, hold });
    // ease wave back toward calm baseline after release
    this.waveAmpTarget = 30;
    this.waveBaselineTarget = 0;
  }

  private flushActiveHolds() {
    const t = this.now();
    KEY_BINDINGS.forEach(({ note }) => {
      const startedAt = this.holdStarts[note];
      if (startedAt === undefined) return;
      this.holdStarts[note] = undefined;
      this.cfg.onPress({ key: note, time: startedAt, hold: Math.max(0.04, t - startedAt) });
    });
  }

  private hueFor(k: NoteKey): number {
    const map: Record<NoteKey, number> = { A: 200, B: 170, C: 280, D: 320, E: 50 };
    return map[k];
  }

  update(_time: number, deltaMs: number) {
    const dt = deltaMs / 1000;
    const W = this.scale.width;
    const H = this.scale.height;

    // Countdown phase
    if (!this.active && !this.finished) {
      this.countdownTimer += dt;
      if (this.countdownTimer >= 1) {
        this.countdownTimer = 0;
        this.countdown -= 1;
        if (this.countdown <= 0) {
          this.startGame();
        }
      }
    }

    // Smoothly approach target Y
    // Animate sine wave (60fps smooth)
    this.wavePhase += dt * 1.8;
    const ampEase = 5;
    this.waveAmp += (this.waveAmpTarget - this.waveAmp) * Math.min(1, ampEase * dt);
    // Slow natural decay back to calm
    this.waveAmpTarget += (30 - this.waveAmpTarget) * Math.min(1, 0.6 * dt);
    this.wavePhaseShift += (this.wavePhaseShiftTarget - this.wavePhaseShift) * Math.min(1, 4 * dt);
    this.waveBaselineOffset += (this.waveBaselineTarget - this.waveBaselineOffset) * Math.min(1, 3 * dt);
    this.waveBaselineTarget += (0 - this.waveBaselineTarget) * Math.min(1, 0.5 * dt);
    // Compute surfer Y from sine
    const surferSineY = this.baselineY + this.waveBaselineOffset
      + Math.sin(this.surfer.x * this.waveFreq + this.wavePhase + this.wavePhaseShift) * this.waveAmp;
    this.currentY = surferSineY;
    // glow decays
    this.glowIntensity = Math.max(0.4, this.glowIntensity - dt * 0.4);

    // ===== Draw background =====
    this.bgGfx.clear();
    // Deep gradient (manual)
    this.bgGfx.fillStyle(0x05060f, 1);
    this.bgGfx.fillRect(0, 0, W, H);
    this.bgGfx.fillStyle(0x0a0a22, 0.7);
    this.bgGfx.fillRect(0, H * 0.3, W, H * 0.7);

    // Nebulae
    for (const n of this.nebulae) {
      n.x -= n.drift * dt;
      if (n.x < -n.r) n.x = W + n.r;
      const col = Phaser.Display.Color.HSLToColor(n.hue / 360, 0.7, 0.5).color;
      for (let i = 0; i < 3; i++) {
        const r = n.r * (1 - i * 0.3);
        this.bgGfx.fillStyle(col, 0.06 + i * 0.04);
        this.bgGfx.fillCircle(n.x, n.y, r);
      }
    }

    // Stars (parallax)
    for (const s of this.stars) {
      s.x -= s.speed * dt;
      if (s.x < 0) s.x += W;
      const a = 0.4 + 0.6 * Math.abs(Math.sin(performance.now() * 0.001 + s.tw));
      this.bgGfx.fillStyle(0xffffff, a);
      this.bgGfx.fillCircle(s.x, s.y, s.r);
    }

    // Moon glow + body
    for (let i = 4; i >= 1; i--) {
      this.bgGfx.fillStyle(0xb8c8ff, 0.04 * i);
      this.bgGfx.fillCircle(this.moonX, this.moonY, this.moonR * (1 + i * 0.5));
    }
    this.bgGfx.fillStyle(0xf5f3ff, 0.95);
    this.bgGfx.fillCircle(this.moonX, this.moonY, this.moonR);
    this.bgGfx.fillStyle(0xc7d2fe, 0.5);
    this.bgGfx.fillCircle(this.moonX + this.moonR * 0.25, this.moonY + this.moonR * 0.1, this.moonR * 0.95);

    // ===== Draw cosmic ribbon =====
    this.ribbonGfx.clear();
    this.markerGfx.clear();
    // Draw a smooth sine wave across the full width.
    // Sample spacing chosen to keep the curve visually smooth at 60fps without
    // wasting fill — ~1 sample per 6px on a 1080w canvas ≈ 180 segments.
    const drawSineRibbon = (lw: number, alpha: number, color: number, phaseOffset = 0) => {
      this.ribbonGfx.lineStyle(lw, color, alpha);
      this.ribbonGfx.beginPath();
      const step = 6;
      const baseY = this.baselineY + this.waveBaselineOffset;
      for (let x = 0; x <= W; x += step) {
        const y = baseY + Math.sin(x * this.waveFreq + this.wavePhase + this.wavePhaseShift + phaseOffset) * this.waveAmp;
        if (x === 0) this.ribbonGfx.moveTo(x, y);
        else this.ribbonGfx.lineTo(x, y);
      }
      this.ribbonGfx.strokePath();
    };
    drawSineRibbon(40, 0.08 * this.glowIntensity, 0x4338ca);
    drawSineRibbon(28, 0.14 * this.glowIntensity, 0x6d28d9);
    drawSineRibbon(18, 0.22 * this.glowIntensity, 0x8b5cf6);
    drawSineRibbon(12, 0.45, 0xa78bfa);
    drawSineRibbon(7,  0.75, 0xc4b5fd);
    drawSineRibbon(3,  1.0,  0xeef2ff);

    // ===== Particles =====
    for (const p of this.particles) {
      p.life += dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += 50 * dt;
      const k = 1 - p.life / p.max;
      if (k <= 0) continue;
      const col = Phaser.Display.Color.HSLToColor(p.hue / 360, 0.9, 0.65).color;
      this.ribbonGfx.fillStyle(col, k);
      this.ribbonGfx.fillCircle(p.x, p.y, 2 + 3 * k);
    }
    this.particles = this.particles.filter((p) => p.life < p.max);

    // Surfer follows ribbon
    this.surfer.y = this.currentY;
    // wobble with low accuracy
    this.surfer.rotation = Math.sin(performance.now() * 0.005) * 0.02 * (1 + this.accuracyShake);

    // HUD
    if (this.active) {
      const remain = Math.max(0, this.cfg.duration - this.now());
      this.hudText.setText(`Time: ${remain.toFixed(1)}s`);

      // ===== Upcoming-note cues =====
      if (this.trainMode) this.renderCues();
      else {
        this.cueTexts.forEach((t) => t.setVisible(false));
        if (this.pressNowText) this.pressNowText.setVisible(false);
        // Hit zone marker is part of the training overlay — keep it hidden when off
      }

      if (remain <= 0 && !this.finished) {
        this.flushActiveHolds();
        this.finished = true;
        this.active = false;
        this.cfg.onFinish();
      }
    } else if (this.countdown > 0) {
      this.comboText.setText(String(this.countdown));
    } else {
      this.comboText.setText("");
    }
  }

  /** Show flying key cues approaching the surfer. Loops the scheme to fill the full game duration. */
  private renderCues() {
    const W = this.scale.width;
    const surferX = this.surfer.x;
    const t = this.now();
    const lookahead = this.cueLookahead; // seconds preview (HUD-controllable)
    // Build list of upcoming chord events across loops within lookahead window
    const upcoming: { keys: NoteKey[]; absTime: number }[] = [];
    if (this.loopDuration > 0) {
      const loopsToCheck = 2;
      for (let l = 0; l < loopsToCheck; l++) {
        const base = Math.floor(t / this.loopDuration + l) * this.loopDuration;
        for (const n of this.cfg.scheme.notes) {
          const at = base + n.time;
          if (at >= t - 0.05 && at <= t + lookahead + 0.5) {
            upcoming.push({ keys: expectedKeysOf(n), absTime: at });
          }
        }
      }
    }
    upcoming.sort((a, b) => a.absTime - b.absTime);
    // Render up to cueTexts.length
    for (let i = 0; i < this.cueTexts.length; i++) {
      const txt = this.cueTexts[i];
      const ev = upcoming[i];
      if (!ev) { txt.setVisible(false); continue; }
      const remain = ev.absTime - t; // 0 = NOW at surfer
      // Map remain (lookahead..0) -> x (right edge .. surferX). Longer lookahead = slower, clearer cue travel.
      const u = Math.max(0, Math.min(1, remain / lookahead));
      const x = surferX + (W - surferX - 40) * u;
      const y = this.baselineY - 90;
      // Map each chord note to its physical key
      const physList = ev.keys.map((k) => KEY_BINDINGS.find(b => b.note === k)?.phys ?? k);
      txt.setText(physList.join("+"));
      txt.setPosition(x, y);
      const scale = 0.6 + (1 - u) * 0.6;
      txt.setScale(scale);
      const alpha = remain < 0 ? Math.max(0, 1 + remain * 4) : 0.4 + (1 - u) * 0.6;
      txt.setAlpha(alpha);
      // Color tint by first chord key
      const hue = this.hueFor(ev.keys[0]);
      const col = Phaser.Display.Color.HSLToColor(hue / 360, 0.8, 0.7).color;
      txt.setColor("#" + col.toString(16).padStart(6, "0"));
      txt.setVisible(true);
    }

    const next = upcoming[0];
    this.drawHitZone(next ? next.absTime - t : 99, HIT_WINDOW_SECONDS);
    if (this.pressNowText && next) {
      const inWindow = Math.abs(next.absTime - t) <= HIT_WINDOW_SECONDS;
      const physList = next.keys.map((k) => KEY_BINDINGS.find(b => b.note === k)?.phys ?? k);
      this.pressNowText
        .setText(inWindow ? `PRESS ${physList.join("+")}` : "HIT THE RING")
        .setPosition(surferX, this.baselineY - 154)
        .setAlpha(inWindow ? 1 : 0.55)
        .setScale(inWindow ? 1.2 : 1)
        .setVisible(true);
    } else if (this.pressNowText) {
      this.pressNowText.setVisible(false);
    }
  }

  private drawHitZone(nextRemain: number, windowSeconds: number) {
    const x = this.surfer.x;
    const y = this.baselineY - 90;
    const near = Math.max(0, 1 - Math.abs(nextRemain) / windowSeconds);
    const ready = nextRemain > windowSeconds ? 0.25 : 0.55 + near * 0.45;
    const ringColor = near > 0.1 ? 0xfde047 : 0x93c5fd;
    this.markerGfx.lineStyle(4 + near * 4, ringColor, ready);
    this.markerGfx.strokeCircle(x, y, 42 + near * 8);
    this.markerGfx.lineStyle(2, 0xffffff, 0.35 + near * 0.45);
    this.markerGfx.beginPath();
    this.markerGfx.moveTo(x - 54, y);
    this.markerGfx.lineTo(x + 54, y);
    this.markerGfx.moveTo(x, y - 54);
    this.markerGfx.lineTo(x, y + 54);
    this.markerGfx.strokePath();
  }

  setAccuracyShake(v: number) { this.accuracyShake = v; }
}
