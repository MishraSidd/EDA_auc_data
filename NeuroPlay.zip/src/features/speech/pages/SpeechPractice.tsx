import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { WORD_SETS, type Difficulty } from "../data/words";
import { useSpeechRecognition } from "../hooks/useSpeechRecognition";
import { useSession } from "../hooks/useSession";
import { saveAttempt, scoreSpeech, type ScoreResult } from "../api/client";
import { DifficultyPicker } from "../components/DifficultyPicker";
import { WordCard } from "../components/WordCard";
import { MicButton } from "../components/MicButton";
import { ScoreDisplay } from "../components/ScoreDisplay";

const ATTEMPTS_PER_WORD = 3;

export default function SpeechPractice() {
  const sessionId = useSession();
  const [params, setParams] = useSearchParams();
  const initialDifficulty = (params.get("d") as Difficulty) || "easy";
  const initialWord = params.get("w");

  const [difficulty, setDifficulty] = useState<Difficulty>(initialDifficulty);
  const list = WORD_SETS[difficulty];
  const startIndex = Math.max(0, list.findIndex((w) => w.word === initialWord));
  const [index, setIndex] = useState<number>(startIndex >= 0 ? startIndex : 0);
  const [attempt, setAttempt] = useState(1);
  const [result, setResult] = useState<ScoreResult | null>(null);
  const [busy, setBusy] = useState(false);

  const sr = useSpeechRecognition("en-US");
  const current = list[index];

  // Reset progress when difficulty changes
  useEffect(() => {
    setIndex(0);
    setAttempt(1);
    setResult(null);
    sr.reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [difficulty]);

  // When recognition produces a transcript, score it via the edge function
  useEffect(() => {
    if (!sr.transcript || sr.recording || !current) return;
    let cancelled = false;
    setBusy(true);
    (async () => {
      try {
        const r = await scoreSpeech(current.word, sr.transcript);
        if (cancelled) return;
        setResult(r);
        await saveAttempt({
          session_id: sessionId,
          word: current.word,
          spoken: sr.transcript,
          score: r.score,
          difficulty,
        });
      } finally {
        if (!cancelled) setBusy(false);
      }
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sr.transcript, sr.recording]);

  const handleMic = () => {
    if (sr.recording) sr.stop();
    else {
      setResult(null);
      sr.start();
    }
  };

  const advanceWord = () => {
    setResult(null);
    sr.reset();
    setAttempt(1);
    setIndex((i) => (i + 1) % list.length);
  };

  const nextAttemptOrAdvance = () => {
    if (attempt >= ATTEMPTS_PER_WORD) {
      advanceWord();
    } else {
      setAttempt((a) => a + 1);
      setResult(null);
      sr.reset();
    }
  };

  const onDifficultyChange = (d: Difficulty) => {
    setDifficulty(d);
    setParams({ d });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h2 className="text-2xl font-semibold">Practice</h2>
        <DifficultyPicker value={difficulty} onChange={onDifficultyChange} />
      </div>

      {!sr.supported && (
        <div
          className="rounded-lg border p-3 text-sm"
          style={{ borderColor: "rgba(0,0,0,0.08)", background: "#FAEEDA", color: "#8a5a13" }}
        >
          Your browser does not support Web Speech Recognition. Try Chrome or Edge.
        </div>
      )}

      <WordCard
        word={current.word}
        phonetic={current.phonetic}
        attempt={attempt}
        totalAttempts={ATTEMPTS_PER_WORD}
      />

      <div className="flex flex-col items-center gap-3">
        <MicButton recording={sr.recording} disabled={!sr.supported || busy} onClick={handleMic} />
        <p className="text-sm text-[#5f5e5a]">
          {sr.recording ? "Listening…" : busy ? "Scoring…" : "Tap the mic and say the word"}
        </p>
        {sr.error && <p className="text-sm text-[#E24B4A]">{sr.error}</p>}
      </div>

      {result && (
        <ScoreDisplay score={result.score} spoken={sr.transcript} feedback={result.feedback} />
      )}

      <div className="flex gap-3 justify-end">
        {result && (
          <button
            type="button"
            onClick={nextAttemptOrAdvance}
            className="rounded-lg px-5 py-2 text-sm font-medium bg-[#1D9E75] text-white hover:bg-[#0F6E56] transition-colors"
          >
            {attempt >= ATTEMPTS_PER_WORD ? "Next word" : "Try again"}
          </button>
        )}
        <button
          type="button"
          onClick={advanceWord}
          className="rounded-lg px-5 py-2 text-sm font-medium border bg-white text-[#1a1a18] hover:bg-[#f0ede6] transition-colors"
          style={{ borderColor: "rgba(0,0,0,0.08)" }}
        >
          Skip word
        </button>
      </div>
    </div>
  );
}