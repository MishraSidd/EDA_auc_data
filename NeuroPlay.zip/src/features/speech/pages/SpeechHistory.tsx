import { useEffect, useMemo, useState } from "react";
import { listAttempts, type AttemptRow } from "../api/client";
import { useSession } from "../hooks/useSession";

export default function SpeechHistory() {
  const sessionId = useSession();
  const [rows, setRows] = useState<AttemptRow[]>([]);
  const [wordFilter, setWordFilter] = useState("");
  const [dateFilter, setDateFilter] = useState("");

  useEffect(() => {
    if (!sessionId) return;
    listAttempts(sessionId, 500).then(setRows).catch(() => {});
  }, [sessionId]);

  const filtered = useMemo(() => {
    return rows.filter((r) => {
      if (wordFilter && !r.word.toLowerCase().includes(wordFilter.toLowerCase())) return false;
      if (dateFilter) {
        const d = new Date(r.created_at).toISOString().slice(0, 10);
        if (d !== dateFilter) return false;
      }
      return true;
    });
  }, [rows, wordFilter, dateFilter]);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold">History</h2>
      <div className="flex flex-wrap gap-3">
        <input
          type="text"
          placeholder="Filter by word…"
          value={wordFilter}
          onChange={(e) => setWordFilter(e.target.value)}
          className="rounded-lg border bg-white px-3 py-2 text-sm"
          style={{ borderColor: "rgba(0,0,0,0.08)" }}
        />
        <input
          type="date"
          value={dateFilter}
          onChange={(e) => setDateFilter(e.target.value)}
          className="rounded-lg border bg-white px-3 py-2 text-sm"
          style={{ borderColor: "rgba(0,0,0,0.08)" }}
        />
        {(wordFilter || dateFilter) && (
          <button
            type="button"
            onClick={() => { setWordFilter(""); setDateFilter(""); }}
            className="text-sm text-[#0F6E56] hover:underline"
          >
            Clear
          </button>
        )}
      </div>

      <div
        className="rounded-xl border bg-white overflow-hidden"
        style={{ borderColor: "rgba(0,0,0,0.08)" }}
      >
        <table className="w-full text-sm">
          <thead className="bg-[#f0ede6] text-[#5f5e5a]">
            <tr>
              <th className="text-left px-4 py-2 font-medium">Word</th>
              <th className="text-left px-4 py-2 font-medium">You said</th>
              <th className="text-right px-4 py-2 font-medium">Score</th>
              <th className="text-right px-4 py-2 font-medium">When</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={4} className="px-4 py-8 text-center text-[#9a9890]">No attempts yet.</td></tr>
            )}
            {filtered.map((r) => (
              <tr key={r.id} className="border-t" style={{ borderColor: "rgba(0,0,0,0.06)" }}>
                <td className="px-4 py-2 font-medium">{r.word}</td>
                <td className="px-4 py-2 text-[#5f5e5a]">{r.spoken_text || "—"}</td>
                <td className="px-4 py-2 text-right">{r.score}%</td>
                <td className="px-4 py-2 text-right text-[#5f5e5a]">
                  {new Date(r.created_at).toLocaleString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}