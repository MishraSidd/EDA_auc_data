import { useEffect, useMemo, useState } from "react";
import { listAttempts, type AttemptRow } from "../api/client";
import { useSession } from "../hooks/useSession";
import { StatCard } from "../components/StatCard";
import { TrendChart } from "../components/TrendChart";

export default function SpeechProgress() {
  const sessionId = useSession();
  const [rows, setRows] = useState<AttemptRow[]>([]);

  useEffect(() => {
    if (!sessionId) return;
    listAttempts(sessionId, 500).then(setRows).catch(() => {});
  }, [sessionId]);

  const total = rows.length;
  const avg = total ? Math.round(rows.reduce((s, r) => s + r.score, 0) / total) : 0;
  const best = rows.reduce((m, r) => Math.max(m, r.score), 0);

  const trend = useMemo(() => {
    const last10 = [...rows].slice(0, 10).reverse();
    return last10.map((r, i) => ({ label: `#${i + 1}`, score: r.score }));
  }, [rows]);

  const perWord = useMemo(() => {
    const map = new Map<string, { total: number; sum: number; best: number }>();
    for (const r of rows) {
      const cur = map.get(r.word) ?? { total: 0, sum: 0, best: 0 };
      cur.total += 1;
      cur.sum += r.score;
      cur.best = Math.max(cur.best, r.score);
      map.set(r.word, cur);
    }
    return Array.from(map.entries())
      .map(([word, v]) => ({ word, attempts: v.total, avg: Math.round(v.sum / v.total), best: v.best }))
      .sort((a, b) => b.attempts - a.attempts);
  }, [rows]);

  const grouped = useMemo(() => {
    const m = new Map<string, AttemptRow[]>();
    for (const r of rows) {
      const key = new Date(r.created_at).toISOString().slice(0, 10);
      const list = m.get(key) ?? [];
      list.push(r);
      m.set(key, list);
    }
    return Array.from(m.entries()).sort(([a], [b]) => (a < b ? 1 : -1));
  }, [rows]);

  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-semibold">Progress</h2>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatCard label="Total attempts" value={total} />
        <StatCard label="Avg accuracy" value={`${avg}%`} />
        <StatCard label="Best score" value={`${best}%`} />
      </section>

      <section
        className="rounded-xl border bg-white p-5"
        style={{ borderColor: "rgba(0,0,0,0.08)" }}
      >
        <h3 className="text-sm uppercase tracking-wider text-[#5f5e5a] mb-4">Recent trend</h3>
        <TrendChart scores={trend} />
      </section>

      <section>
        <h3 className="text-sm uppercase tracking-wider text-[#5f5e5a] mb-3">Per-word performance</h3>
        <div className="rounded-xl border bg-white overflow-hidden" style={{ borderColor: "rgba(0,0,0,0.08)" }}>
          <table className="w-full text-sm">
            <thead className="bg-[#f0ede6] text-[#5f5e5a]">
              <tr>
                <th className="text-left px-4 py-2 font-medium">Word</th>
                <th className="text-right px-4 py-2 font-medium">Attempts</th>
                <th className="text-left px-4 py-2 font-medium">Average</th>
                <th className="text-right px-4 py-2 font-medium">Best</th>
              </tr>
            </thead>
            <tbody>
              {perWord.length === 0 && (
                <tr><td colSpan={4} className="px-4 py-8 text-center text-[#9a9890]">No data yet.</td></tr>
              )}
              {perWord.map((w) => (
                <tr key={w.word} className="border-t" style={{ borderColor: "rgba(0,0,0,0.06)" }}>
                  <td className="px-4 py-2 font-medium">{w.word}</td>
                  <td className="px-4 py-2 text-right">{w.attempts}</td>
                  <td className="px-4 py-2">
                    <div className="flex items-center gap-2">
                      <div className="h-2 w-32 rounded-full bg-[#f0ede6] overflow-hidden">
                        <div className="h-full bg-[#1D9E75]" style={{ width: `${w.avg}%` }} />
                      </div>
                      <span className="text-xs text-[#5f5e5a]">{w.avg}%</span>
                    </div>
                  </td>
                  <td className="px-4 py-2 text-right">{w.best}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section>
        <h3 className="text-sm uppercase tracking-wider text-[#5f5e5a] mb-3">Sessions by day</h3>
        <div className="space-y-3">
          {grouped.length === 0 && <p className="text-sm text-[#9a9890]">No sessions yet.</p>}
          {grouped.map(([day, items]) => {
            const dayAvg = Math.round(items.reduce((s, r) => s + r.score, 0) / items.length);
            return (
              <div
                key={day}
                className="rounded-xl border bg-white p-4 flex items-center justify-between"
                style={{ borderColor: "rgba(0,0,0,0.08)" }}
              >
                <div>
                  <p className="font-medium">{new Date(day).toLocaleDateString(undefined, { weekday: "long", month: "short", day: "numeric" })}</p>
                  <p className="text-xs text-[#5f5e5a]">{items.length} attempt{items.length === 1 ? "" : "s"}</p>
                </div>
                <div className="text-2xl font-semibold text-[#0F6E56]">{dayAvg}%</div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}