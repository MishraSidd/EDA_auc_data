import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { allWords } from "../data/words";
import { listAttempts, type AttemptRow } from "../api/client";
import { useSession } from "../hooks/useSession";

export default function SpeechWords() {
  const sessionId = useSession();
  const [rows, setRows] = useState<AttemptRow[]>([]);

  useEffect(() => {
    if (!sessionId) return;
    listAttempts(sessionId).then(setRows).catch(() => {});
  }, [sessionId]);

  const bestByWord = useMemo(() => {
    const m = new Map<string, number>();
    for (const r of rows) m.set(r.word, Math.max(m.get(r.word) ?? 0, r.score));
    return m;
  }, [rows]);

  const grouped = useMemo(() => {
    const all = allWords();
    return {
      easy: all.filter((w) => w.difficulty === "easy"),
      medium: all.filter((w) => w.difficulty === "medium"),
      hard: all.filter((w) => w.difficulty === "hard"),
    };
  }, []);

  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-semibold">Word library</h2>
      {(["easy", "medium", "hard"] as const).map((d) => (
        <section key={d}>
          <h3 className="text-sm uppercase tracking-wider text-[#5f5e5a] mb-3">{d}</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {grouped[d].map((w) => {
              const best = bestByWord.get(w.word);
              return (
                <Link
                  key={w.word}
                  to={`/speech/practice?d=${d}&w=${encodeURIComponent(w.word)}`}
                  className="rounded-xl border bg-white p-4 hover:bg-[#f0ede6] transition-colors"
                  style={{ borderColor: "rgba(0,0,0,0.08)" }}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-base font-medium text-[#1a1a18]">{w.word}</span>
                    {best !== undefined && (
                      <span
                        className="text-xs px-2 py-0.5 rounded-full"
                        style={{ background: "#E1F5EE", color: "#0F6E56" }}
                      >
                        {best}%
                      </span>
                    )}
                  </div>
                  <p className="mt-1 text-xs text-[#5f5e5a]">{w.phonetic}</p>
                </Link>
              );
            })}
          </div>
        </section>
      ))}
    </div>
  );
}