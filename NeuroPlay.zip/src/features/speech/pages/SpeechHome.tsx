import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { listAttempts, type AttemptRow } from "../api/client";
import { useSession } from "../hooks/useSession";
import { StatCard } from "../components/StatCard";

function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x.getTime();
}

function computeStreak(rows: AttemptRow[]): number {
  if (!rows.length) return 0;
  const days = new Set(rows.map((r) => startOfDay(new Date(r.created_at))));
  let streak = 0;
  let cursor = startOfDay(new Date());
  while (days.has(cursor)) {
    streak++;
    cursor -= 86400000;
  }
  return streak;
}

export default function SpeechHome() {
  const sessionId = useSession();
  const [rows, setRows] = useState<AttemptRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!sessionId) return;
    listAttempts(sessionId).then((r) => {
      setRows(r);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [sessionId]);

  const today = startOfDay(new Date());
  const todays = rows.filter((r) => startOfDay(new Date(r.created_at)) === today);
  const todayAvg = todays.length
    ? Math.round(todays.reduce((s, r) => s + r.score, 0) / todays.length)
    : 0;
  const best = rows.reduce((m, r) => Math.max(m, r.score), 0);
  const streak = computeStreak(rows);

  return (
    <div className="space-y-8">
      <section>
        <h2 className="text-2xl font-semibold mb-1">Welcome back</h2>
        <p className="text-[#5f5e5a]">A calm, steady practice space for your voice.</p>
      </section>

      <section className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Today's avg" value={loading ? "…" : `${todayAvg}%`} hint={`${todays.length} attempts today`} />
        <StatCard label="Total attempts" value={loading ? "…" : rows.length} />
        <StatCard label="Best score" value={loading ? "…" : `${best}%`} />
        <StatCard label="Streak" value={loading ? "…" : `${streak} day${streak === 1 ? "" : "s"}`} />
      </section>

      <section>
        <Link
          to="/speech/practice"
          className="inline-flex items-center justify-center rounded-lg px-6 py-3 text-base font-medium bg-[#1D9E75] text-white hover:bg-[#0F6E56] transition-colors"
        >
          Start a practice session
        </Link>
      </section>
    </div>
  );
}