// Word sets for the Speech Recovery Tracker, with simple IPA-style phonetic hints.
export type Difficulty = "easy" | "medium" | "hard";

export interface PracticeWord {
  word: string;
  phonetic: string;
}

export const WORD_SETS: Record<Difficulty, PracticeWord[]> = {
  easy: [
    { word: "Water", phonetic: "/ ˈwɔː.tər /" },
    { word: "Apple", phonetic: "/ ˈæp.əl /" },
    { word: "Hello", phonetic: "/ həˈloʊ /" },
    { word: "Book",  phonetic: "/ bʊk /" },
    { word: "Door",  phonetic: "/ dɔːr /" },
    { word: "Cat",   phonetic: "/ kæt /" },
    { word: "Sun",   phonetic: "/ sʌn /" },
    { word: "Tree",  phonetic: "/ triː /" },
  ],
  medium: [
    { word: "Butter", phonetic: "/ ˈbʌt.ər /" },
    { word: "Purple", phonetic: "/ ˈpɜːr.pəl /" },
    { word: "Bottle", phonetic: "/ ˈbɒt.əl /" },
    { word: "Turtle", phonetic: "/ ˈtɜːr.təl /" },
    { word: "Gentle", phonetic: "/ ˈdʒen.təl /" },
    { word: "Simple", phonetic: "/ ˈsɪm.pəl /" },
  ],
  hard: [
    { word: "Thermometer",   phonetic: "/ θərˈmɑː.mə.tər /" },
    { word: "Strawberry",    phonetic: "/ ˈstrɔː.ber.i /" },
    { word: "Comfortable",   phonetic: "/ ˈkʌmf.tə.bəl /" },
    { word: "Particularly",  phonetic: "/ pərˈtɪk.jə.lər.li /" },
    { word: "Veterinarian",  phonetic: "/ ˌvet.ər.əˈner.i.ən /" },
  ],
};

export function allWords(): { word: string; phonetic: string; difficulty: Difficulty }[] {
  return (Object.keys(WORD_SETS) as Difficulty[]).flatMap((d) =>
    WORD_SETS[d].map((w) => ({ ...w, difficulty: d })),
  );
}