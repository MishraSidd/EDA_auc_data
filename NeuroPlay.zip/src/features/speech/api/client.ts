// API client for Speech Recovery Tracker. Uses a Supabase Edge Function for
// the Jaro-Winkler scoring math and the Lovable Cloud database for persistence.
import { supabase } from "@/integrations/supabase/client";
import type { Difficulty } from "../data/words";

export interface ScoreResult {
  score: number;
  feedback: string;
}

export interface AttemptRow {
  id: string;
  session_id: string;
  word: string;
  spoken_text: string;
  score: number;
  difficulty: string;
  created_at: string;
}

export async function scoreSpeech(target: string, spoken: string): Promise<ScoreResult> {
  const { data, error } = await supabase.functions.invoke("score-speech", {
    body: { target, spoken },
  });
  if (error) throw error;
  return data as ScoreResult;
}

export async function saveAttempt(input: {
  session_id: string;
  word: string;
  spoken: string;
  score: number;
  difficulty: Difficulty;
}): Promise<void> {
  const { error } = await supabase.from("speech_attempts").insert({
    session_id: input.session_id,
    word: input.word,
    spoken_text: input.spoken,
    score: input.score,
    difficulty: input.difficulty,
  });
  if (error) throw error;
}

export async function listAttempts(sessionId: string, limit = 200): Promise<AttemptRow[]> {
  const { data, error } = await supabase
    .from("speech_attempts")
    .select("*")
    .eq("session_id", sessionId)
    .order("created_at", { ascending: false })
    .limit(limit);
  if (error) throw error;
  return (data ?? []) as AttemptRow[];
}