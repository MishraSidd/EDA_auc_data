// Shared layout/nav for all /speech/* pages.
import { NavLink, Outlet } from "react-router-dom";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/speech", label: "Home", end: true },
  { to: "/speech/practice", label: "Practice" },
  { to: "/speech/words", label: "Words" },
  { to: "/speech/history", label: "History" },
  { to: "/speech/progress", label: "Progress" },
];

export default function SpeechLayout() {
  return (
    <div className="min-h-screen" style={{ background: "#f7f6f2", color: "#1a1a18", fontFamily: "Inter, ui-sans-serif, system-ui" }}>
      <header className="border-b bg-white" style={{ borderColor: "rgba(0,0,0,0.08)" }}>
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2">
            <span className="inline-block h-3 w-3 rounded-full bg-[#1D9E75]" />
            <h1 className="text-lg font-semibold">Speech Recovery Tracker</h1>
          </div>
          <nav className="flex gap-1">
            {NAV.map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                end={n.end}
                className={({ isActive }) =>
                  cn(
                    "px-3 py-1.5 rounded-md text-sm transition-colors",
                    isActive ? "bg-[#E1F5EE] text-[#0F6E56]" : "text-[#5f5e5a] hover:bg-[#f0ede6]",
                  )
                }
              >
                {n.label}
              </NavLink>
            ))}
          </nav>
        </div>
      </header>
      <main className="max-w-5xl mx-auto px-4 py-8">
        <Outlet />
      </main>
    </div>
  );
}