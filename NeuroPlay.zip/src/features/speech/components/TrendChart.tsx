// Recharts bar chart of the most recent N attempt scores.
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

interface Props {
  scores: { label: string; score: number }[];
}

export function TrendChart({ scores }: Props) {
  if (!scores.length) {
    return <div className="text-sm text-[#5f5e5a] italic">No attempts yet — start practicing!</div>;
  }
  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={scores}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.08)" />
          <XAxis dataKey="label" stroke="#5f5e5a" fontSize={11} />
          <YAxis domain={[0, 100]} stroke="#5f5e5a" fontSize={11} />
          <Tooltip contentStyle={{ background: "#ffffff", border: "1px solid rgba(0,0,0,0.08)", borderRadius: 8, fontSize: 12 }} />
          <Bar dataKey="score" fill="#1D9E75" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}