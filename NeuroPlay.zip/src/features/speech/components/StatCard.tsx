interface Props {
  label: string;
  value: string | number;
  hint?: string;
}

export function StatCard({ label, value, hint }: Props) {
  return (
    <div className="rounded-xl border p-5 bg-white" style={{ borderColor: "rgba(0,0,0,0.08)" }}>
      <p className="text-xs uppercase tracking-wider text-[#9a9890]">{label}</p>
      <p className="mt-2 text-3xl font-semibold text-[#1a1a18]">{value}</p>
      {hint && <p className="mt-1 text-xs text-[#5f5e5a]">{hint}</p>}
    </div>
  );
}