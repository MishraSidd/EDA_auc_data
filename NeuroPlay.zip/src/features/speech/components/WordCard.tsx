// Target word with phonetic hint and attempt counter.
interface Props {
  word: string;
  phonetic: string;
  attempt: number;
  totalAttempts: number;
}

export function WordCard({ word, phonetic, attempt, totalAttempts }: Props) {
  return (
    <div className="rounded-xl border p-8 text-center" style={{ background: "#ffffff", borderColor: "rgba(0,0,0,0.08)" }}>
      <p className="text-xs uppercase tracking-wider text-[#9a9890] mb-2">
        Attempt {attempt} of {totalAttempts}
      </p>
      <h2 className="text-5xl font-semibold text-[#1a1a18]">{word}</h2>
      <p className="mt-3 text-base text-[#5f5e5a]">{phonetic}</p>
    </div>
  );
}