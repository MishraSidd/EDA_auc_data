// Animated microphone button. Pulses while recording.
import { Mic, Square } from "lucide-react";
import { cn } from "@/lib/utils";

interface Props {
  recording: boolean;
  disabled?: boolean;
  onClick: () => void;
}

export function MicButton({ recording, disabled, onClick }: Props) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-label={recording ? "Stop recording" : "Start recording"}
      className={cn(
        "relative inline-flex items-center justify-center rounded-full transition-colors",
        "h-24 w-24 border border-[#1D9E75]/30",
        recording ? "bg-[#E24B4A] text-white" : "bg-[#1D9E75] text-white hover:bg-[#0F6E56]",
        disabled && "opacity-50 cursor-not-allowed",
      )}
    >
      {recording && <span className="absolute inset-0 rounded-full animate-ping bg-[#E24B4A]/40" />}
      {recording ? <Square className="!h-8 !w-8" /> : <Mic className="!h-8 !w-8" />}
    </button>
  );
}