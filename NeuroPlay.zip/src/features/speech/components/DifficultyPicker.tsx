import type { Difficulty } from "../data/words";
import { cn } from "@/lib/utils";

interface Props {
  value: Difficulty;
  onChange: (d: Difficulty) => void;
}

const OPTIONS: { value: Difficulty; label: string }[] = [
  { value: "easy", label: "Easy" },
  { value: "medium", label: "Medium" },
  { value: "hard", label: "Hard" },
];

export function DifficultyPicker({ value, onChange }: Props) {
  return (
    <div className="inline-flex rounded-lg border p-1 bg-white" style={{ borderColor: "rgba(0,0,0,0.08)" }}>
      {OPTIONS.map((o) => (
        <button
          key={o.value}
          type="button"
          onClick={() => onChange(o.value)}
          className={cn(
            "px-4 py-1.5 text-sm rounded-md transition-colors",
            value === o.value ? "bg-[#1D9E75] text-white" : "text-[#5f5e5a] hover:bg-[#f0ede6]",
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}