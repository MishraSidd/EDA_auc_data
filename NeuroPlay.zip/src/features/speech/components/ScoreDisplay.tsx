// Big % score, color-coded bar, feedback line.
interface Props {
  score: number;
  spoken: string;
  feedback: string;
}

function bandColor(score: number) {
  if (score >= 80) return { bar: "#1D9E75", bg: "#E1F5EE", text: "#0F6E56" };
  if (score >= 50) return { bar: "#EF9F27", bg: "#FAEEDA", text: "#8a5a13" };
  return { bar: "#E24B4A", bg: "#FCEBEB", text: "#8a2a29" };
}

export function ScoreDisplay({ score, spoken, feedback }: Props) {
  const c = bandColor(score);
  return (
    <div className="rounded-xl border p-5" style={{ borderColor: "rgba(0,0,0,0.08)", background: c.bg }}>
      <p className="text-sm text-[#5f5e5a]">You said:</p>
      <p className="text-lg font-medium text-[#1a1a18] mb-3 break-words">
        {spoken || <span className="text-[#9a9890]">— nothing yet —</span>}
      </p>
      <div className="flex items-baseline gap-2">
        <span className="text-5xl font-semibold" style={{ color: c.text }}>{score}</span>
        <span className="text-xl" style={{ color: c.text }}>%</span>
      </div>
      <div className="mt-3 h-2 w-full rounded-full bg-white/70 overflow-hidden">
        <div className="h-full rounded-full transition-all" style={{ width: `${score}%`, background: c.bar }} />
      </div>
      <p className="mt-3 text-sm" style={{ color: c.text }}>{feedback}</p>
    </div>
  );
}