// Generates and persists an anonymous session id in localStorage so attempts
// can be grouped per device without requiring login.
import { useEffect, useState } from "react";

const KEY = "speechRecoverySessionId";

function genId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `s_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
}

export function useSession(): string {
  const [id, setId] = useState<string>(() => {
    if (typeof window === "undefined") return "";
    const existing = window.localStorage.getItem(KEY);
    if (existing) return existing;
    const fresh = genId();
    window.localStorage.setItem(KEY, fresh);
    return fresh;
  });

  useEffect(() => {
    if (!id) {
      const fresh = genId();
      window.localStorage.setItem(KEY, fresh);
      setId(fresh);
    }
  }, [id]);

  return id;
}