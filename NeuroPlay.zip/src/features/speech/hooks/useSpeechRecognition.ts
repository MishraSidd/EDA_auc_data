// Thin wrapper around the browser Web Speech API. Returns the raw transcript;
// the backend handles similarity scoring (no autocorrect).
import { useCallback, useEffect, useRef, useState } from "react";

export interface UseSpeechRecognition {
  supported: boolean;
  recording: boolean;
  transcript: string;
  error: string | null;
  start: () => void;
  stop: () => void;
  reset: () => void;
}

export function useSpeechRecognition(lang = "en-US"): UseSpeechRecognition {
  const [supported, setSupported] = useState(false);
  const [recording, setRecording] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [error, setError] = useState<string | null>(null);
  const recRef = useRef<any>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const Ctor = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!Ctor) {
      setSupported(false);
      return;
    }
    setSupported(true);
    const rec = new Ctor();
    rec.lang = lang;
    rec.continuous = false;
    rec.interimResults = false;
    rec.maxAlternatives = 1;
    rec.onresult = (e: any) => {
      const text = e?.results?.[0]?.[0]?.transcript ?? "";
      setTranscript(text);
    };
    rec.onerror = (e: any) => {
      setError(e?.error || "Speech recognition error");
      setRecording(false);
    };
    rec.onend = () => setRecording(false);
    recRef.current = rec;
    return () => {
      try { rec.abort(); } catch { /* noop */ }
    };
  }, [lang]);

  const start = useCallback(() => {
    if (!recRef.current) return;
    setError(null);
    setTranscript("");
    try {
      recRef.current.start();
      setRecording(true);
    } catch (e: any) {
      setError(String(e?.message ?? e));
    }
  }, []);

  const stop = useCallback(() => {
    try { recRef.current?.stop(); } catch { /* noop */ }
    setRecording(false);
  }, []);

  const reset = useCallback(() => {
    setTranscript("");
    setError(null);
  }, []);

  return { supported, recording, transcript, error, start, stop, reset };
}