export interface TremorPoint { x: number; y: number; t: number; }

export interface TremorResult {
  smoothness: number;        // 0–100, higher = smoother
  deviation: number;         // 0–100, higher = more deviation from ideal ∞
  velocityVariation: number; // 0–100, higher = more jitter
  pointCount: number;
}

// Pure analysis. No external libs.
export function analyzeTremor(points: TremorPoint[]): TremorResult {
  if (points.length < 10) {
    return { smoothness: 0, deviation: 100, velocityVariation: 100, pointCount: points.length };
  }

  // Velocities between consecutive points
  const velocities: number[] = [];
  for (let i = 1; i < points.length; i++) {
    const dx = points[i].x - points[i - 1].x;
    const dy = points[i].y - points[i - 1].y;
    const dt = Math.max(1, points[i].t - points[i - 1].t);
    velocities.push(Math.hypot(dx, dy) / dt);
  }

  const meanV = velocities.reduce((a, b) => a + b, 0) / velocities.length;
  const varV =
    velocities.reduce((a, b) => a + (b - meanV) ** 2, 0) / velocities.length;
  const stdV = Math.sqrt(varV);
  const cv = meanV > 0 ? stdV / meanV : 1; // coefficient of variation
  const velocityVariation = Math.min(100, Math.round(cv * 100));

  // Smoothness via angular jitter (sum of |angle changes|)
  let angleSum = 0;
  let angleCount = 0;
  for (let i = 2; i < points.length; i++) {
    const a1 = Math.atan2(points[i - 1].y - points[i - 2].y, points[i - 1].x - points[i - 2].x);
    const a2 = Math.atan2(points[i].y - points[i - 1].y, points[i].x - points[i - 1].x);
    let d = Math.abs(a2 - a1);
    if (d > Math.PI) d = 2 * Math.PI - d;
    angleSum += d;
    angleCount++;
  }
  const meanAngle = angleSum / Math.max(1, angleCount); // radians per step
  // Lower mean angle => smoother. Map ~0..1.5 rad → 100..0.
  const smoothness = Math.max(0, Math.min(100, Math.round(100 - (meanAngle / 1.2) * 100)));

  // Deviation from ideal ∞: fit bbox, compare ideal lemniscate samples to nearest point distances
  const xs = points.map((p) => p.x);
  const ys = points.map((p) => p.y);
  const minX = Math.min(...xs), maxX = Math.max(...xs);
  const minY = Math.min(...ys), maxY = Math.max(...ys);
  const cx = (minX + maxX) / 2, cy = (minY + maxY) / 2;
  const w = Math.max(1, (maxX - minX) / 2);
  const h = Math.max(1, (maxY - minY) / 2);

  let totalErr = 0;
  const samples = 60;
  for (let i = 0; i < samples; i++) {
    const t = (i / samples) * 2 * Math.PI;
    // Lemniscate of Gerono parametrisation
    const ix = cx + w * Math.cos(t);
    const iy = cy + h * Math.sin(t) * Math.cos(t);
    let nearest = Infinity;
    for (const p of points) {
      const d = Math.hypot(p.x - ix, p.y - iy);
      if (d < nearest) nearest = d;
    }
    totalErr += nearest;
  }
  const meanErr = totalErr / samples;
  const norm = (w + h) / 2;
  const deviation = Math.min(100, Math.round((meanErr / norm) * 100));

  return {
    smoothness,
    deviation,
    velocityVariation,
    pointCount: points.length,
  };
}