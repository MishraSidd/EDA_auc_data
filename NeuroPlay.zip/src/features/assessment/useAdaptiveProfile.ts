import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { AdaptiveProfile } from "./scoringEngine";

const DEFAULT_PROFILE: AdaptiveProfile = {
  previewMs: 3000,
  distractorCount: 17,
  targetSize: "md",
  sessionLengthMin: 15,
  recommendBreaks: false,
};

export function getUserId(): string {
  let id = localStorage.getItem("np_session_id");
  if (!id) {
    id = `u_${Math.random().toString(36).slice(2, 10)}`;
    localStorage.setItem("np_session_id", id);
  }
  return id;
}

export function useAdaptiveProfile() {
  const [profile, setProfile] = useState<AdaptiveProfile>(DEFAULT_PROFILE);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const userId = getUserId();
    supabase
      .from("assessments")
      .select("adaptive_profile")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(1)
      .then(({ data }) => {
        const ap = data?.[0]?.adaptive_profile as unknown as AdaptiveProfile | undefined;
        if (ap && typeof ap === "object") {
          setProfile({ ...DEFAULT_PROFILE, ...ap });
        }
        setLoaded(true);
      });
  }, []);

  return { profile, loaded };
}