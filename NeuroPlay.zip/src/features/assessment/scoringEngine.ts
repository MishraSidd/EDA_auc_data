// Pure-logic adaptive scoring. No AI, no external API.
// All scores 0–100. Higher = better, except fatigue_sensitivity (higher = more fatigue).

export interface QuestionnaireAnswers {
  condition?: string;
  side?: string;
  daily?: string[];
  memory?: string[];
  comms?: string[];
  fatigue?: string;
  mood?: string;
}

export interface TremorMetrics {
  smoothness: number;       // 0–100
  deviation: number;        // 0–100 (lower = better path adherence)
  velocityVariation: number;// 0–100 (lower = steadier)
}

export interface RehabMetrics {
  motor_stability: number;
  cognitive_focus: number;
  communication_confidence: number;
  fatigue_sensitivity: number;
  memory_index: number;
  adaptation_level: number;
}

export interface AdaptiveProfile {
  previewMs: number;       // memory preview duration
  distractorCount: number; // 0–17 distractors in 20-tile grid
  targetSize: "sm" | "md" | "lg";
  sessionLengthMin: number;
  recommendBreaks: boolean;
}

const clamp = (n: number, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, Math.round(n)));

const fatigueMap: Record<string, number> = {
  Rarely: 20,
  Sometimes: 45,
  Frequently: 70,
  Constantly: 90,
};

const moodBoost: Record<string, number> = {
  Motivated: 10,
  Frustrated: -5,
  Anxious: -5,
  "Low confidence": -10,
};

export function computeMetrics(
  q: QuestionnaireAnswers,
  tremor?: TremorMetrics,
  gameAvgAccuracy = 0,
  speechAvg = 0,
  recallAvg = 0,
): RehabMetrics {
  const dailyHits = q.daily?.length ?? 0;
  const memHits = (q.memory ?? []).filter((x) => x !== "No major issue").length;
  const commsHits = (q.comms ?? []).filter((x) => x !== "No major issue").length;

  const sidePenalty = q.side === "Both" ? 20 : q.side === "Not sure" ? 10 : 8;
  const tremorPenalty = tremor ? (100 - tremor.smoothness) * 0.4 : 0;

  const motor_stability = clamp(
    95 - dailyHits * 8 - sidePenalty - tremorPenalty + (moodBoost[q.mood ?? ""] ?? 0),
  );

  const cognitive_focus = clamp(
    85 - memHits * 10 - commsHits * 4 + gameAvgAccuracy * 0.3,
  );

  const communication_confidence = clamp(
    90 - commsHits * 15 + speechAvg * 0.4,
  );

  const fatigue_sensitivity = clamp(fatigueMap[q.fatigue ?? "Sometimes"] ?? 50);

  const memory_index = clamp(
    recallAvg > 0 ? recallAvg : 75 - memHits * 12,
  );

  const adaptation_level = clamp(
    (cognitive_focus + motor_stability + memory_index) / 3 - fatigue_sensitivity * 0.2,
  );

  return {
    motor_stability,
    cognitive_focus,
    communication_confidence,
    fatigue_sensitivity,
    memory_index,
    adaptation_level,
  };
}

export function deriveProfile(m: RehabMetrics): AdaptiveProfile {
  // Preview time: lower cognitive focus => more time
  const previewMs = m.cognitive_focus < 40 ? 5000 : m.cognitive_focus < 70 ? 4000 : 3000;
  // Distractors: lower memory index => fewer distractors
  const distractorCount = m.memory_index < 40 ? 9 : m.memory_index < 70 ? 13 : 17;
  // Target size: lower motor stability => bigger targets
  const targetSize: AdaptiveProfile["targetSize"] =
    m.motor_stability < 50 ? "lg" : m.motor_stability < 75 ? "md" : "sm";
  // Session length: higher fatigue => shorter
  const sessionLengthMin = m.fatigue_sensitivity > 75 ? 5 : m.fatigue_sensitivity > 50 ? 10 : 15;
  const recommendBreaks = m.fatigue_sensitivity > 60;
  return { previewMs, distractorCount, targetSize, sessionLengthMin, recommendBreaks };
}

// Rule-based, non-medical personalization summary.
// Each recommendation is framed as a comfort/therapy adaptation, never a diagnosis.
export interface Recommendation {
  id: string;
  title: string;
  detail: string;
}

export function generateRecommendations(
  m: RehabMetrics,
  p: AdaptiveProfile,
  tremor?: TremorMetrics,
): Recommendation[] {
  const out: Recommendation[] = [];

  if (m.memory_index < 55) {
    out.push({
      id: "memory-guided",
      title: "Guided memory exercises",
      detail: `Memory Recall starts with ${p.distractorCount + 3} tiles and a ${Math.round(p.previewMs / 1000)}s preview so patterns stay easier to hold.`,
    });
  } else if (m.memory_index >= 80) {
    out.push({
      id: "memory-stretch",
      title: "Stretch your recall",
      detail: "We'll keep distractors high and previews short to keep recall challenging.",
    });
  }

  if (m.fatigue_sensitivity > 60) {
    out.push({
      id: "fatigue-pacing",
      title: "Shorter, calmer sessions",
      detail: `Suggested session length is around ${p.sessionLengthMin} minutes with built-in breaks between games.`,
    });
  }

  if (m.motor_stability < 60 || (tremor && tremor.smoothness < 60)) {
    out.push({
      id: "motor-targets",
      title: "Larger, easier-to-tap targets",
      detail: "Buttons and tiles are sized up so small hand movements still register accurately.",
    });
  }

  if (m.communication_confidence < 60) {
    out.push({
      id: "comms-speech",
      title: "Gentle speech warm-ups",
      detail: "Speech Recovery will start at the easiest difficulty and grow as you feel ready.",
    });
  }

  if (m.cognitive_focus < 50) {
    out.push({
      id: "focus-simplify",
      title: "Reduced visual load",
      detail: "Fewer items on screen at once, so attention stays on one thing at a time.",
    });
  }

  if (out.length === 0) {
    out.push({
      id: "balanced",
      title: "Balanced plan",
      detail: "Your responses suggest a balanced setup — standard pacing and target sizes.",
    });
  }

  return out;
}