export type OnboardingAnswer = string | string[];

export interface OnboardingQuestion {
  id: string;
  title: string;
  helper: string;
  multi: boolean;
  options: string[];
}

export const onboardingQuestions: OnboardingQuestion[] = [
  {
    id: "condition",
    title: "Which neurological condition applies to you?",
    helper: "Choose the one that best describes your situation.",
    multi: false,
    options: [
      "Ischaemic Stroke",
      "Haemorrhagic Stroke",
      "TBI",
      "Anoxic Brain Injury",
      "Tumour-related Injury",
      "Multiple Sclerosis",
      "Other / Not Sure",
    ],
  },
  {
    id: "side",
    title: "Which side of your body is most affected?",
    helper: "It's okay to pick the closest answer.",
    multi: false,
    options: ["Right side", "Left side", "Both", "Not sure"],
  },
  {
    id: "daily",
    title: "Which daily activities are challenging right now?",
    helper: "Select all that apply — your honesty helps us help you.",
    multi: true,
    options: ["Eating", "Holding objects", "Walking", "Dressing", "Phone usage"],
  },
  {
    id: "memory",
    title: "How is your memory feeling lately?",
    helper: "There are no wrong answers.",
    multi: true,
    options: [
      "Forgetting steps",
      "Forgetting objects",
      "Trouble focusing",
      "No major issue",
    ],
  },
  {
    id: "comms",
    title: "Any communication difficulties?",
    helper: "These help us tailor the speech exercises.",
    multi: true,
    options: [
      "Slurred speech",
      "Word finding difficulty",
      "Slow speech",
      "No major issue",
    ],
  },
  {
    id: "fatigue",
    title: "How often do you feel fatigued?",
    helper: "We'll adjust your session length accordingly.",
    multi: false,
    options: ["Rarely", "Sometimes", "Frequently", "Constantly"],
  },
  {
    id: "mood",
    title: "How would you describe your motivation today?",
    helper: "Your emotional state matters in recovery.",
    multi: false,
    options: ["Motivated", "Frustrated", "Anxious", "Low confidence"],
  },
];