import { useCallback, useEffect, useRef, useState } from "react";

/**
 * Lightweight wrapper around the browser SpeechSynthesis API.
 * No API key needed — works offline, instant playback.
 */
export function useSpeech() {
  const [supported] = useState(
    () => typeof window !== "undefined" && "speechSynthesis" in window,
  );
  const [speaking, setSpeaking] = useState(false);
  const utterRef = useRef<SpeechSynthesisUtterance | null>(null);

  const cancel = useCallback(() => {
    if (!supported) return;
    window.speechSynthesis.cancel();
    setSpeaking(false);
  }, [supported]);

  const speak = useCallback(
    (text: string, opts?: { rate?: number; pitch?: number }) => {
      if (!supported || !text) return;
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.rate = opts?.rate ?? 0.95;
      u.pitch = opts?.pitch ?? 1;
      u.lang = "en-US";
      u.onstart = () => setSpeaking(true);
      u.onend = () => setSpeaking(false);
      u.onerror = () => setSpeaking(false);
      utterRef.current = u;
      window.speechSynthesis.speak(u);
    },
    [supported],
  );

  // Cancel on unmount
  useEffect(() => () => cancel(), [cancel]);

  return { speak, cancel, speaking, supported };
}
