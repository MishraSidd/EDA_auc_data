import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { getUserId } from "@/features/assessment/useAdaptiveProfile";

export interface DashboardStats {
  totalSessions: number;
  overallAccuracy: number | null;
  streakDays: number;
  speechAvg: number | null;
  perGame: Record<string, number | null>;
  activeDays: boolean[]; // length 7, Mon..Sun for current week
  lastPlayed: string | null;
  hasAnyData: boolean;
}

const EMPTY: DashboardStats = {
  totalSessions: 0,
  overallAccuracy: null,
  streakDays: 0,
  speechAvg: null,
  perGame: {},
  activeDays: [false, false, false, false, false, false, false],
  lastPlayed: null,
  hasAnyData: false,
};

export function useDashboardStats() {
  const [stats, setStats] = useState<DashboardStats>(EMPTY);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const userId = getUserId();
      const [gamesRes, speechRes] = await Promise.all([
        supabase
          .from("game_sessions")
          .select("score,accuracy,accuracy_percent,game,game_name,played_at,created_at")
          .eq("user_id", userId)
          .order("played_at", { ascending: false }),
        supabase
          .from("speech_sessions")
          .select("avg_score,session_date,created_at")
          .eq("user_id", userId)
          .order("created_at", { ascending: false }),
      ]);
      if (cancelled) return;

      const games = gamesRes.data ?? [];
      const speech = speechRes.data ?? [];

      const accOf = (g: any) =>
        Number(g.accuracy_percent ?? g.accuracy ?? 0);

      // per-game averages keyed by game name (lowercase, normalized)
      const perGame: Record<string, number | null> = {};
      const groups: Record<string, number[]> = {};
      games.forEach((g) => {
        const k = String(g.game ?? g.game_name ?? "").toLowerCase().trim();
        if (!k) return;
        (groups[k] ||= []).push(accOf(g));
      });
      Object.entries(groups).forEach(([k, arr]) => {
        perGame[k] = arr.length
          ? Math.round(arr.reduce((a, b) => a + b, 0) / arr.length)
          : null;
      });

      const speechAvg = speech.length
        ? Math.round(
            speech.reduce((a, b) => a + Number(b.avg_score || 0), 0) /
              speech.length,
          )
        : null;

      const allAcc = games.map(accOf).filter((n) => !Number.isNaN(n));
      const overallAccuracy = allAcc.length
        ? Math.round(allAcc.reduce((a, b) => a + b, 0) / allAcc.length)
        : null;

      const totalSessions = games.length + speech.length;

      // Date set
      const dateSet = new Set<string>();
      games.forEach((g) => {
        const d = (g.played_at || g.created_at || "").slice(0, 10);
        if (d) dateSet.add(d);
      });
      speech.forEach((s) => {
        const d = (s.session_date || s.created_at || "").slice(0, 10);
        if (d) dateSet.add(d);
      });

      // Streak counting back from today
      const todayD = new Date();
      todayD.setHours(0, 0, 0, 0);
      let streak = 0;
      const cur = new Date(todayD);
      while (dateSet.has(cur.toISOString().slice(0, 10))) {
        streak++;
        cur.setDate(cur.getDate() - 1);
      }

      // Active days for the current week (Mon..Sun)
      const monday = new Date(todayD);
      const dow = (monday.getDay() + 6) % 7; // 0 = Mon
      monday.setDate(monday.getDate() - dow);
      const activeDays = Array.from({ length: 7 }, (_, i) => {
        const d = new Date(monday);
        d.setDate(monday.getDate() + i);
        return dateSet.has(d.toISOString().slice(0, 10));
      });

      const lastPlayed = [...dateSet].sort().reverse()[0] || null;

      setStats({
        totalSessions,
        overallAccuracy,
        streakDays: streak,
        speechAvg,
        perGame,
        activeDays,
        lastPlayed,
        hasAnyData: totalSessions > 0,
      });
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  return { stats, loading };
}
