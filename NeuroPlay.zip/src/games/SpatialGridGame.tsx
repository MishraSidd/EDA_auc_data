// Spatial Grid Memory game — self-contained.
import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { TopBar } from "@/components/TopBar";
import { saveGameSession } from "@/lib/sessionTracker";

type Difficulty = "easy" | "medium" | "hard";
const CONFIG: Record<Difficulty, { size: number; lit: number }> = {
  easy: { size: 3, lit: 3 },
  medium: { size: 4, lit: 5 },
  hard: { size: 5, lit: 7 },
};
const ROUNDS = 5;

type Phase = "ready" | "watch" | "input" | "feedback" | "done";

function pickCells(total: number, n: number): number[] {
  const all = Array.from({ length: total }, (_, i) => i);
  for (let i = all.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [all[i], all[j]] = [all[j], all[i]];
  }
  return all.slice(0, n);
}

export default function SpatialGridGame() {
  const [difficulty, setDifficulty] = useState<Difficulty>("easy");
  const cfg = CONFIG[difficulty];
  const total = cfg.size * cfg.size;

  const [phase, setPhase] = useState<Phase>("ready");
  const [round, setRound] = useState(0);
  const [pattern, setPattern] = useState<number[]>([]);
  const [activeIdx, setActiveIdx] = useState<number>(-1);
  const [picks, setPicks] = useState<number[]>([]);
  const [history, setHistory] = useState<boolean[]>([]);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [startedAt, setStartedAt] = useState<number>(0);
  const [errorsTotal, setErrorsTotal] = useState(0);

  // Watch animation
  useEffect(() => {
    if (phase !== "watch") return;
    let i = 0;
    let t: number;
    const step = () => {
      if (i >= pattern.length) {
        setActiveIdx(-1);
        setPhase("input");
        return;
      }
      setActiveIdx(pattern[i]);
      t = window.setTimeout(() => {
        setActiveIdx(-1);
        i++;
        t = window.setTimeout(step, 250);
      }, 500);
    };
    step();
    return () => clearTimeout(t);
  }, [phase, pattern]);

  const startSession = () => {
    setRound(0);
    setScore(0);
    setStreak(0);
    setHistory([]);
    setErrorsTotal(0);
    setStartedAt(Date.now());
    beginRound();
  };

  const beginRound = () => {
    setPattern(pickCells(total, cfg.lit));
    setPicks([]);
    setPhase("watch");
  };

  const onCell = (i: number) => {
    if (phase !== "input") return;
    if (picks.includes(i)) return;
    const next = [...picks, i];
    setPicks(next);
    if (next.length === pattern.length) {
      // Evaluate
      const correct = next.filter((c) => pattern.includes(c)).length;
      const allRight = correct === pattern.length;
      const newStreak = allRight ? streak + 1 : 0;
      const wrong = pattern.length - correct;
      if (wrong > 0) setErrorsTotal((e) => e + wrong);
      setStreak(newStreak);
      setScore((s) => s + correct * 10 + newStreak * 5);
      setHistory((h) => [...h, allRight]);
      setPhase("feedback");
    }
  };

  const next = async () => {
    if (round + 1 >= ROUNDS) {
      const perfectRounds = history.filter(Boolean).length;
      const accuracy = Math.round((perfectRounds / ROUNDS) * 100);
      await saveGameSession({
        gameName: "Spatial Grid",
        score,
        accuracyPercent: accuracy,
        errors: errorsTotal,
        durationSeconds: Math.round((Date.now() - startedAt) / 1000),
        levelReached: difficulty,
        difficulty,
        roundsTotal: ROUNDS,
        roundsCorrect: perfectRounds,
        sessionData: { gridSize: cfg.size, litCells: cfg.lit, history },
      });
      setPhase("done");
    } else {
      setRound((r) => r + 1);
      beginRound();
    }
  };

  const cellClass = (i: number) => {
    const base = "aspect-square rounded-xl border-2 transition-colors";
    if (phase === "watch") {
      return `${base} ${activeIdx === i ? "bg-teal-400 border-teal-500" : "bg-card border-border"}`;
    }
    if (phase === "feedback") {
      const isPattern = pattern.includes(i);
      const isPicked = picks.includes(i);
      if (isPattern && isPicked) return `${base} bg-green-100 border-green-500`;
      if (!isPattern && isPicked) return `${base} bg-red-100 border-red-500`;
      if (isPattern && !isPicked) return `${base} bg-orange-50 border-orange-500 border-dashed`;
      return `${base} bg-card border-border opacity-60`;
    }
    return `${base} ${picks.includes(i) ? "bg-primary/20 border-primary" : "bg-card border-border hover:bg-secondary"}`;
  };

  const gridStyle = useMemo(
    () => ({ gridTemplateColumns: `repeat(${cfg.size}, minmax(0, 1fr))` }),
    [cfg.size],
  );

  return (
    <main className="min-h-screen bg-background">
      <TopBar />
      <div className="max-w-3xl mx-auto px-4 py-8">
        <Link to="/" className="inline-flex items-center gap-2 text-[13px] text-muted-foreground mb-4 hover:text-foreground">
          <ArrowLeft className="w-4 h-4" /> Back
        </Link>
        <header className="mb-6">
          <h1 className="text-[24px] font-medium">Spatial Grid</h1>
          <p className="text-[13px] text-muted-foreground mt-1">Round {Math.min(round + 1, ROUNDS)} / {ROUNDS} · Score {score}</p>
        </header>

        {phase === "ready" && (
          <div className="bg-card rounded-3xl p-6 border border-border">
            <p className="font-bold mb-3">Difficulty</p>
            <div className="flex gap-2 mb-6">
              {(Object.keys(CONFIG) as Difficulty[]).map((d) => (
                <button
                  key={d}
                  onClick={() => setDifficulty(d)}
                  className={`px-4 py-2 rounded-xl border font-semibold capitalize ${
                    difficulty === d ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border"
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>
            <div className="text-center">
              <Button onClick={startSession} className="rounded-2xl h-12 px-8 font-bold">Start</Button>
            </div>
          </div>
        )}

        {(phase === "watch" || phase === "input" || phase === "feedback") && (
          <div className="bg-card rounded-3xl p-6 border border-border">
            <p className="text-center font-bold mb-4">
              {phase === "watch" && "Watch the pattern"}
              {phase === "input" && `Reproduce the pattern (${picks.length}/${pattern.length})`}
              {phase === "feedback" && (history[history.length - 1] ? "Perfect!" : "Close — keep going")}
            </p>
            <div className="grid gap-2 mx-auto" style={{ ...gridStyle, maxWidth: 420 }}>
              {Array.from({ length: total }, (_, i) => (
                <button key={i} className={cellClass(i)} onClick={() => onCell(i)} />
              ))}
            </div>
            {phase === "feedback" && (
              <div className="mt-6 flex justify-center">
                <Button onClick={next} className="rounded-2xl h-12 px-8 font-bold">
                  {round + 1 >= ROUNDS ? "See results" : "Next round"}
                </Button>
              </div>
            )}
          </div>
        )}

        {phase === "done" && (
          <div className="bg-card rounded-3xl p-8 border border-border text-center">
            <h2 className="text-2xl font-extrabold mb-2">Session complete</h2>
            <p className="text-6xl font-extrabold text-primary my-6">{score}</p>
            <p className="text-muted-foreground mb-4">
              {history.filter(Boolean).length} / {ROUNDS} perfect rounds
            </p>
            <div className="flex justify-center gap-2 mb-6">
              {history.map((ok, i) => (
                <span key={i} className={`w-3 h-3 rounded-full ${ok ? "bg-green-500" : "bg-red-500"}`} />
              ))}
            </div>
            <Button onClick={startSession} className="rounded-2xl h-12 px-8 font-bold">Play again</Button>
          </div>
        )}
      </div>
    </main>
  );
}