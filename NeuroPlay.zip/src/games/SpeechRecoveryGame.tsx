// Speech Recovery game — self-contained with inline Jaro-Winkler scoring.
import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Mic, Square } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { TopBar } from "@/components/TopBar";
import { saveGameSession } from "@/lib/sessionTracker";
import { getUserId } from "@/features/assessment/useAdaptiveProfile";
import { toast } from "sonner";

const SESSION_WORDS = 5;
const MAX_ATTEMPTS_PER_WORD = 3;

type Difficulty = "easy" | "medium" | "hard";

const WORDS: Record<Difficulty, { word: string; phonetic: string }[]> = {
  easy: [
    { word: "Water", phonetic: "/ ˈwɔː.tər /" },
    { word: "Apple", phonetic: "/ ˈæp.əl /" },
    { word: "Hello", phonetic: "/ həˈloʊ /" },
    { word: "Book", phonetic: "/ bʊk /" },
    { word: "Door", phonetic: "/ dɔːr /" },
    { word: "Cat", phonetic: "/ kæt /" },
    { word: "Sun", phonetic: "/ sʌn /" },
    { word: "Tree", phonetic: "/ triː /" },
  ],
  medium: [
    { word: "Butter", phonetic: "/ ˈbʌt.ər /" },
    { word: "Purple", phonetic: "/ ˈpɜːr.pəl /" },
    { word: "Bottle", phonetic: "/ ˈbɒt.əl /" },
    { word: "Turtle", phonetic: "/ ˈtɜːr.təl /" },
    { word: "Gentle", phonetic: "/ ˈdʒen.təl /" },
    { word: "Simple", phonetic: "/ ˈsɪm.pəl /" },
  ],
  hard: [
    { word: "Thermometer", phonetic: "/ θərˈmɑː.mə.tər /" },
    { word: "Strawberry", phonetic: "/ ˈstrɔː.ber.i /" },
    { word: "Comfortable", phonetic: "/ ˈkʌmf.tə.bəl /" },
    { word: "Particularly", phonetic: "/ pərˈtɪk.jə.lər.li /" },
    { word: "Veterinarian", phonetic: "/ ˌvet.ər.əˈner.i.ən /" },
  ],
};

function jaroWinkler(s1: string, s2: string): number {
  s1 = s1.toLowerCase().trim(); s2 = s2.toLowerCase().trim();
  if (s1 === s2) return 1;
  const len1 = s1.length, len2 = s2.length;
  if (!len1 || !len2) return 0;
  const matchDist = Math.max(Math.floor(Math.max(len1, len2) / 2) - 1, 0);
  const s1m = new Array(len1).fill(false), s2m = new Array(len2).fill(false);
  let matches = 0, transpositions = 0;
  for (let i = 0; i < len1; i++) {
    const start = Math.max(0, i - matchDist), end = Math.min(i + matchDist + 1, len2);
    for (let j = start; j < end; j++) {
      if (s2m[j] || s1[i] !== s2[j]) continue;
      s1m[i] = s2m[j] = true; matches++; break;
    }
  }
  if (!matches) return 0;
  let k = 0;
  for (let i = 0; i < len1; i++) {
    if (!s1m[i]) continue;
    while (!s2m[k]) k++;
    if (s1[i] !== s2[k]) transpositions++;
    k++;
  }
  const jaro = (matches / len1 + matches / len2 + (matches - transpositions / 2) / matches) / 3;
  let prefix = 0;
  for (let i = 0; i < Math.min(len1, len2, 4); i++) { if (s1[i] === s2[i]) prefix++; else break; }
  return jaro + prefix * 0.1 * (1 - jaro);
}

function computeScore(target: string, spoken: string): number {
  return Math.round(jaroWinkler(target, spoken) * 100);
}

function pickSessionWords(d: Difficulty) {
  const pool = [...WORDS[d]];
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  return pool.slice(0, Math.min(SESSION_WORDS, pool.length));
}

export default function SpeechRecoveryGame() {
  const [difficulty, setDifficulty] = useState<Difficulty>("easy");
  const [list, setList] = useState(() => pickSessionWords("easy"));
  const [index, setIndex] = useState(0);
  const [attempt, setAttempt] = useState(1);
  const [recording, setRecording] = useState(false);
  const [spoken, setSpoken] = useState("");
  const [score, setScore] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<{ word: string; score: number }[]>([]);
  const [bestPerWord, setBestPerWord] = useState<number[]>([]);
  const [sessionComplete, setSessionComplete] = useState(false);
  const recRef = useRef<any>(null);
  const startedAtRef = useRef<number>(Date.now());
  const savedRef = useRef(false);
  const historyRef = useRef<{ word: string; score: number }[]>([]);
  const difficultyRef = useRef<Difficulty>("easy");
  const navigate = useNavigate();
  const supported = typeof window !== "undefined" && !!((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);

  const current = list[index];
  useEffect(() => { historyRef.current = history; }, [history]);
  useEffect(() => { difficultyRef.current = difficulty; }, [difficulty]);

  // Persist a session summary when leaving the game (unmount only).
  useEffect(() => {
    return () => {
      if (savedRef.current) return;
      const h = historyRef.current;
      if (h.length === 0) return;
      savedRef.current = true;
      const avg = Math.round(h.reduce((a, b) => a + b.score, 0) / h.length);
      const errors = h.filter((x) => x.score < 50).length;
      const d = difficultyRef.current;
      void saveGameSession({
        gameName: "Speech Recovery",
        score: avg,
        accuracyPercent: avg,
        errors,
        durationSeconds: Math.round((Date.now() - startedAtRef.current) / 1000),
        levelReached: d,
        difficulty: d,
        roundsTotal: h.length,
        roundsCorrect: h.filter((x) => x.score >= 80).length,
        sessionData: { attempts: h },
      });
    };
  }, []);

  useEffect(() => {
    if (!supported) return;
    const Ctor = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const rec = new Ctor();
    rec.lang = "en-US";
    rec.continuous = false;
    rec.interimResults = false;
    rec.maxAlternatives = 1;
    rec.onresult = (e: any) => {
      const text = e?.results?.[0]?.[0]?.transcript ?? "";
      setSpoken(text);
      const s = computeScore(current?.word || "", text);
      setScore(s);
      setHistory((h) => [...h, { word: current.word, score: s }]);
      // persist (best-effort)
      (async () => {
        try {
          await supabase.from("speech_attempts").insert({
            session_id: localStorage.getItem("np_session_id") || "anon",
            word: current.word,
            spoken_text: text,
            score: s,
            difficulty,
          });
        } catch {
          const log = JSON.parse(localStorage.getItem("speechRecoveryScores") || "[]");
          log.push({ word: current.word, score: s, at: Date.now() });
          localStorage.setItem("speechRecoveryScores", JSON.stringify(log));
        }
      })();
    };
    rec.onerror = (e: any) => { setError(e?.error || "Speech error"); setRecording(false); };
    rec.onend = () => setRecording(false);
    recRef.current = rec;
    return () => { try { rec.abort(); } catch { /* noop */ } };
  }, [current, difficulty, supported]);

  const startStop = () => {
    if (!recRef.current) return;
    if (recording) {
      try { recRef.current.stop(); } catch { /* noop */ }
      setRecording(false);
      return;
    }
    setError(null); setSpoken(""); setScore(null);
    try { recRef.current.start(); setRecording(true); } catch (e: any) { setError(String(e?.message ?? e)); }
  };

  const tryAgain = () => { setSpoken(""); setScore(null); setAttempt((a) => Math.min(MAX_ATTEMPTS_PER_WORD, a + 1)); };

  const finishSession = async (perWord: number[]) => {
    if (savedRef.current) return;
    savedRef.current = true;
    const avg = perWord.length ? Math.round(perWord.reduce((a, b) => a + b, 0) / perWord.length) : 0;
    setSessionComplete(true);
    try {
      await supabase.from("speech_sessions").insert({
        user_id: getUserId(),
        words_attempted: perWord.length,
        avg_score: avg,
        session_date: new Date().toISOString().slice(0, 10),
      });
      toast.success("Session saved ✓");
    } catch {
      // ignore
    }
  };

  const nextWord = () => {
    const wordBest = score ?? 0;
    const nextBest = [...bestPerWord, wordBest];
    setBestPerWord(nextBest);
    setSpoken(""); setScore(null); setAttempt(1);
    if (index + 1 >= list.length) {
      void finishSession(nextBest);
    } else {
      setIndex((i) => i + 1);
    }
  };

  const resetSession = (d: Difficulty = difficulty) => {
    savedRef.current = false;
    startedAtRef.current = Date.now();
    setList(pickSessionWords(d));
    setIndex(0); setAttempt(1); setSpoken(""); setScore(null);
    setHistory([]); setBestPerWord([]); setSessionComplete(false);
  };

  const onDifficulty = (d: Difficulty) => {
    setDifficulty(d);
    resetSession(d);
  };

  const band = useMemo(() => {
    if (score == null) return { bar: "bg-secondary", text: "text-foreground", msg: "" };
    if (score >= 80) return { bar: "bg-green-500", text: "text-green-700", msg: "Excellent pronunciation!" };
    if (score >= 50) return { bar: "bg-amber-500", text: "text-amber-700", msg: "Good — keep practicing." };
    return { bar: "bg-red-500", text: "text-red-700", msg: "Try again, slow and clear." };
  }, [score]);

  return (
    <main className="min-h-screen bg-background">
      <TopBar />
      <div className="max-w-3xl mx-auto px-4 py-8">
        <Link to="/" className="inline-flex items-center gap-2 text-[13px] text-muted-foreground mb-4 hover:text-foreground">
          <ArrowLeft className="w-4 h-4" /> Back
        </Link>
        <header className="mb-6">
          <h1 className="text-[24px] font-medium">Speech Practice</h1>
          <p className="text-[13px] text-muted-foreground mt-1">Strengthen your communication — {SESSION_WORDS} words per session</p>
        </header>

        {!supported && (
          <div className="rounded-2xl border border-amber-300 bg-amber-50 text-amber-800 p-4 mb-4">
            Your browser does not support Speech Recognition. Please use Chrome or Edge.
          </div>
        )}

        {sessionComplete ? (
          <div className="bg-card rounded-3xl p-8 border border-border text-center">
            {(() => {
              const avg = bestPerWord.length ? Math.round(bestPerWord.reduce((a, b) => a + b, 0) / bestPerWord.length) : 0;
              return (
                <>
                  <h2 className="text-3xl font-semibold mb-2">Session complete</h2>
                  <p className="text-muted-foreground mb-6">Words attempted: {bestPerWord.length}</p>
                  <div className="mb-2 text-sm uppercase tracking-wide text-muted-foreground">Average pronunciation</div>
                  <div className="text-6xl font-extrabold text-teal-600 mb-3">{avg}%</div>
                  <div className="h-3 w-full rounded-full bg-secondary overflow-hidden mb-6">
                    <div className="h-full bg-teal-500" style={{ width: `${avg}%` }} />
                  </div>
                  <p className="text-[14px] text-muted-foreground mb-8 max-w-md mx-auto">
                    Well done for practising today — consistency is what builds improvement.
                  </p>
                  <div className="flex gap-3 justify-center flex-wrap">
                    <Button className="rounded-2xl h-11" onClick={() => resetSession()}>Practice again</Button>
                    <Button variant="secondary" className="rounded-2xl h-11" onClick={() => navigate("/")}>Go to dashboard</Button>
                  </div>
                </>
              );
            })()}
          </div>
        ) : (
        <div className="bg-card rounded-3xl p-6 border border-border">
          <div className="flex gap-2 mb-6 flex-wrap">
            {(Object.keys(WORDS) as Difficulty[]).map((d) => (
              <button
                key={d}
                onClick={() => onDifficulty(d)}
                className={`px-4 py-2 rounded-xl border font-semibold capitalize ${
                  difficulty === d ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border"
                }`}
              >
                {d}
              </button>
            ))}
          </div>

          <div className="text-center mb-6">
            <p className="text-xs uppercase tracking-wider text-muted-foreground mb-1">
              Word {index + 1} / {list.length} • Attempt {attempt} / {MAX_ATTEMPTS_PER_WORD}
            </p>
            <h2 className="text-5xl font-extrabold">{current.word}</h2>
            <p className="mt-2 text-muted-foreground">{current.phonetic}</p>
          </div>

          <div className="flex flex-col items-center gap-3 mb-6">
            <button
              type="button"
              onClick={startStop}
              disabled={!supported}
              className={`relative h-20 w-20 rounded-full grid place-items-center text-white transition-colors ${
                recording ? "bg-red-500" : "bg-primary hover:bg-primary/90"
              } ${!supported ? "opacity-50" : ""}`}
            >
              {recording && <span className="absolute inset-0 rounded-full bg-red-500/40 animate-ping" />}
              {recording ? <Square className="w-7 h-7" /> : <Mic className="w-7 h-7" />}
            </button>
            <p className="text-sm text-muted-foreground">{recording ? "Listening…" : "Tap the mic and say the word"}</p>
            {error && <p className="text-sm text-red-600">{error}</p>}
          </div>

          {score != null && (
            <div className="rounded-2xl border border-border p-5 mb-4">
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <p className="text-xs uppercase text-muted-foreground">You said</p>
                  <p className="text-lg font-bold break-words">{spoken || "—"}</p>
                </div>
                <div>
                  <p className="text-xs uppercase text-muted-foreground">Target</p>
                  <p className="text-lg font-bold">{current.word}</p>
                </div>
              </div>
              <div className="flex items-baseline gap-2">
                <span className={`text-5xl font-extrabold ${band.text}`}>{score}</span>
                <span className={`text-xl ${band.text}`}>%</span>
              </div>
              <div className="mt-2 h-2 w-full rounded-full bg-secondary overflow-hidden">
                <div className={`h-full ${band.bar}`} style={{ width: `${score}%` }} />
              </div>
              <p className={`mt-2 text-sm ${band.text}`}>{band.msg}</p>
            </div>
          )}

          <div className="flex gap-3 justify-end">
            {score != null && attempt < MAX_ATTEMPTS_PER_WORD && (
              <Button variant="secondary" className="rounded-2xl h-11" onClick={tryAgain}>Try again</Button>
            )}
            <Button className="rounded-2xl h-11" onClick={nextWord}>
              {index + 1 >= list.length ? "Finish session" : "Next word"}
            </Button>
          </div>
        </div>
        )}

        {!sessionComplete && history.length > 0 && (
          <div className="bg-card rounded-3xl p-6 border border-border mt-6">
            <h3 className="font-extrabold mb-3">Session progress</h3>
            <ul className="space-y-1 text-sm">
              {history.slice(-10).reverse().map((h, i) => (
                <li key={i} className="flex justify-between border-b border-border/50 py-1">
                  <span>{h.word}</span>
                  <span className="font-bold">{h.score}%</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </main>
  );
}