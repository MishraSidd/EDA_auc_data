// Memory Recall game — self-contained, added per request.
// Flow: Ready → Memorize (3s) → Pause (2s) → Recall → Result. 5 sets per session.
import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { TopBar } from "@/components/TopBar";
import { useAdaptiveProfile } from "@/features/assessment/useAdaptiveProfile";
import { saveGameSession } from "@/lib/sessionTracker";

const EMOJIS = ['🪑','📷','🌿','🍎','🎯','🎸','🚲','⌚','🍕','🌸','🐶','🦋','🎩','🍦','🏠','🌍','🎻','🧩','🚀','🐠','🍋','🎀','🔑','🎃','🦁','🌺','🛸','🎾','🍓','🧸','🦜','🍩','🌙','🎮','🐙','🌻','🎺','🦊','🍇','🏆'];
const TOTAL_SETS = 5;
const TARGET_COUNT = 3;

type Phase = "ready" | "memorize" | "pause" | "recall" | "setResult" | "done";

function sample<T>(arr: T[], n: number): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a.slice(0, n);
}

function buildSet(gridSize: number) {
  const targets = sample(EMOJIS, TARGET_COUNT);
  const distractors = sample(EMOJIS.filter((e) => !targets.includes(e)), Math.max(0, gridSize - TARGET_COUNT));
  const grid = sample([...targets, ...distractors], gridSize);
  return { targets, grid };
}

export default function MemoryRecallGame() {
  const { profile } = useAdaptiveProfile();
  const gridSize = TARGET_COUNT + Math.max(6, profile.distractorCount); // 9–20 tiles
  const [phase, setPhase] = useState<Phase>("ready");
  const [setIndex, setSetIndex] = useState(0);
  const [round, setRound] = useState(() => buildSet(gridSize));
  const [picks, setPicks] = useState<string[]>([]);
  const [progress, setProgress] = useState(100);
  const [correctTotal, setCorrectTotal] = useState(0);
  const [startedAt, setStartedAt] = useState<number>(0);
  const [errorsTotal, setErrorsTotal] = useState(0);

  // Animated countdown for memorize/pause
  useEffect(() => {
    if (phase !== "memorize" && phase !== "pause") return;
    const total = phase === "memorize" ? profile.previewMs : 2000;
    const start = performance.now();
    let raf = 0;
    const tick = (t: number) => {
      const elapsed = t - start;
      const pct = Math.max(0, 100 - (elapsed / total) * 100);
      setProgress(pct);
      if (elapsed >= total) {
        setPhase(phase === "memorize" ? "pause" : "recall");
      } else {
        raf = requestAnimationFrame(tick);
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [phase, profile.previewMs]);

  const startSession = () => {
    setSetIndex(0);
    setCorrectTotal(0);
    setErrorsTotal(0);
    setStartedAt(Date.now());
    setPicks([]);
    setRound(buildSet(gridSize));
    setProgress(100);
    setPhase("memorize");
  };

  const togglePick = (emoji: string) => {
    if (phase !== "recall") return;
    setPicks((p) =>
      p.includes(emoji) ? p.filter((x) => x !== emoji) : p.length < TARGET_COUNT ? [...p, emoji] : p,
    );
  };

  const submit = () => {
    const correct = picks.filter((p) => round.targets.includes(p)).length;
    const wrong = picks.length - correct;
    setCorrectTotal((c) => c + correct);
    setErrorsTotal((e) => e + wrong + (TARGET_COUNT - correct));
    setPhase("setResult");
  };

  const next = async () => {
    if (setIndex + 1 >= TOTAL_SETS) {
      const total = correctTotal;
      const accuracy = Math.round((total / (TOTAL_SETS * TARGET_COUNT)) * 100);
      await saveGameSession({
        gameName: "Memory Recall",
        score: accuracy,
        accuracyPercent: accuracy,
        errors: errorsTotal,
        durationSeconds: Math.round((Date.now() - startedAt) / 1000),
        levelReached: setIndex + 1,
        roundsTotal: TOTAL_SETS,
        roundsCorrect: Math.round(total / TARGET_COUNT),
        sessionData: {
          gridSize,
          targetCount: TARGET_COUNT,
          correctTiles: total,
          totalTiles: TOTAL_SETS * TARGET_COUNT,
          previewMs: profile.previewMs,
        },
      });
      setPhase("done");
    } else {
      setSetIndex((i) => i + 1);
      setRound(buildSet(gridSize));
      setPicks([]);
      setProgress(100);
      setPhase("memorize");
    }
  };

  const accuracy = useMemo(
    () => Math.round((correctTotal / (TOTAL_SETS * TARGET_COUNT)) * 100),
    [correctTotal],
  );

  const cellClass = (emoji: string) => {
    if (phase !== "setResult") {
      return picks.includes(emoji)
        ? "border-primary ring-2 ring-primary"
        : "border-border hover:bg-secondary";
    }
    const wasTarget = round.targets.includes(emoji);
    const wasPicked = picks.includes(emoji);
    if (wasTarget && wasPicked) return "border-green-500 bg-green-50";
    if (!wasTarget && wasPicked) return "border-red-500 bg-red-50";
    if (wasTarget && !wasPicked) return "border-orange-500 border-dashed bg-orange-50";
    return "border-border opacity-60";
  };

  return (
    <main className="min-h-screen bg-background">
      <TopBar />
      <div className="max-w-3xl mx-auto px-4 py-8">
        <Link to="/" className="inline-flex items-center gap-2 text-[13px] text-muted-foreground mb-4 hover:text-foreground">
          <ArrowLeft className="w-4 h-4" /> Back
        </Link>
        <header className="mb-6">
          <h1 className="text-[24px] font-medium">Memory Recall</h1>
          <p className="text-[13px] text-muted-foreground mt-1">Set {Math.min(setIndex + 1, TOTAL_SETS)} of {TOTAL_SETS}</p>
        </header>

        {phase === "ready" && (
          <div className="text-center bg-card rounded-3xl p-8 border border-border">
            <p className="text-lg mb-6">Memorize 3 emojis, then pick them from a grid.</p>
            <Button onClick={startSession} className="rounded-2xl h-12 px-8 font-bold">Start</Button>
          </div>
        )}

        {(phase === "memorize" || phase === "pause") && (
          <div className="bg-card rounded-3xl p-8 border border-border text-center">
            <div className="h-3 w-full rounded-full bg-secondary overflow-hidden mb-6">
              <div
                className={`h-full transition-none ${phase === "memorize" ? "bg-green-500" : "bg-amber-500"}`}
                style={{ width: `${progress}%` }}
              />
            </div>
            {phase === "memorize" ? (
              <div className="flex justify-center gap-6 text-7xl">
                {round.targets.map((e, i) => <span key={i}>{e}</span>)}
              </div>
            ) : (
              <p className="text-2xl font-bold text-muted-foreground">Get ready…</p>
            )}
          </div>
        )}

        {(phase === "recall" || phase === "setResult") && (
          <div className="bg-card rounded-3xl p-6 border border-border">
            <p className="text-center text-lg font-bold mb-4">
              {phase === "recall" ? `Pick the 3 emojis you saw (${picks.length}/${TARGET_COUNT})` : "Result"}
            </p>
            <div className={`grid gap-3 ${gridSize <= 12 ? "grid-cols-3" : gridSize <= 16 ? "grid-cols-4" : "grid-cols-5"}`}>
              {round.grid.map((e, i) => (
                <button
                  key={i}
                  onClick={() => togglePick(e)}
                  className={`aspect-square rounded-2xl border-2 text-4xl flex items-center justify-center transition-colors ${cellClass(e)}`}
                >
                  {e}
                </button>
              ))}
            </div>
            <div className="mt-6 flex justify-center">
              {phase === "recall" ? (
                <Button disabled={picks.length !== TARGET_COUNT} onClick={submit} className="rounded-2xl h-12 px-8 font-bold">
                  Submit
                </Button>
              ) : (
                <Button onClick={next} className="rounded-2xl h-12 px-8 font-bold">
                  {setIndex + 1 >= TOTAL_SETS ? "See results" : "Next set"}
                </Button>
              )}
            </div>
          </div>
        )}

        {phase === "done" && (
          <div className="bg-card rounded-3xl p-8 border border-border text-center">
            <h2 className="text-2xl font-extrabold mb-2">Session complete</h2>
            <p className="text-6xl font-extrabold text-primary my-6">{accuracy}%</p>
            <p className="text-muted-foreground mb-6">{correctTotal} / {TOTAL_SETS * TARGET_COUNT} correct</p>
            <Button onClick={startSession} className="rounded-2xl h-12 px-8 font-bold">Play again</Button>
          </div>
        )}
      </div>
    </main>
  );
}