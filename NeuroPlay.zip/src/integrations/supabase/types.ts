export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      assessments: {
        Row: {
          adaptation_level: number
          adaptive_profile: Json
          cognitive_focus: number
          communication_confidence: number
          created_at: string
          fatigue_sensitivity: number
          id: string
          memory_index: number
          motor_stability: number
          questionnaire: Json
          tremor_deviation: number
          tremor_smoothness: number
          tremor_velocity_var: number
          user_id: string
        }
        Insert: {
          adaptation_level?: number
          adaptive_profile?: Json
          cognitive_focus?: number
          communication_confidence?: number
          created_at?: string
          fatigue_sensitivity?: number
          id?: string
          memory_index?: number
          motor_stability?: number
          questionnaire?: Json
          tremor_deviation?: number
          tremor_smoothness?: number
          tremor_velocity_var?: number
          user_id: string
        }
        Update: {
          adaptation_level?: number
          adaptive_profile?: Json
          cognitive_focus?: number
          communication_confidence?: number
          created_at?: string
          fatigue_sensitivity?: number
          id?: string
          memory_index?: number
          motor_stability?: number
          questionnaire?: Json
          tremor_deviation?: number
          tremor_smoothness?: number
          tremor_velocity_var?: number
          user_id?: string
        }
        Relationships: []
      }
      daily_tasks: {
        Row: {
          completed: boolean
          completed_at: string | null
          created_at: string
          id: string
          scheduled_for: string
          scheduled_time: string | null
          title: string
          user_id: string
        }
        Insert: {
          completed?: boolean
          completed_at?: string | null
          created_at?: string
          id?: string
          scheduled_for: string
          scheduled_time?: string | null
          title: string
          user_id: string
        }
        Update: {
          completed?: boolean
          completed_at?: string | null
          created_at?: string
          id?: string
          scheduled_for?: string
          scheduled_time?: string | null
          title?: string
          user_id?: string
        }
        Relationships: []
      }
      game_sessions: {
        Row: {
          accuracy: number
          accuracy_percent: number
          created_at: string
          difficulty: string | null
          duration_sec: number
          duration_seconds: number
          errors: number
          game: string
          game_name: string | null
          id: string
          level_reached: string | null
          metadata: Json
          played_at: string
          rounds_correct: number
          rounds_total: number
          score: number
          session_data: Json
          user_id: string
        }
        Insert: {
          accuracy?: number
          accuracy_percent?: number
          created_at?: string
          difficulty?: string | null
          duration_sec?: number
          duration_seconds?: number
          errors?: number
          game: string
          game_name?: string | null
          id?: string
          level_reached?: string | null
          metadata?: Json
          played_at?: string
          rounds_correct?: number
          rounds_total?: number
          score?: number
          session_data?: Json
          user_id: string
        }
        Update: {
          accuracy?: number
          accuracy_percent?: number
          created_at?: string
          difficulty?: string | null
          duration_sec?: number
          duration_seconds?: number
          errors?: number
          game?: string
          game_name?: string | null
          id?: string
          level_reached?: string | null
          metadata?: Json
          played_at?: string
          rounds_correct?: number
          rounds_total?: number
          score?: number
          session_data?: Json
          user_id?: string
        }
        Relationships: []
      }
      mood_logs: {
        Row: {
          created_at: string
          id: string
          logged_at: string
          mood_label: string
          mood_score: number | null
          mood_value: number
          note: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          logged_at?: string
          mood_label: string
          mood_score?: number | null
          mood_value: number
          note?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          logged_at?: string
          mood_label?: string
          mood_score?: number | null
          mood_value?: number
          note?: string | null
          user_id?: string
        }
        Relationships: []
      }
      speech_attempts: {
        Row: {
          created_at: string
          difficulty: string
          id: string
          score: number
          session_id: string
          spoken_text: string
          word: string
        }
        Insert: {
          created_at?: string
          difficulty?: string
          id?: string
          score: number
          session_id: string
          spoken_text?: string
          word: string
        }
        Update: {
          created_at?: string
          difficulty?: string
          id?: string
          score?: number
          session_id?: string
          spoken_text?: string
          word?: string
        }
        Relationships: []
      }
      speech_sessions: {
        Row: {
          avg_score: number
          created_at: string
          id: string
          session_date: string
          user_id: string
          words_attempted: number
        }
        Insert: {
          avg_score?: number
          created_at?: string
          id?: string
          session_date?: string
          user_id: string
          words_attempted?: number
        }
        Update: {
          avg_score?: number
          created_at?: string
          id?: string
          session_date?: string
          user_id?: string
          words_attempted?: number
        }
        Relationships: []
      }
      task_logs: {
        Row: {
          completed_at: string
          created_at: string
          delay_minutes: number
          id: string
          scheduled_time: string | null
          task_name: string
          user_id: string
          was_completed: boolean
        }
        Insert: {
          completed_at?: string
          created_at?: string
          delay_minutes?: number
          id?: string
          scheduled_time?: string | null
          task_name: string
          user_id: string
          was_completed?: boolean
        }
        Update: {
          completed_at?: string
          created_at?: string
          delay_minutes?: number
          id?: string
          scheduled_time?: string | null
          task_name?: string
          user_id?: string
          was_completed?: boolean
        }
        Relationships: []
      }
      weekly_reports: {
        Row: {
          avg_accuracy: number
          avg_mood: number
          avg_score: number
          created_at: string
          highlights: string | null
          id: string
          sessions_played: number
          tasks_completed: number
          tasks_total: number
          trend: string | null
          user_id: string
          week_end: string
          week_start: string
        }
        Insert: {
          avg_accuracy?: number
          avg_mood?: number
          avg_score?: number
          created_at?: string
          highlights?: string | null
          id?: string
          sessions_played?: number
          tasks_completed?: number
          tasks_total?: number
          trend?: string | null
          user_id: string
          week_end: string
          week_start: string
        }
        Update: {
          avg_accuracy?: number
          avg_mood?: number
          avg_score?: number
          created_at?: string
          highlights?: string | null
          id?: string
          sessions_played?: number
          tasks_completed?: number
          tasks_total?: number
          trend?: string | null
          user_id?: string
          week_end?: string
          week_start?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
