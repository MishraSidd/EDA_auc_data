import { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, ArrowRight, Check } from "lucide-react";
import { TopBar } from "@/components/TopBar";
import { Button } from "@/components/ui/button";
import { onboardingQuestions } from "@/features/onboarding/questions";
import { computeMetrics, deriveProfile, type QuestionnaireAnswers } from "@/features/assessment/scoringEngine";
import { supabase } from "@/integrations/supabase/client";
import { getUserId } from "@/features/assessment/useAdaptiveProfile";

export default function Onboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string | string[]>>({});
  const [saving, setSaving] = useState(false);

  const q = onboardingQuestions[step];
  const total = onboardingQuestions.length;
  const progress = ((step + 1) / total) * 100;

  const current = answers[q.id];
  const canContinue = q.multi
    ? Array.isArray(current) && current.length > 0
    : typeof current === "string" && current.length > 0;

  const toggle = (opt: string) => {
    setAnswers((a) => {
      if (q.multi) {
        const arr = Array.isArray(a[q.id]) ? (a[q.id] as string[]) : [];
        return {
          ...a,
          [q.id]: arr.includes(opt) ? arr.filter((x) => x !== opt) : [...arr, opt],
        };
      }
      return { ...a, [q.id]: opt };
    });
  };

  const isSelected = (opt: string) =>
    q.multi ? Array.isArray(current) && current.includes(opt) : current === opt;

  const finish = async () => {
    setSaving(true);
    const qa = answers as QuestionnaireAnswers;
    const metrics = computeMetrics(qa);
    const profile = deriveProfile(metrics);
    const userId = getUserId();
    try {
      await supabase.from("assessments").insert({
        user_id: userId,
        questionnaire: answers as never,
        ...metrics,
        adaptive_profile: profile as never,
      });
      localStorage.setItem("np_onboarded", "1");
    } finally {
      setSaving(false);
      navigate("/assessment/tremor");
    }
  };

  const encouragements = useMemo(
    () => [
      "Let's begin gently.",
      "You're doing great.",
      "Honest answers help us help you.",
      "Almost halfway there.",
      "Keep going — your input matters.",
      "Two more to go.",
      "Last one. Thank you.",
    ],
    [],
  );

  return (
    <main className="min-h-screen bg-background">
      <TopBar />
      <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8">
        <button
          type="button"
          onClick={() => {
            localStorage.setItem("np_onboarded", "1");
            navigate("/");
          }}
          className="inline-flex items-center gap-2 text-[13px] text-muted-foreground mb-6 hover:text-foreground"
        >
          <ArrowLeft className="w-4 h-4" /> Back to dashboard
        </button>

        {/* Progress */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] uppercase tracking-wide text-muted-foreground">
              Question {step + 1} of {total}
            </span>
            <span className="text-[11px] text-muted-foreground">{encouragements[step]}</span>
          </div>
          <div className="h-1 w-full bg-secondary rounded-full overflow-hidden">
            <div
              className="h-full bg-primary transition-all duration-500 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        <section className="bg-card border border-border rounded-md p-6 sm:p-8">
          <h1 className="text-[22px] font-medium leading-snug">{q.title}</h1>
          <p className="text-[13px] text-muted-foreground mt-2">{q.helper}</p>

          <div className="mt-6 grid gap-2">
            {q.options.map((opt) => {
              const sel = isSelected(opt);
              return (
                <button
                  key={opt}
                  onClick={() => toggle(opt)}
                  className={`w-full text-left flex items-center justify-between gap-4 px-4 min-h-[56px] rounded-md border transition-colors ${
                    sel
                      ? "border-primary bg-accent text-accent-foreground"
                      : "border-border bg-card hover:bg-secondary"
                  }`}
                >
                  <span className="text-[15px]">{opt}</span>
                  {sel && <Check className="w-4 h-4 text-primary" />}
                </button>
              );
            })}
          </div>

          <div className="mt-8 flex items-center justify-between">
            <Button
              variant="ghost"
              disabled={step === 0}
              onClick={() => setStep((s) => Math.max(0, s - 1))}
            >
              <ArrowLeft className="w-4 h-4" /> Back
            </Button>
            {step < total - 1 ? (
              <Button
                disabled={!canContinue}
                onClick={() => setStep((s) => s + 1)}
              >
                Continue <ArrowRight className="w-4 h-4" />
              </Button>
            ) : (
              <Button disabled={!canContinue || saving} onClick={finish}>
                {saving ? "Saving…" : "Finish"} <ArrowRight className="w-4 h-4" />
              </Button>
            )}
          </div>
        </section>
      </div>
    </main>
  );
}