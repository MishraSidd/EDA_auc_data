import { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { getUserId } from "@/features/assessment/useAdaptiveProfile";
import { onboardingQuestions } from "@/features/onboarding/questions";

interface Assessment {
  id: string;
  created_at: string;
  questionnaire: Record<string, string | string[]> | null;
  adaptive_profile: { sessionLengthMin?: number; targetSize?: string } | null;
  tremor_smoothness: number;
  tremor_deviation: number;
  tremor_velocity_var: number;
}

interface TremorRow {
  id: string;
  date: string;
  tremor_index: number;
  severity: "minimal" | "mild" | "moderate" | "significant";
}

const SEVERITY_COLORS: Record<TremorRow["severity"], { dot: string; bg: string; text: string }> = {
  minimal:     { dot: "#0F6E56", bg: "#E1F5EE", text: "#0F6E56" },
  mild:        { dot: "#EF9F27", bg: "#FAEEDA", text: "#8A5A12" },
  moderate:    { dot: "#C05A0A", bg: "#FEE2C8", text: "#8A3D08" },
  significant: { dot: "#A32D2D", bg: "#FCEBEB", text: "#A32D2D" },
};

function severityFromIndex(idx: number): TremorRow["severity"] {
  if (idx >= 80) return "minimal";
  if (idx >= 60) return "mild";
  if (idx >= 40) return "moderate";
  return "significant";
}

function computeTremorIndex(a: Assessment): number {
  const s = Number(a.tremor_smoothness ?? 0);
  const d = Number(a.tremor_deviation ?? 0);
  const v = Number(a.tremor_velocity_var ?? 0);
  return Math.round((s + (100 - d) + (100 - v)) / 3);
}

function formatDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
}

function formatShort(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString(undefined, { day: "numeric", month: "short" });
}

export default function Profile() {
  const navigate = useNavigate();
  const [latest, setLatest] = useState<Assessment | null>(null);
  const [tremorHistory, setTremorHistory] = useState<TremorRow[]>([]);
  const [tremorRaw, setTremorRaw] = useState<Assessment[]>([]);
  const [loading, setLoading] = useState(true);
  const chartRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    (async () => {
      const userId = getUserId();
      const { data } = await supabase
        .from("assessments")
        .select("id, created_at, questionnaire, adaptive_profile, tremor_smoothness, tremor_deviation, tremor_velocity_var")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })
        .limit(50);
      const rows = (data ?? []) as unknown as Assessment[];
      const withQuestionnaire = rows.find((r) => r.questionnaire && Object.keys(r.questionnaire).length > 0) ?? rows[0] ?? null;
      setLatest(withQuestionnaire);
      const tremor = rows.filter((r) => Number(r.tremor_smoothness ?? 0) > 0);
      setTremorRaw(tremor);
      setTremorHistory(
        tremor.slice(0, 10).map((r) => {
          const idx = computeTremorIndex(r);
          return { id: r.id, date: r.created_at, tremor_index: idx, severity: severityFromIndex(idx) };
        }),
      );
      setLoading(false);
    })();
  }, []);

  useEffect(() => {
    const canvas = chartRef.current;
    if (!canvas || tremorRaw.length === 0) return;
    const last7 = [...tremorRaw].slice(0, 7).reverse();
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, rect.width, rect.height);
    const padding = 4;
    const labelArea = 14;
    const barArea = rect.height - labelArea;
    const gap = 6;
    const w = (rect.width - padding * 2 - gap * (last7.length - 1)) / last7.length;
    last7.forEach((r, i) => {
      const idx = computeTremorIndex(r);
      const sev = severityFromIndex(idx);
      const h = Math.max(3, (idx / 100) * (barArea - 4));
      const x = padding + i * (w + gap);
      const y = barArea - h;
      ctx.fillStyle = SEVERITY_COLORS[sev].dot;
      const radius = 3;
      ctx.beginPath();
      ctx.moveTo(x + radius, y);
      ctx.lineTo(x + w - radius, y);
      ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
      ctx.lineTo(x + w, y + h);
      ctx.lineTo(x, y + h);
      ctx.lineTo(x, y + radius);
      ctx.quadraticCurveTo(x, y, x + radius, y);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "#9a9890";
      ctx.font = "10px system-ui, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(formatShort(r.created_at), x + w / 2, rect.height - 2);
    });
  }, [tremorRaw]);

  const userId = getUserId();
  const userName = `Patient ${userId.replace(/^u_/, "").slice(0, 4).toUpperCase()}`;
  const initials = userName.split(" ").map((w) => w[0]).join("").toUpperCase().slice(0, 2);

  return (
    <main className="min-h-screen" style={{ background: "#f7f6f2" }}>
      <div className="max-w-[600px] mx-auto" style={{ padding: "2rem 1rem" }}>
        <header className="mb-5">
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="inline-flex items-center gap-1.5 text-[12px] text-[#5f5e5a] hover:text-[#1a1a18] mb-3"
            aria-label="Back"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Back
          </button>
          <h1 className="text-[22px] font-medium text-[#1a1a18]">My profile</h1>
          <p className="text-[13px] text-[#5f5e5a] mt-1">Your health intake and progress data</p>
        </header>

        {loading ? (
          <p className="text-center text-[13px] text-[#9a9890] py-10">Loading your profile...</p>
        ) : !latest || !latest.questionnaire || Object.keys(latest.questionnaire).length === 0 ? (
          <Card>
            <p className="text-[14px] text-[#1a1a18]">Profile not found. Please complete the onboarding.</p>
            <div className="mt-4">
              <Link
                to="/onboarding"
                className="inline-block text-[13px] px-4 py-2 rounded-md"
                style={{ background: "#E1F5EE", border: "1px solid #1D9E75", color: "#0F6E56" }}
              >
                Start onboarding →
              </Link>
            </div>
          </Card>
        ) : (
          <>
            {/* Personal details */}
            <Card>
              <div className="flex items-center gap-3">
                <div
                  className="grid place-items-center text-[14px] font-medium"
                  style={{
                    width: 44, height: 44, borderRadius: "50%",
                    background: "#E1F5EE", color: "#0F6E56", border: "0.5px solid #1D9E75",
                  }}
                >
                  {initials}
                </div>
                <div>
                  <div className="text-[15px] font-medium text-[#1a1a18]">{userName}</div>
                  <div className="text-[11px] text-[#9a9890]">Patient account</div>
                </div>
              </div>
              <Divider />
              <Row label="Assigned difficulty">
                <DifficultyPill targetSize={latest.adaptive_profile?.targetSize} />
              </Row>
              <Row label="Member since">
                <span className="text-[13px] text-[#1a1a18]">{formatDate(latest.created_at)}</span>
              </Row>
            </Card>

            {/* Health intake */}
            <Card title="Health intake answers">
              {onboardingQuestions.map((q) => (
                <Field key={q.id} label={q.title}>
                  <AnswerView value={latest.questionnaire?.[q.id]} multi={q.multi} />
                </Field>
              ))}
              <p className="text-[11px] text-[#9a9890] mt-2">
                These answers were used to personalise your therapy plan. Contact your therapist if anything has changed.
              </p>
            </Card>

            {/* Tremor history */}
            <Card title="Tremor check history">
              {tremorHistory.length === 0 ? (
                <div className="text-center py-6">
                  <p className="text-[13px] text-[#5f5e5a] mb-3">No tremor scans yet.</p>
                  <Link
                    to="/assessment/tremor"
                    className="inline-block text-[13px] px-4 py-2 rounded-md"
                    style={{ background: "#E1F5EE", border: "1px solid #1D9E75", color: "#0F6E56" }}
                  >
                    Take tremor check →
                  </Link>
                </div>
              ) : (
                <>
                  <ul className="flex flex-col gap-2">
                    {tremorHistory.map((r) => {
                      const c = SEVERITY_COLORS[r.severity];
                      return (
                        <li key={r.id} className="flex items-center gap-3 py-1">
                          <span style={{ width: 8, height: 8, borderRadius: "50%", background: c.dot }} />
                          <span className="text-[13px] text-[#1a1a18] flex-1">{formatDate(r.date)}</span>
                          <span
                            className="text-[11px] px-2 py-0.5 rounded-full capitalize"
                            style={{ background: c.bg, color: c.text }}
                          >
                            {r.severity}
                          </span>
                          <span className="text-[12px] text-[#5f5e5a] tabular-nums w-[52px] text-right">
                            {r.tremor_index}/100
                          </span>
                        </li>
                      );
                    })}
                  </ul>
                  <div className="mt-4">
                    <canvas ref={chartRef} style={{ width: "100%", height: 80 }} />
                  </div>
                  <div className="mt-3">
                    <Link
                      to="/assessment/tremor"
                      className="inline-block text-[13px] text-[#0F6E56] hover:underline"
                    >
                      Tremor check →
                    </Link>
                  </div>
                </>
              )}
            </Card>
          </>
        )}
      </div>
    </main>
  );
}

function Card({ title, children }: { title?: string; children: React.ReactNode }) {
  return (
    <section
      className="mb-4"
      style={{
        background: "#ffffff",
        border: "1px solid rgba(0,0,0,0.08)",
        borderRadius: 12,
        padding: "18px 20px",
      }}
    >
      {title && <h2 className="text-[14px] font-medium text-[#1a1a18] mb-3">{title}</h2>}
      {children}
    </section>
  );
}

function Divider() {
  return <div className="my-3" style={{ height: 1, background: "rgba(0,0,0,0.06)" }} />;
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between py-1.5">
      <span className="text-[12px] text-[#5f5e5a]">{label}</span>
      {children}
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="mb-3">
      <div className="text-[11px] uppercase tracking-wider text-[#9a9890] mb-1">{label}</div>
      <div className="text-[13px] text-[#1a1a18]">{children}</div>
    </div>
  );
}

function AnswerView({ value, multi }: { value: string | string[] | undefined; multi: boolean }) {
  if (value == null || (Array.isArray(value) && value.length === 0) || value === "") {
    return <span className="text-[13px] text-[#9a9890]">Not provided</span>;
  }
  if (multi || Array.isArray(value)) {
    const items = Array.isArray(value) ? value : [value];
    return (
      <div className="flex flex-wrap gap-1.5">
        {items.map((v) => (
          <span
            key={v}
            className="text-[12px] px-2 py-0.5 rounded-full"
            style={{ background: "#E1F5EE", color: "#0F6E56" }}
          >
            {v}
          </span>
        ))}
      </div>
    );
  }
  return <span>{value}</span>;
}

function DifficultyPill({ targetSize }: { targetSize?: string }) {
  const map: Record<string, { label: string; bg: string; text: string }> = {
    lg: { label: "Easy",   bg: "#E1F5EE", text: "#0F6E56" },
    md: { label: "Medium", bg: "#FAEEDA", text: "#8A5A12" },
    sm: { label: "Hard",   bg: "#FCEBEB", text: "#A32D2D" },
  };
  const v = map[targetSize ?? "md"] ?? map.md;
  return (
    <span
      className="text-[11px] px-2 py-0.5 rounded-full"
      style={{ background: v.bg, color: v.text }}
    >
      {v.label}
    </span>
  );
}