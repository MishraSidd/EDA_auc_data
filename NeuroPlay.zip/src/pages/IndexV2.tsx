// V2 alias — both routes share the unified clinical UI.
import Index from "./Index";
export default Index;
