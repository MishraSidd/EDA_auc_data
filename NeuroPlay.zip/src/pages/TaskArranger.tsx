import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Lightbulb, RotateCcw, CheckCircle2, XCircle, Trophy, Clock, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SpeakButton } from "@/components/SpeakButton";
import { TopBar } from "@/components/TopBar";
import { saveGameSession } from "@/lib/sessionTracker";

type Level = 1 | 2 | 3;

interface TaskDef {
  title: string;
  emoji: string;
  steps: string[]; // correct order
  distractors?: string[];
}

const TASKS: Record<Level, TaskDef[]> = {
  1: [
    { title: "Take Medication", emoji: "💊", steps: ["Pick up the pill bottle", "Pour a glass of water", "Swallow the pill with water"] },
    { title: "Brush Your Teeth", emoji: "🪥", steps: ["Wet the toothbrush", "Apply toothpaste", "Brush for two minutes"] },
    { title: "Wash Your Hands", emoji: "🧼", steps: ["Turn on the tap", "Apply soap and scrub", "Rinse and dry hands"] },
  ],
  2: [
    {
      title: "Make Breakfast (Toast & Tea)",
      emoji: "🍞",
      steps: [
        "Boil water in the kettle",
        "Place bread in the toaster",
        "Pour hot water over the tea bag",
        "Spread butter on the toast",
        "Sit down and enjoy",
      ],
    },
    {
      title: "Get Dressed",
      emoji: "👕",
      steps: [
        "Choose clothes for the day",
        "Put on underwear",
        "Put on shirt",
        "Put on trousers",
        "Put on shoes",
      ],
    },
  ],
  3: [
    {
      title: "Get Ready for a Doctor's Appointment",
      emoji: "🏥",
      steps: [
        "Check the appointment time",
        "Shower and get dressed",
        "Eat a light breakfast",
        "Pack ID and insurance card",
        "Bring your medication list",
        "Lock the front door",
        "Travel to the clinic",
      ],
      distractors: ["Water the garden", "Start a load of laundry"],
    },
    {
      title: "Prepare a Simple Meal",
      emoji: "🍳",
      steps: [
        "Wash your hands",
        "Gather ingredients from the fridge",
        "Heat the pan on the stove",
        "Add oil to the pan",
        "Cook the eggs gently",
        "Plate the food",
        "Turn off the stove",
      ],
      distractors: ["Take out the trash", "Vacuum the living room"],
    },
  ],
};

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

interface Card {
  id: string;
  text: string;
  isDistractor: boolean;
}

const TaskArranger = () => {
  const [level, setLevel] = useState<Level | null>(null);
  const [taskIdx, setTaskIdx] = useState(0);
  const [cards, setCards] = useState<Card[]>([]);
  const [task, setTask] = useState<TaskDef | null>(null);
  const [errors, setErrors] = useState(0);
  const [hintsUsed, setHintsUsed] = useState(0);
  const [hintIndex, setHintIndex] = useState<number | null>(null);
  const [startTime, setStartTime] = useState<number | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const [completed, setCompleted] = useState(false);
  const [feedback, setFeedback] = useState<{ id: string; type: "ok" | "bad" } | null>(null);
  // Click-to-order: maps card id -> 1-based order chosen by the patient.
  // Double-click a card to deselect it.
  const [order, setOrder] = useState<Record<string, number>>({});

  // timer
  useEffect(() => {
    if (!startTime || completed) return;
    const t = setInterval(() => setElapsed(Math.floor((Date.now() - startTime) / 1000)), 250);
    return () => clearInterval(t);
  }, [startTime, completed]);

  function startLevel(l: Level) {
    const idx = Math.floor(Math.random() * TASKS[l].length);
    const t = TASKS[l][idx];
    const all: Card[] = [
      ...t.steps.map((s, i) => ({ id: `s-${i}`, text: s, isDistractor: false })),
      ...(t.distractors || []).map((s, i) => ({ id: `d-${i}`, text: s, isDistractor: true })),
    ];
    setLevel(l);
    setTaskIdx(idx);
    setTask(t);
    setCards(shuffle(all));
    setErrors(0);
    setHintsUsed(0);
    setHintIndex(null);
    setStartTime(Date.now());
    setElapsed(0);
    setCompleted(false);
    setFeedback(null);
    setOrder({});
  }

  function reset() {
    setLevel(null);
    setTask(null);
    setCards([]);
    setStartTime(null);
    setCompleted(false);
    setOrder({});
  }

  // Single click: assign next available order number to the card.
  // If already ordered, do nothing (use double-click to deselect).
  function pickCard(id: string) {
    setOrder((prev) => {
      if (prev[id]) return prev;
      const used = Object.values(prev);
      const next = (used.length ? Math.max(...used) : 0) + 1;
      return { ...prev, [id]: next };
    });
  }

  // Double click: remove card from the ordering and re-number remaining picks
  // so numbers stay contiguous (1, 2, 3, ...).
  function deselectCard(id: string) {
    setOrder((prev) => {
      if (!prev[id]) return prev;
      const entries = Object.entries(prev)
        .filter(([cid]) => cid !== id)
        .sort((a, b) => a[1] - b[1]);
      const renum: Record<string, number> = {};
      entries.forEach(([cid], i) => (renum[cid] = i + 1));
      return renum;
    });
  }

  function checkAnswer() {
    if (!task) return;
    const correctOrder = task.steps;
    // Build the patient's answer from the click-order map.
    const picked = Object.entries(order)
      .sort((a, b) => a[1] - b[1])
      .map(([cid]) => cards.find((c) => c.id === cid))
      .filter(Boolean) as Card[];

    let totalMistakes = 0;
    // Must have selected exactly the right number of cards.
    if (picked.length !== correctOrder.length) {
      totalMistakes += Math.abs(picked.length - correctOrder.length);
    }
    for (let i = 0; i < correctOrder.length; i++) {
      const p = picked[i];
      if (!p || p.isDistractor || p.text !== correctOrder[i]) totalMistakes++;
    }

    if (totalMistakes === 0) {
      setCompleted(true);
      setFeedback(null);
      const duration = startTime ? Math.round((Date.now() - startTime) / 1000) : elapsed;
      const accuracy = Math.max(0, 100 - errors * 10 - hintsUsed * 5);
      void saveGameSession({
        gameName: "Task Arranger",
        score: accuracy,
        accuracyPercent: accuracy,
        errors,
        durationSeconds: duration,
        levelReached: level ?? undefined,
        difficulty: level ? `level-${level}` : undefined,
        roundsTotal: task.steps.length,
        roundsCorrect: task.steps.length,
        sessionData: {
          taskTitle: task.title,
          hintsUsed,
          stepCount: task.steps.length,
          distractors: task.distractors?.length ?? 0,
        },
      });
      return;
    }
    setErrors((e) => e + 1);
    // Highlight the first wrongly-placed card briefly.
    const firstWrong = picked.find((c, i) => c.isDistractor || c.text !== correctOrder[i]);
    if (firstWrong) {
      setFeedback({ id: firstWrong.id, type: "bad" });
      setTimeout(() => setFeedback(null), 900);
    }
  }

  function useHint() {
    if (!task) return;
    setHintsUsed((h) => h + 1);
    // Find first slot in the patient's picks that is wrong; if none, point to the next missing slot.
    const correct = task.steps;
    const picked = Object.entries(order)
      .sort((a, b) => a[1] - b[1])
      .map(([cid]) => cards.find((c) => c.id === cid)) as (Card | undefined)[];
    for (let i = 0; i < correct.length; i++) {
      const c = picked[i];
      if (!c || c.isDistractor || c.text !== correct[i]) {
        setHintIndex(i);
        setTimeout(() => setHintIndex(null), 2500);
        return;
      }
    }
  }

  // ----- UI -----
  if (!level) {
    return (
      <main className="min-h-screen bg-background">
        <TopBar />
        <div className="max-w-3xl mx-auto px-4 py-8">
          <Link to="/" className="inline-flex items-center gap-2 text-[13px] text-muted-foreground mb-6 hover:text-foreground">
            <ArrowLeft className="w-4 h-4" /> Back
          </Link>
          <h1 className="text-[24px] font-medium mb-2">Task Arranger</h1>
          <p className="text-muted-foreground mb-8 text-[14px]">
            Put the steps in the correct order to complete a real-life task. Trains planning, sequencing,
            and safety awareness.
          </p>
          <div className="mb-6">
            <SpeakButton
              autoPlay
              text="Welcome to Task Arranger. Choose a level below. You will see cards with the steps of an everyday task in the wrong order. Drag and drop the cards to put them in the correct order from top to bottom. Tap Check Order when you are done. You can also tap the Hint button at any time for free help."
            />
          </div>
          <div className="grid sm:grid-cols-3 gap-4">
            {[1, 2, 3].map((n) => (
              <button
                key={n}
                onClick={() => startLevel(n as Level)}
                className="bg-card border border-border rounded-3xl p-6 text-left hover:-translate-y-1 hover:shadow-lg transition-all"
              >
                <div className="text-3xl font-extrabold text-game-blue mb-1">Level {n}</div>
                <div className="text-sm text-muted-foreground">
                  {n === 1 && "3 steps · easy warm-up"}
                  {n === 2 && "5 steps · everyday routine"}
                  {n === 3 && "7 steps + 2 distractors"}
                </div>
              </button>
            ))}
          </div>
        </div>
      </main>
    );
  }

  if (completed && task) {
    return (
      <main className="min-h-screen bg-background">
        <div className="max-w-2xl mx-auto px-4 py-12 text-center">
          <div className="inline-flex w-20 h-20 rounded-full bg-success/15 text-success items-center justify-center mb-4">
            <Trophy className="w-10 h-10" />
          </div>
          <h1 className="text-4xl font-extrabold mb-2">Great work!</h1>
          <p className="text-lg text-muted-foreground mb-8">You completed: {task.title}</p>
          <div className="mb-6 flex justify-center">
            <SpeakButton
              autoPlay
              text={`Great work! You completed ${task.title}. Your time was ${elapsed} seconds. You made ${errors} ${errors === 1 ? "error" : "errors"} and used ${hintsUsed} ${hintsUsed === 1 ? "hint" : "hints"}.`}
            />
          </div>
          <div className="grid grid-cols-3 gap-3 mb-8">
            <Stat label="Time" value={`${elapsed}s`} icon={<Clock className="w-4 h-4" />} />
            <Stat label="Errors" value={String(errors)} icon={<XCircle className="w-4 h-4" />} />
            <Stat label="Hints" value={String(hintsUsed)} icon={<Lightbulb className="w-4 h-4" />} />
          </div>
          <div className="flex gap-3 justify-center">
            <Button onClick={() => startLevel(level)} className="rounded-2xl h-12 px-6">
              <RotateCcw className="w-4 h-4" /> Play Again
            </Button>
            <Button variant="secondary" onClick={reset} className="rounded-2xl h-12 px-6">
              Choose Level
            </Button>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-background">
      <div className="max-w-3xl mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-4">
          <button onClick={reset} className="inline-flex items-center gap-2 text-sm font-bold hover:underline">
            <ArrowLeft className="w-4 h-4" /> Levels
          </button>
          <div className="flex items-center gap-3 text-sm font-bold">
            <span className="inline-flex items-center gap-1"><Clock className="w-4 h-4" /> {elapsed}s</span>
            <span className="inline-flex items-center gap-1"><XCircle className="w-4 h-4" /> {errors}</span>
            <span className="inline-flex items-center gap-1"><Lightbulb className="w-4 h-4" /> {hintsUsed}</span>
          </div>
        </div>

        <div className="bg-secondary rounded-3xl p-5 mb-5 flex items-center gap-4">
          <div className="text-4xl">{task?.emoji}</div>
          <div className="flex-1">
            <div className="text-xs uppercase tracking-wider text-muted-foreground font-bold">Task · Level {level}</div>
            <h1 className="text-2xl font-extrabold leading-tight">{task?.title}</h1>
          </div>
          {task && (
            <SpeakButton
              autoPlay
              text={`Your task is: ${task.title}. Drag the cards to put the steps in the correct order from top to bottom. When you are ready, tap Check Order. You can tap Hint at any time for free help.${task.distractors?.length ? " Watch out — some cards are not part of this task and should be left at the bottom." : ""}`}
            />
          )}
        </div>

        <p className="text-muted-foreground text-sm mb-3">
          Tap each card in the correct order. The number on the card shows your chosen position.
          Double-tap a card to deselect it.
          {task?.distractors?.length ? " Watch out — some steps don't belong!" : ""}
        </p>

        <ol className="flex flex-col gap-2 mb-5">
          {cards.map((c, i) => {
            const pickedNum = order[c.id];
            const isHint =
              hintIndex !== null &&
              task &&
              !c.isDistractor &&
              c.text === task.steps[hintIndex];
            const isBad = feedback?.id === c.id && feedback.type === "bad";
            const inSlot = !!pickedNum;
            return (
              <li
                key={c.id}
                onClick={() => pickCard(c.id)}
                onDoubleClick={() => deselectCard(c.id)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    pickedNum ? deselectCard(c.id) : pickCard(c.id);
                  }
                }}
                className={`group flex items-center gap-3 bg-card border-2 rounded-2xl p-4 cursor-pointer select-none transition-all ${
                  isBad
                    ? "border-destructive bg-destructive/5"
                    : isHint
                      ? "border-game-blue bg-game-blue/10"
                      : pickedNum
                        ? "border-foreground/60"
                        : "border-border hover:border-foreground/40"
                }`}
              >
                <span
                  className={`w-9 h-9 rounded-full grid place-items-center font-extrabold text-sm shrink-0 ${
                    inSlot ? "bg-foreground text-background" : "bg-muted text-muted-foreground"
                  }`}
                >
                  {pickedNum ?? "•"}
                </span>
                <span className="flex-1 text-base font-bold">{c.text}</span>
                {isHint && task && hintIndex !== null && (
                  <span className="text-xs font-bold text-game-blue hidden sm:block">
                    Try: "{task.steps[hintIndex]}"
                  </span>
                )}
                <span className="text-muted-foreground text-xs">{pickedNum ? "double-tap to clear" : "tap to pick"}</span>
              </li>
            );
          })}
        </ol>

        {task?.distractors?.length ? (
          <div className="text-xs text-muted-foreground mb-4 inline-flex items-center gap-1">
            <AlertTriangle className="w-3 h-3" /> Pick exactly {task.steps.length} cards — leave any extras unselected.
          </div>
        ) : null}

        <div className="flex flex-wrap gap-3">
          <Button onClick={checkAnswer} className="rounded-2xl h-12 px-6 text-base">
            <CheckCircle2 className="w-5 h-5" /> Check Order
          </Button>
          <Button variant="secondary" onClick={useHint} className="rounded-2xl h-12 px-6 text-base">
            <Lightbulb className="w-5 h-5" /> Hint (free)
          </Button>
          <Button variant="ghost" onClick={() => startLevel(level)} className="rounded-2xl h-12 px-6 text-base">
            <RotateCcw className="w-5 h-5" /> Restart
          </Button>
        </div>
      </div>
    </main>
  );
};

const Stat = ({ label, value, icon }: { label: string; value: string; icon: React.ReactNode }) => (
  <div className="bg-card border border-border rounded-2xl p-4">
    <div className="text-xs text-muted-foreground font-bold inline-flex items-center gap-1">{icon} {label}</div>
    <div className="text-2xl font-extrabold mt-1">{value}</div>
  </div>
);

export default TaskArranger;