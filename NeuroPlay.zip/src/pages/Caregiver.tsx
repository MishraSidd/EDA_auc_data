import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Loader2, FileText, Download } from "lucide-react";
import { TopBar } from "@/components/TopBar";
import { supabase } from "@/integrations/supabase/client";
import { getUserId } from "@/features/assessment/useAdaptiveProfile";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Legend,
} from "recharts";

interface GameRow {
  created_at: string;
  played_at: string;
  game: string | null;
  game_name: string | null;
  score: number;
  accuracy: number;
  accuracy_percent: number;
  errors: number;
  duration_seconds: number;
  duration_sec: number;
}
interface MoodRow {
  logged_at: string;
  mood_score: number | null;
  mood_value: number;
  mood_label: string;
}
interface TaskRow {
  completed_at: string;
  task_name: string;
  was_completed: boolean;
  delay_minutes: number;
}

const dayKey = (d: Date) => d.toISOString().slice(0, 10);
const dayLabel = (d: Date) =>
  d.toLocaleDateString(undefined, { weekday: "short" });

export default function Caregiver() {
  const [games, setGames] = useState<GameRow[]>([]);
  const [moods, setMoods] = useState<MoodRow[]>([]);
  const [tasks, setTasks] = useState<TaskRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [reportLoading, setReportLoading] = useState(false);
  const [reportError, setReportError] = useState<string | null>(null);
  const [report, setReport] = useState<string | null>(null);

  const generateReport = async () => {
    setReportLoading(true);
    setReportError(null);
    try {
      const { data, error } = await supabase.functions.invoke(
        "generate-weekly-report",
        { body: {} },
      );
      if (error) throw error;
      setReport(data?.report ?? "No report returned.");
    } catch (e: any) {
      setReportError(e?.message ?? "Failed to generate report");
    } finally {
      setReportLoading(false);
    }
  };

  const downloadReport = () => {
    if (!report) return;
    const date = new Date().toISOString().slice(0, 10);
    const tableLines = perGameStats.length
      ? [
          "",
          "Game performance (last 7 days)",
          "Game | Sessions | Avg score | Avg accuracy | Practice (min) | Errors",
          ...perGameStats.map(
            (r) =>
              `${r.name} | ${r.sessions} | ${r.avgScore} | ${r.avgAcc}% | ${r.minutes} | ${r.errors}`,
          ),
        ]
      : [];
    const content = [
      `Weekly Clinical Report — ${date}`,
      "=".repeat(48),
      "",
      report,
      ...tableLines,
    ].join("\n");
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `weekly-report-${date}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  useEffect(() => {
    const userId = getUserId();
    const since = new Date();
    since.setDate(since.getDate() - 6);
    since.setHours(0, 0, 0, 0);
    const sinceIso = since.toISOString();
    (async () => {
      const [g, m, t] = await Promise.all([
        supabase
          .from("game_sessions")
          .select(
            "created_at,played_at,game,game_name,score,accuracy,accuracy_percent,errors,duration_seconds,duration_sec",
          )
          .eq("user_id", userId)
          .gte("played_at", sinceIso)
          .order("played_at", { ascending: true }),
        supabase
          .from("mood_logs")
          .select("logged_at,mood_score,mood_value,mood_label")
          .eq("user_id", userId)
          .gte("logged_at", sinceIso)
          .order("logged_at", { ascending: true }),
        supabase
          .from("task_logs")
          .select("completed_at,task_name,was_completed,delay_minutes")
          .eq("user_id", userId)
          .gte("completed_at", sinceIso)
          .order("completed_at", { ascending: true }),
      ]);
      setGames((g.data ?? []) as GameRow[]);
      setMoods((m.data ?? []) as MoodRow[]);
      setTasks((t.data ?? []) as TaskRow[]);
      setLoading(false);
    })();
  }, []);

  // Build per-day buckets for the last 7 days.
  const days = useMemo(() => {
    const arr: { key: string; label: string }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      d.setHours(0, 0, 0, 0);
      arr.push({ key: dayKey(d), label: dayLabel(d) });
    }
    return arr;
  }, []);

  const chartData = useMemo(() => {
    return days.map(({ key, label }) => {
      const dayGames = games.filter(
        (g) => (g.played_at || g.created_at).slice(0, 10) === key,
      );
      const dayMoods = moods.filter((m) => m.logged_at.slice(0, 10) === key);
      const accuracy = dayGames.length
        ? Math.round(
            dayGames.reduce(
              (a, g) => a + Number(g.accuracy_percent ?? g.accuracy ?? 0),
              0,
            ) / dayGames.length,
          )
        : 0;
      const score = dayGames.length
        ? Math.round(
            dayGames.reduce((a, g) => a + Number(g.score ?? 0), 0) /
              dayGames.length,
          )
        : 0;
      const mood = dayMoods.length
        ? Math.round(
            (dayMoods.reduce(
              (a, m) => a + Number(m.mood_score ?? m.mood_value ?? 0),
              0,
            ) /
              dayMoods.length) *
              20,
          ) // scale 1–5 to 0–100
        : 0;
      return { name: label, Accuracy: accuracy, Score: score, Mood: mood };
    });
  }, [days, games, moods]);

  const sessionsCount = games.length;
  const avgAccuracy = sessionsCount
    ? Math.round(
        games.reduce(
          (a, g) => a + Number(g.accuracy_percent ?? g.accuracy ?? 0),
          0,
        ) / sessionsCount,
      )
    : 0;
  const tasksCompleted = tasks.filter((t) => t.was_completed).length;
  const taskRate = tasks.length
    ? Math.round((tasksCompleted / tasks.length) * 100)
    : 0;
  const avgMood = moods.length
    ? (
        moods.reduce(
          (a, m) => a + Number(m.mood_score ?? m.mood_value ?? 0),
          0,
        ) / moods.length
      ).toFixed(1)
    : "—";
  const avgDelay = tasks.length
    ? Math.round(
        tasks.reduce((a, t) => a + Number(t.delay_minutes ?? 0), 0) /
          tasks.length,
      )
    : 0;
  const totalMinutes = Math.round(
    games.reduce(
      (a, g) => a + Number(g.duration_seconds ?? g.duration_sec ?? 0),
      0,
    ) / 60,
  );

  // Per-game breakdown for the table-style summary line.
  const gameNames = Array.from(
    new Set(games.map((g) => g.game_name || g.game || "Unknown")),
  );

  // Per-game performance table rows (sessions, avg score, avg accuracy, total min, errors).
  const perGameStats = useMemo(() => {
    const map = new Map<
      string,
      { sessions: number; score: number; acc: number; secs: number; errors: number }
    >();
    for (const g of games) {
      const name = g.game_name || g.game || "Unknown";
      const cur = map.get(name) ?? { sessions: 0, score: 0, acc: 0, secs: 0, errors: 0 };
      cur.sessions += 1;
      cur.score += Number(g.score ?? 0);
      cur.acc += Number(g.accuracy_percent ?? g.accuracy ?? 0);
      cur.secs += Number(g.duration_seconds ?? g.duration_sec ?? 0);
      cur.errors += Number(g.errors ?? 0);
      map.set(name, cur);
    }
    return Array.from(map.entries())
      .map(([name, v]) => ({
        name,
        sessions: v.sessions,
        avgScore: Math.round(v.score / v.sessions),
        avgAcc: Math.round(v.acc / v.sessions),
        minutes: Math.round(v.secs / 60),
        errors: v.errors,
      }))
      .sort((a, b) => b.sessions - a.sessions);
  }, [games]);

  return (
    <main className="min-h-screen bg-background">
      <TopBar />
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        <Link to="/" className="inline-flex items-center gap-2 text-[13px] text-muted-foreground mb-6 hover:text-foreground">
          <ArrowLeft className="w-4 h-4" /> Back to dashboard
        </Link>

        <header className="mb-6">
          <h1 className="text-[24px] font-medium">Caregiver overview</h1>
          <p className="text-[13px] text-muted-foreground mt-1">
            Last 7 days of rehabilitation activity. Not a clinical assessment.
          </p>
        </header>

        <section className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          <Metric label="Sessions (7d)" value={`${sessionsCount}`} />
          <Metric label="Avg accuracy" value={sessionsCount ? `${avgAccuracy}%` : "—"} />
          <Metric label="Task completion" value={tasks.length ? `${taskRate}%` : "—"} />
          <Metric label="Avg mood" value={`${avgMood}`} />
        </section>

        <section className="bg-card border border-border rounded-md p-4 mb-6">
          <h2 className="text-[13px] font-medium mb-4">Rehabilitation trends (last 7 days)</h2>
          {loading ? (
            <p className="text-[13px] text-muted-foreground">Loading…</p>
          ) : sessionsCount === 0 && moods.length === 0 ? (
            <p className="text-[13px] text-muted-foreground">
              No activity logged in the last 7 days yet.
            </p>
          ) : (
            <div className="w-full h-[280px]">
              <ResponsiveContainer>
                <LineChart data={chartData} margin={{ left: 0, right: 8, top: 8, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" />
                  <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#5f5e5a" }} />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: "#5f5e5a" }} />
                  <Tooltip />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Line type="monotone" dataKey="Accuracy" stroke="#0F6E56" strokeWidth={2} dot={{ r: 3 }} />
                  <Line type="monotone" dataKey="Score" stroke="#1D9E75" strokeWidth={2} dot={{ r: 3 }} />
                  <Line type="monotone" dataKey="Mood" stroke="#9FE1CB" strokeWidth={2} dot={{ r: 3 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
        </section>

        <section className="bg-card border border-border rounded-md p-6">
          <h2 className="text-[13px] font-medium mb-3">Weekly summary</h2>
          <ul className="text-[14px] space-y-2 text-foreground">
            <li>
              • {sessionsCount} game session{sessionsCount === 1 ? "" : "s"} across{" "}
              {gameNames.length} game{gameNames.length === 1 ? "" : "s"}
              {gameNames.length > 0 && ` (${gameNames.slice(0, 4).join(", ")})`}.
            </li>
            <li>
              • Total practice time: {totalMinutes} min · average accuracy{" "}
              {sessionsCount ? `${avgAccuracy}%` : "—"}.
            </li>
            <li>
              • Tasks: {tasksCompleted}/{tasks.length} completed (
              {tasks.length ? `${taskRate}%` : "—"}) — average delay {avgDelay} min
              from scheduled time.
            </li>
            <li>
              • Mood entries: {moods.length} logged, average {avgMood}/5
              {taskRate >= 80 ? " — excellent adherence." : taskRate >= 60 ? " — steady progress." : " — could use encouragement."}
            </li>
          </ul>
        </section>

        <section className="mt-6 bg-card border border-border rounded-md p-6">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div>
              <h2 className="text-[13px] font-medium">Weekly clinical report</h2>
              <p className="text-[12px] text-muted-foreground mt-1">
                AI-generated 7-day summary based on games, mood and tasks.
              </p>
            </div>
            <div className="flex items-center gap-3 flex-wrap">
              {report && !reportLoading && (
                <button
                  onClick={downloadReport}
                  className="inline-flex items-center gap-2 text-[13px] text-foreground hover:underline"
                >
                  <Download className="w-4 h-4" /> Download report
                </button>
              )}
              <button
              onClick={generateReport}
              disabled={reportLoading}
              className="inline-flex items-center gap-2 text-[13px] text-[#0F6E56] hover:underline disabled:opacity-60"
            >
              {reportLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <FileText className="w-4 h-4" />
              )}
              {reportLoading ? "Generating…" : report ? "Regenerate weekly report" : "Generate weekly report"}
              </button>
            </div>
          </div>

          {reportError && (
            <p className="mt-4 text-[13px] text-[#E24B4A]">{reportError}</p>
          )}

          {report && !reportLoading && (
            <div className="mt-5 border-t border-border pt-5">
              <pre className="whitespace-pre-wrap text-[13px] leading-relaxed font-sans text-foreground">
                {report}
              </pre>

              <h3 className="text-[13px] font-medium mt-6 mb-2">Game performance (last 7 days)</h3>
              {perGameStats.length === 0 ? (
                <p className="text-[13px] text-muted-foreground">
                  No game sessions logged in the last 7 days.
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-[13px] border-collapse">
                    <thead>
                      <tr className="text-left text-muted-foreground border-b border-border">
                        <th className="py-2 pr-3 font-medium">Game</th>
                        <th className="py-2 pr-3 font-medium">Sessions</th>
                        <th className="py-2 pr-3 font-medium">Avg score</th>
                        <th className="py-2 pr-3 font-medium">Avg accuracy</th>
                        <th className="py-2 pr-3 font-medium">Practice (min)</th>
                        <th className="py-2 pr-3 font-medium">Errors</th>
                      </tr>
                    </thead>
                    <tbody>
                      {perGameStats.map((row) => (
                        <tr key={row.name} className="border-b border-border/60">
                          <td className="py-2 pr-3 capitalize">{row.name}</td>
                          <td className="py-2 pr-3">{row.sessions}</td>
                          <td className="py-2 pr-3">{row.avgScore}</td>
                          <td className="py-2 pr-3">{row.avgAcc}%</td>
                          <td className="py-2 pr-3">{row.minutes}</td>
                          <td className="py-2 pr-3">{row.errors}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </section>
      </div>
    </main>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-card border border-border rounded-md p-4">
      <div className="text-[22px] font-medium leading-none">{value}</div>
      <div className="text-[11px] uppercase tracking-wide text-muted-foreground mt-2">{label}</div>
    </div>
  );
}