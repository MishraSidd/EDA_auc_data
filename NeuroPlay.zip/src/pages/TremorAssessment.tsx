import { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, RotateCcw, Check } from "lucide-react";
import { TopBar } from "@/components/TopBar";
import { Button } from "@/components/ui/button";
import { analyzeTremor, type TremorPoint, type TremorResult } from "@/features/assessment/tremorAnalysis";
import { supabase } from "@/integrations/supabase/client";
import { getUserId } from "@/features/assessment/useAdaptiveProfile";
import { computeMetrics, deriveProfile } from "@/features/assessment/scoringEngine";
import { saveGameSession } from "@/lib/sessionTracker";

export default function TremorAssessment() {
  const navigate = useNavigate();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawingRef = useRef(false);
  const pointsRef = useRef<TremorPoint[]>([]);
  const startRef = useRef(0);
  const [result, setResult] = useState<TremorResult | null>(null);
  const [saving, setSaving] = useState(false);
  const [motionEnabled, setMotionEnabled] = useState(false);

  // Setup canvas, draw guide ∞
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.scale(dpr, dpr);
    drawGuide(ctx, rect.width, rect.height);
  }, []);

  // Optional motion sensor sampling — silent, just to invoke API per spec
  useEffect(() => {
    if (!motionEnabled) return;
    const handler = () => {};
    window.addEventListener("devicemotion", handler);
    return () => window.removeEventListener("devicemotion", handler);
  }, [motionEnabled]);

  function drawGuide(ctx: CanvasRenderingContext2D, w: number, h: number) {
    ctx.clearRect(0, 0, w, h);
    ctx.strokeStyle = "rgba(15,110,86,0.18)";
    ctx.setLineDash([6, 6]);
    ctx.lineWidth = 2;
    ctx.beginPath();
    const cx = w / 2, cy = h / 2;
    const rw = w * 0.38, rh = h * 0.32;
    for (let i = 0; i <= 200; i++) {
      const t = (i / 200) * 2 * Math.PI;
      const x = cx + rw * Math.cos(t);
      const y = cy + rh * Math.sin(t) * Math.cos(t);
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.setLineDash([]);
  }

  const getCanvasPoint = (e: React.PointerEvent) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };

  const onDown = (e: React.PointerEvent) => {
    drawingRef.current = true;
    pointsRef.current = [];
    startRef.current = performance.now();
    setResult(null);
    const canvas = canvasRef.current!;
    canvas.setPointerCapture(e.pointerId);
    const ctx = canvas.getContext("2d")!;
    const rect = canvas.getBoundingClientRect();
    drawGuide(ctx, rect.width, rect.height);
    const p = getCanvasPoint(e);
    pointsRef.current.push({ x: p.x, y: p.y, t: 0 });
    ctx.strokeStyle = "#0F6E56";
    ctx.lineWidth = 3;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(p.x, p.y);
  };

  const onMove = (e: React.PointerEvent) => {
    if (!drawingRef.current) return;
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext("2d")!;
    const p = getCanvasPoint(e);
    pointsRef.current.push({ x: p.x, y: p.y, t: performance.now() - startRef.current });
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
  };

  const onUp = () => {
    if (!drawingRef.current) return;
    drawingRef.current = false;
    const r = analyzeTremor(pointsRef.current);
    setResult(r);
  };

  const reset = () => {
    setResult(null);
    pointsRef.current = [];
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext("2d")!;
    const rect = canvas.getBoundingClientRect();
    drawGuide(ctx, rect.width, rect.height);
  };

  const enableMotion = async () => {
    type DM = { requestPermission?: () => Promise<"granted" | "denied"> };
    const Anyev = (window as unknown as { DeviceMotionEvent?: DM }).DeviceMotionEvent;
    if (Anyev?.requestPermission) {
      try {
        const res = await Anyev.requestPermission();
        setMotionEnabled(res === "granted");
        return;
      } catch { /* ignore */ }
    }
    setMotionEnabled(true);
  };

  const save = async () => {
    if (!result) return;
    setSaving(true);
    const userId = getUserId();
    // Pull most recent questionnaire to recompute metrics with tremor data
    const { data } = await supabase
      .from("assessments")
      .select("questionnaire")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(1);
    const qa = (data?.[0]?.questionnaire as never) ?? {};
    const tremor = {
      smoothness: result.smoothness,
      deviation: result.deviation,
      velocityVariation: result.velocityVariation,
    };
    const metrics = computeMetrics(qa, tremor);
    const profile = deriveProfile(metrics);
    await supabase.from("assessments").insert({
      user_id: userId,
      questionnaire: qa,
      ...metrics,
      tremor_smoothness: result.smoothness,
      tremor_deviation: result.deviation,
      tremor_velocity_var: result.velocityVariation,
      adaptive_profile: profile as never,
    });
    await saveGameSession({
      gameName: "Tremor Assessment",
      score: result.smoothness,
      accuracyPercent: Math.max(0, 100 - result.deviation),
      errors: 0,
      durationSeconds: Math.round((performance.now() - startRef.current) / 1000),
      levelReached: "infinity-trace",
      sessionData: {
        smoothness: result.smoothness,
        deviation: result.deviation,
        velocityVariation: result.velocityVariation,
        points: pointsRef.current.length,
      },
    });
    setSaving(false);
    localStorage.setItem("np_onboarded", "1");
    navigate("/?welcome=1", { replace: true });
  };

  return (
    <main className="min-h-screen bg-background">
      <TopBar />
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
        <Link to="/" className="inline-flex items-center gap-2 text-[13px] text-muted-foreground mb-6 hover:text-foreground">
          <ArrowLeft className="w-4 h-4" /> Back to dashboard
        </Link>

        <header className="mb-6">
          <h1 className="text-[24px] font-medium">Tremor & motion check</h1>
          <p className="text-[13px] text-muted-foreground mt-1 max-w-prose">
            Trace the dotted infinity shape with your finger or mouse, in one continuous motion.
            This is a rehabilitation indicator — not a medical diagnosis.
          </p>
        </header>

        <section className="bg-card border border-border rounded-md p-3 sm:p-4">
          <canvas
            ref={canvasRef}
            onPointerDown={onDown}
            onPointerMove={onMove}
            onPointerUp={onUp}
            onPointerCancel={onUp}
            className="w-full h-[320px] sm:h-[380px] touch-none rounded-md bg-background"
            style={{ touchAction: "none" }}
          />
          <div className="flex flex-wrap items-center justify-between gap-2 mt-3">
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={reset}>
                <RotateCcw className="w-4 h-4" /> Reset
              </Button>
              {!motionEnabled && (
                <Button variant="ghost" size="sm" onClick={enableMotion}>
                  Enable motion sensor
                </Button>
              )}
            </div>
            <span className="text-[11px] text-muted-foreground uppercase tracking-wide">
              {motionEnabled ? "Motion sensor on" : "Touch only"}
            </span>
          </div>
        </section>

        {result && (
          <section className="mt-6 bg-card border border-border rounded-md p-6">
            <h2 className="text-[15px] font-medium mb-4">Your stability indicators</h2>
            <dl className="grid grid-cols-3 gap-4 mb-6">
              <Stat label="Smoothness" value={`${result.smoothness}`} />
              <Stat label="Path adherence" value={`${100 - result.deviation}`} />
              <Stat label="Steadiness" value={`${100 - result.velocityVariation}`} />
            </dl>
            <p className="text-[13px] text-muted-foreground mb-6">
              We'll use these to right-size your game targets and pacing. You can retry as
              many times as you'd like.
            </p>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={reset}>Try again</Button>
              <Button onClick={save} disabled={saving}>
                <Check className="w-4 h-4" /> {saving ? "Saving…" : "Save & continue"}
              </Button>
            </div>
          </section>
        )}
      </div>
    </main>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="border border-border rounded-md p-3">
      <div className="text-[22px] font-medium leading-none">{value}</div>
      <div className="text-[11px] uppercase tracking-wide text-muted-foreground mt-2">{label}</div>
    </div>
  );
}