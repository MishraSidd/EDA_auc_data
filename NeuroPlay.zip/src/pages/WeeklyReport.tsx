import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { TopBar } from "@/components/TopBar";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import { Download, RefreshCw, Loader2 } from "lucide-react";

type GameStat = {
  game: string;
  sessions: number;
  avg_score: number;
  avg_accuracy: number;
  avg_errors: number;
  accuracy_trend: string;
  scores_over_time: { date: string; score: number; accuracy: number }[];
};

type Stats = {
  window: { start: string; end: string };
  mood: {
    average: number;
    trend: string;
    entries: number;
    chart: { date: string; value: number; label: string }[];
  };
  games: GameStat[];
  tasks: {
    total: number;
    completed: number;
    completion_rate_pct: number;
    most_missed: string;
    avg_delay_minutes: number;
  };
  totals: { sessions: number; total_time_minutes: number };
};

function parseSections(text: string) {
  const headings = [
    "Weekly Summary",
    "What Went Well",
    "Areas of Concern",
    "Recommendations for Next Week",
    "Therapist Notes",
  ];
  const out: { title: string; body: string }[] = [];
  for (let i = 0; i < headings.length; i++) {
    const start = text.search(new RegExp(`\\d\\)\\s*${headings[i]}`, "i"));
    if (start === -1) continue;
    const next =
      i + 1 < headings.length
        ? text.search(new RegExp(`\\d\\)\\s*${headings[i + 1]}`, "i"))
        : -1;
    const body = text
      .slice(start, next === -1 ? undefined : next)
      .replace(new RegExp(`^\\d\\)\\s*${headings[i]}\\s*:?`, "i"), "")
      .trim();
    out.push({ title: headings[i], body });
  }
  return out.length ? out : [{ title: "Report", body: text }];
}

const prettyGame = (g: string) =>
  g
    .replace(/_/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());

export default function WeeklyReport() {
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<Stats | null>(null);
  const [report, setReport] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const cardRef = useRef<HTMLDivElement>(null);

  const generate = async () => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase.functions.invoke(
        "generate-weekly-report",
        { body: {} },
      );
      if (error) throw error;
      setStats(data.stats);
      setReport(data.report);
    } catch (e: any) {
      setError(e?.message ?? "Failed to generate report");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    generate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const downloadPdf = async () => {
    if (!cardRef.current) return;
    const canvas = await html2canvas(cardRef.current, {
      backgroundColor: "#ffffff",
      scale: 2,
    });
    const img = canvas.toDataURL("image/png");
    const pdf = new jsPDF("p", "mm", "a4");
    const pageW = pdf.internal.pageSize.getWidth();
    const pageH = pdf.internal.pageSize.getHeight();
    const imgH = (canvas.height * pageW) / canvas.width;
    let heightLeft = imgH;
    let position = 0;
    pdf.addImage(img, "PNG", 0, position, pageW, imgH);
    heightLeft -= pageH;
    while (heightLeft > 0) {
      position = heightLeft - imgH;
      pdf.addPage();
      pdf.addImage(img, "PNG", 0, position, pageW, imgH);
      heightLeft -= pageH;
    }
    pdf.save(`mary-weekly-report-${new Date().toISOString().slice(0, 10)}.pdf`);
  };

  const sections = report ? parseSections(report) : [];

  return (
    <main className="min-h-screen bg-background">
      <TopBar initials="MA" />
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center justify-between mb-6 gap-3 flex-wrap">
          <div>
            <h1 className="text-[24px] font-medium leading-tight">Weekly report</h1>
            <p className="text-[13px] text-muted-foreground mt-1">Mary — 7 day clinical summary</p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={generate}
              disabled={loading}
              className="rounded-md"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <RefreshCw className="w-4 h-4 mr-2" />
              )}
              Regenerate
            </Button>
            <Button
              onClick={downloadPdf}
              disabled={loading || !stats}
              className="rounded-md"
            >
              <Download className="w-4 h-4 mr-2" /> Download PDF
            </Button>
          </div>
        </div>

        {error && (
          <div className="mb-6 p-4 rounded-md border border-border bg-card text-sm">
            {error}
          </div>
        )}

        <div
          ref={cardRef}
          className="bg-card rounded-md border border-border p-6 sm:p-8 space-y-8"
        >
          {stats && (
            <header className="pb-4 border-b border-border">
              <p className="text-[12px] uppercase tracking-wide text-muted-foreground">Reporting window</p>
              <p className="text-[14px] mt-1">{stats.window.start} → {stats.window.end}</p>
            </header>
          )}

          {loading && !stats && (
            <div className="flex items-center justify-center py-20 text-muted-foreground">
              <Loader2 className="w-6 h-6 animate-spin mr-3" /> Generating
              clinical summary...
            </div>
          )}

          {stats && (
            <>
              {/* Quick stats */}
              <section className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[
                  {
                    label: "Avg mood",
                    value: stats.mood.average.toFixed(1),
                    sub: stats.mood.trend,
                  },
                  {
                    label: "Sessions",
                    value: stats.totals.sessions,
                    sub: `${stats.totals.total_time_minutes} min`,
                  },
                  {
                    label: "Tasks done",
                    value: `${stats.tasks.completion_rate_pct}%`,
                    sub: `${stats.tasks.completed}/${stats.tasks.total}`,
                  },
                  {
                    label: "Most missed",
                    value: stats.tasks.most_missed,
                    sub: `${stats.tasks.avg_delay_minutes} min avg delay`,
                  },
                ].map((s) => (
                  <div
                    key={s.label}
                    className="rounded-md border border-border p-4 bg-card"
                  >
                    <div className="text-[22px] font-medium leading-none truncate">{s.value}</div>
                    <div className="text-[11px] uppercase tracking-wide text-muted-foreground mt-2">{s.label}</div>
                    <div className="text-[11px] text-muted-foreground mt-1">{s.sub}</div>
                  </div>
                ))}
              </section>

              {/* Mood chart */}
              <section>
                <h2 className="text-[13px] font-medium uppercase tracking-wide text-muted-foreground mb-3">
                  Mood across the week
                </h2>
                <div className="h-56 rounded-md border border-border p-3 bg-card">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={stats.mood.chart}>
                      <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                      <XAxis dataKey="date" fontSize={11} />
                      <YAxis domain={[1, 5]} ticks={[1,2,3,4,5]} fontSize={11} />
                      <Tooltip />
                      <Line
                        type="monotone"
                        dataKey="value"
                        stroke="hsl(var(--primary))"
                        strokeWidth={2}
                        dot={{ r: 4 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </section>

              {/* Game performance */}
              <section>
                <h2 className="text-[13px] font-medium uppercase tracking-wide text-muted-foreground mb-3">Game performance</h2>
                <div className="overflow-x-auto rounded-md border border-border">
                  <table className="w-full text-sm">
                    <thead className="bg-secondary/40 text-[11px] uppercase tracking-wide text-muted-foreground">
                      <tr className="text-left">
                        <th className="p-3 font-medium">Game</th>
                        <th className="p-3 font-medium">Sessions</th>
                        <th className="p-3 font-medium">Avg score</th>
                        <th className="p-3 font-medium">Avg accuracy</th>
                        <th className="p-3 font-medium">Avg errors</th>
                        <th className="p-3 font-medium">Trend</th>
                      </tr>
                    </thead>
                    <tbody>
                      {stats.games.map((g) => (
                        <tr key={g.game} className="border-t border-border">
                          <td className="p-3">{prettyGame(g.game)}</td>
                          <td className="p-3">{g.sessions}</td>
                          <td className="p-3">{g.avg_score}</td>
                          <td className="p-3">{g.avg_accuracy}%</td>
                          <td className="p-3">{g.avg_errors}</td>
                          <td className="p-3 capitalize">
                            {g.accuracy_trend}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>

              {/* Task summary */}
              <section>
                <h2 className="text-[13px] font-medium uppercase tracking-wide text-muted-foreground mb-3">Task completion</h2>
                <div className="rounded-md border border-border p-4 bg-card text-sm">
                  <p>
                    Mary completed{" "}
                    <strong>{stats.tasks.completed}</strong> of{" "}
                    <strong>{stats.tasks.total}</strong> scheduled tasks (
                    {stats.tasks.completion_rate_pct}%) this week.
                  </p>
                  <p className="mt-1 text-muted-foreground">
                    Most missed task: <strong>{stats.tasks.most_missed}</strong>
                    . Average delay from scheduled time:{" "}
                    <strong>{stats.tasks.avg_delay_minutes} min</strong>.
                  </p>
                </div>
              </section>

              {/* Claude sections */}
              {sections.length > 0 && (
                <section className="space-y-4">
                  <h2 className="text-[13px] font-medium uppercase tracking-wide text-muted-foreground">Clinical summary</h2>
                  {sections.map((s) => (
                    <div
                      key={s.title}
                      className="rounded-md border border-border p-4 bg-card"
                    >
                      <h3 className="font-medium mb-2">{s.title}</h3>
                      <p className="text-sm whitespace-pre-wrap leading-relaxed">
                        {s.body}
                      </p>
                    </div>
                  ))}
                </section>
              )}
            </>
          )}
        </div>
      </div>
    </main>
  );
}