import { useEffect, useState } from "react";
import { Plus, Waves, ListChecks, Brain, Image as ImageIcon, Grid3x3 } from "lucide-react";
import { Navigate, useSearchParams } from "react-router-dom";
import { TopBar } from "@/components/TopBar";
import { TaskItem } from "@/components/TaskItem";
import { MoodSlider } from "@/components/MoodSlider";
import { GameRow } from "@/components/GameRow";
import { supabase } from "@/integrations/supabase/client";
import { getUserId } from "@/features/assessment/useAdaptiveProfile";
import {
  generateRecommendations,
  type AdaptiveProfile,
  type RehabMetrics,
  type Recommendation,
} from "@/features/assessment/scoringEngine";
import { saveTaskLog } from "@/lib/sessionTracker";
import { useDashboardStats } from "@/hooks/useDashboardStats";
import TherapyPlan from "@/components/TherapyPlan";

const gamesMeta = [
  { title: "Echo Surfer", category: "Rhythm & Reaction", icon: Waves, dotClass: "bg-[hsl(var(--game-blue)/0.15)]", difficulty: "Easy" as const, to: "/games/echo-surfer" },
  { title: "Task Arranger", category: "Sequencing", icon: ListChecks, dotClass: "bg-[hsl(var(--game-green)/0.15)]", difficulty: "Medium" as const, to: "/games/task-arranger" },
  { title: "Memory Match", category: "Short-term memory", icon: Brain, dotClass: "bg-[hsl(var(--game-coral)/0.15)]", difficulty: "Easy" as const },
  { title: "Memory Recall", category: "Visual memory", icon: ImageIcon, dotClass: "bg-[hsl(var(--game-purple)/0.15)]", difficulty: "Medium" as const, to: "/games/memory-recall" },
  { title: "Spatial Grid", category: "Spatial pattern", icon: Grid3x3, dotClass: "bg-[hsl(var(--game-coral)/0.15)]", difficulty: "Hard" as const, to: "/games/spatial-grid" },
];

const days = ["M", "T", "W", "T", "F", "S", "S"];

const Index = () => {
  const [onboarded, setOnboarded] = useState<boolean | null>(null);
  const [params, setParams] = useSearchParams();
  const showWelcome = params.get("welcome") === "1";
  const [recs, setRecs] = useState<Recommendation[] | null>(null);
  const { stats, loading: statsLoading } = useDashboardStats();
  const [tasks, setTasks] = useState([
    { id: 1, title: "Take morning medication", time: "08:00 AM", completed: true },
    { id: 2, title: "Complete memory game", time: "10:00 AM", completed: false },
    { id: 3, title: "Stretch exercises", time: "02:00 PM", completed: false },
    { id: 4, title: "Call daughter", time: "06:00 PM", completed: false },
  ]);
  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (localStorage.getItem("np_onboarded") === "1") {
        if (!cancelled) setOnboarded(true);
        return;
      }
      const { data } = await supabase
        .from("assessments")
        .select("id")
        .eq("user_id", getUserId())
        .limit(1);
      if (cancelled) return;
      if (data && data.length > 0) {
        localStorage.setItem("np_onboarded", "1");
        setOnboarded(true);
      } else {
        setOnboarded(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!showWelcome) return;
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("assessments")
        .select("motor_stability,cognitive_focus,communication_confidence,fatigue_sensitivity,memory_index,adaptation_level,adaptive_profile,tremor_smoothness,tremor_deviation,tremor_velocity_var")
        .eq("user_id", getUserId())
        .order("created_at", { ascending: false })
        .limit(1);
      if (cancelled || !data?.[0]) return;
      const row = data[0];
      const metrics: RehabMetrics = {
        motor_stability: row.motor_stability,
        cognitive_focus: row.cognitive_focus,
        communication_confidence: row.communication_confidence,
        fatigue_sensitivity: row.fatigue_sensitivity,
        memory_index: row.memory_index,
        adaptation_level: row.adaptation_level,
      };
      const profile = row.adaptive_profile as unknown as AdaptiveProfile;
      const tremor = {
        smoothness: Number(row.tremor_smoothness) || 0,
        deviation: Number(row.tremor_deviation) || 0,
        velocityVariation: Number(row.tremor_velocity_var) || 0,
      };
      setRecs(generateRecommendations(metrics, profile, tremor));
    })();
    return () => { cancelled = true; };
  }, [showWelcome]);

  if (onboarded === false && !showWelcome) {
    return <Navigate to="/onboarding" replace />;
  }
  if (onboarded === null) {
    return <main className="min-h-screen bg-background" />;
  }

  const dismissWelcome = () => {
    params.delete("welcome");
    setParams(params, { replace: true });
  };

  const toggleTask = (id: number) =>
    setTasks((t) =>
      t.map((task) => {
        if (task.id !== id) return task;
        const nextCompleted = !task.completed;
        if (nextCompleted) {
          void saveTaskLog({
            taskName: task.title,
            wasCompleted: true,
            scheduledTime: task.time,
          });
        }
        return { ...task, completed: nextCompleted };
      }),
    );

  const fmtPct = (n: number | null) => (n == null ? "—" : `${n}%`);
  const fmtNum = (n: number) => (statsLoading ? "—" : `${n}`);

  const metricCards = [
    { label: "Overall accuracy", value: statsLoading ? null : fmtPct(stats.overallAccuracy) },
    { label: "Sessions done", value: statsLoading ? null : fmtNum(stats.totalSessions) },
    { label: "Day streak", value: statsLoading ? null : fmtNum(stats.streakDays) },
    { label: "Speech accuracy", value: statsLoading ? null : fmtPct(stats.speechAvg) },
  ];

  const games = gamesMeta.map((g) => ({
    ...g,
    score: statsLoading
      ? null
      : (stats.perGame[g.title.toLowerCase()] ?? null),
  }));

  const completedDays = stats.activeDays;

  return (
    <main className="min-h-screen bg-background">
      <TopBar initials="MA" />
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        {showWelcome && (
          <section className="mb-6 bg-card border border-border rounded-md p-5">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h2 className="text-[15px] font-medium">Your personalized plan is ready</h2>
                <p className="text-[13px] text-muted-foreground mt-1 max-w-prose">
                  Based on your answers, we've tuned game pacing, target sizes, and session
                  length to fit your comfort. These are rehabilitation adaptations, not medical advice.
                </p>
                {recs && recs.length > 0 && (
                  <ul className="mt-4 space-y-2">
                    {recs.map((r) => (
                      <li key={r.id} className="border border-border rounded-md p-3">
                        <div className="text-[13px] font-medium">{r.title}</div>
                        <div className="text-[13px] text-muted-foreground mt-1">{r.detail}</div>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
              <button
                onClick={dismissWelcome}
                className="text-[13px] border border-border rounded-md px-3 py-1.5 hover:bg-secondary transition-colors shrink-0"
              >
                Get started
              </button>
            </div>
          </section>
        )}

        {/* Greeting */}
        <header className="mb-6">
          <h1 className="text-[24px] font-medium leading-tight">Good morning, Mary</h1>
          <p className="text-[13px] text-muted-foreground mt-1">Week 3 of recovery</p>
        </header>

        {!statsLoading && !stats.hasAnyData && (
          <div className="mb-6 bg-card border border-border rounded-md p-4 text-[13px] text-muted-foreground">
            No sessions yet. Play your first game to see your progress here.
          </div>
        )}

        {/* Metrics */}
        <section className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          {metricCards.map((m) => (
            <div key={m.label} className="bg-card border border-border rounded-md p-4">
              {m.value === null ? (
                <div className="h-[22px] w-16 rounded bg-secondary animate-pulse" />
              ) : (
                <div className="text-[22px] font-medium leading-none">{m.value}</div>
              )}
              <div className="text-[11px] uppercase tracking-wide text-muted-foreground mt-2">
                {m.label}
              </div>
            </div>
          ))}
        </section>

        <TherapyPlan />

        {/* Weekly streak */}
        <section className="bg-card border border-border rounded-md p-4 mb-6">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-[13px] font-medium">This week</h2>
            <span className="text-[11px] text-muted-foreground uppercase tracking-wide">
              {statsLoading ? "—" : `${completedDays.filter(Boolean).length}/7 days`}
            </span>
          </div>
          <div className="flex items-center justify-between gap-2 max-w-md">
            {days.map((d, i) => {
              const done = completedDays[i];
              return (
                <div
                  key={i}
                  className={`w-7 h-7 rounded-full grid place-items-center text-[11px] font-medium ${
                    done
                      ? "bg-primary text-primary-foreground"
                      : "border border-border text-muted-foreground"
                  }`}
                >
                  {d}
                </div>
              );
            })}
          </div>
        </section>

        <div className="grid lg:grid-cols-[1fr_320px] gap-6">
          {/* Left: mood + games */}
          <div className="space-y-6">
            <MoodSlider />

            <section className="bg-card border border-border rounded-md">
              <div className="flex items-center justify-between px-4 h-11 border-b border-border">
                <h2 className="text-[13px] font-medium">Therapy games</h2>
                <span className="text-[11px] text-muted-foreground uppercase tracking-wide">
                  {games.length} available
                </span>
              </div>
              <div>
                {games.map((g) => (
                  <GameRow key={g.title} {...g} />
                ))}
              </div>
            </section>
          </div>

          {/* Right: tasks */}
          <aside className="bg-card border border-border rounded-md p-4 h-fit">
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-[13px] font-medium">Today's tasks</h2>
              <span className="text-[11px] text-muted-foreground uppercase tracking-wide">
                {tasks.filter((t) => t.completed).length}/{tasks.length}
              </span>
            </div>
            <div>
              {tasks.map((task) => (
                <TaskItem
                  key={task.id}
                  title={task.title}
                  time={task.time}
                  completed={task.completed}
                  onToggle={() => toggleTask(task.id)}
                />
              ))}
            </div>
            <button className="mt-3 w-full text-[13px] border border-border rounded-md py-2 flex items-center justify-center gap-1 hover:bg-secondary transition-colors">
              <Plus className="w-4 h-4" /> Add task
            </button>
          </aside>
        </div>
      </div>
    </main>
  );
};

export default Index;
