import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Loader2, Pause, Play, RotateCcw, Settings, Upload, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { SpeakButton } from "@/components/SpeakButton";
import { analyseAudio, type Onset } from "@/lib/audioAnalysis";
import { toast } from "@/hooks/use-toast";
import { EchoSurferGame } from "@/components/EchoSurferGame";
import { scoreRun, expectedKeysOf, type Scheme, type PressEvent, type ScoreSummary, type NoteKey } from "@/lib/scoring";
import { setCasioVolume, unlockCasioAudio } from "@/lib/casioSynth";
import musicKeyArt from "@/assets/music-key-cartoon.jpg";
import { saveGameSession } from "@/lib/sessionTracker";

type Phase = "loading" | "intro" | "listening" | "ready" | "playing" | "results";

const BUTTONS = [
  { key: "A", color: "#22d3ee", glow: "rgba(34,211,238,0.7)" },
  { key: "S", color: "#a78bfa", glow: "rgba(167,139,250,0.7)" },
  { key: "D", color: "#f472b6", glow: "rgba(244,114,182,0.7)" },
  { key: "F", color: "#facc15", glow: "rgba(250,204,21,0.7)" },
] as const;

const DEFAULT_CLIP = "/defaults/input_music.mp3";
const DEFAULT_SCHEME = "/defaults/score_scheme.json";

interface PressRecord {
  button: 0 | 1 | 2 | 3;
  correct: boolean;
  worldX: number;
  y: number;
}

const EchoSurfer = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const audioBufferRef = useRef<AudioBuffer | null>(null);
  const buttonClipsRef = useRef<(AudioBuffer | null)[]>([null, null, null, null]);
  const sourceRef = useRef<AudioBufferSourceNode | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const starsRef = useRef<{ x: number; y: number; r: number; tw: number }[]>([]);
  const galaxiesRef = useRef<{ x: number; y: number; r: number; hue: number }[]>([]);

  const [phase, setPhase] = useState<Phase>("loading");
  const [clipName, setClipName] = useState("Default clip");
  const [onsets, setOnsets] = useState<Onset[]>([]);
  const [envelope, setEnvelope] = useState<Float32Array>(new Float32Array(0));
  const [buttonPitches, setButtonPitches] = useState<number[]>([110, 330, 660, 1320]);
  const [presses, setPresses] = useState<PressRecord[]>([]);
  const [activeFlash, setActiveFlash] = useState<number | null>(null);
  const [wrongFlash, setWrongFlash] = useState(false);
  const [score, setScore] = useState({ correct: 0, total: 0, accuracy: 0 });
  const [analysing, setAnalysing] = useState(false);
  const [scheme, setScheme] = useState<Scheme | null>(null);
  const [summary, setSummary] = useState<ScoreSummary | null>(null);
  // Defaults can be overridden by the player via "Save as defaults" (persisted to localStorage)
  const DEFAULTS_KEY = "echoSurferDefaults";
  const savedDefaults = (() => {
    try { return JSON.parse(localStorage.getItem(DEFAULTS_KEY) || "null"); } catch { return null; }
  })();
  const [trainMode, setTrainMode] = useState<boolean>(savedDefaults?.trainMode ?? true);
  const [musicVolume, setMusicVolume] = useState<number>(savedDefaults?.musicVolume ?? 35);
  const [cueLookahead, setCueLookahead] = useState<number>(savedDefaults?.cueLookahead ?? 4);
  const [noteSpacing, setNoteSpacing] = useState<number>(savedDefaults?.noteSpacing ?? 2);
  const [defaultsLocked, setDefaultsLocked] = useState<boolean>(!!savedDefaults);
  const [paused, setPaused] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [feedback, setFeedback] = useState<{ id: number; text: string; color: string } | null>(null);
  const comboRef = useRef(0);
  const pressEventsRef = useRef<PressEvent[]>([]);
  // Live tally driven by per-press feedback so the score the player SEES (Perfect/Good/Okay)
  // is exactly what the final score reflects.
  const statsRef = useRef({ perfect: 0, good: 0, okay: 0, miss: 0, points: 0, bestCombo: 0 });

  // Rebuild times from the slider so SIMILAR consecutive chords (e.g. A+K, A+K)
  // are spaced at 1x the slider value, while DIFFERENT chords (A+K, B+K) get
  // 2x. Keeps cues + scoring perfectly in sync because both consume this scheme.
  const scaledScheme = useMemo<Scheme | null>(() => {
    if (!scheme) return null;
    const m = Math.max(0.5, noteSpacing);
    const SIMILAR_GAP = 0.5 * m;   // gap after a same-keys chord
    const DIFFERENT_GAP = 1.0 * m; // gap before a new chord group
    const sameChord = (a: NoteKey[], b: NoteKey[]) => {
      if (a.length !== b.length) return false;
      const sa = [...a].sort().join(",");
      const sb = [...b].sort().join(",");
      return sa === sb;
    };
    let t = DIFFERENT_GAP; // initial breathing room
    const newNotes = scheme.notes.map((n, i) => {
      const dur = n.duration ?? 0.2;
      if (i > 0) {
        const prev = scheme.notes[i - 1];
        const gap = sameChord(prev.keys as NoteKey[], n.keys as NoteKey[]) ? SIMILAR_GAP : DIFFERENT_GAP;
        t += (prev.duration ?? 0.2) + gap;
      }
      return { ...n, time: t, duration: dur };
    });
    const last = newNotes[newNotes.length - 1];
    const songLength = last ? last.time + (last.duration ?? 0.2) + DIFFERENT_GAP : (scheme.song_length ?? 6);
    return { ...scheme, song_length: songLength, notes: newNotes };
  }, [scheme, noteSpacing]);

  const saveDefaults = () => {
    const payload = { trainMode, musicVolume, cueLookahead, noteSpacing };
    localStorage.setItem(DEFAULTS_KEY, JSON.stringify(payload));
    setDefaultsLocked(true);
    toast({ title: "Defaults saved", description: "Future games will start with these settings." });
  };
  const clearDefaults = () => {
    localStorage.removeItem(DEFAULTS_KEY);
    setDefaultsLocked(false);
  };

  // Auto-pause whenever the settings popover is open
  useEffect(() => {
    if (phase !== "playing") return;
    setPaused((p) => (settingsOpen ? true : p));
  }, [settingsOpen, phase]);

  const buttonLevels = useMemo(() => {
    const indexed = buttonPitches.map((p, i) => ({ i, p }));
    const sorted = [...indexed].sort((a, b) => a.p - b.p);
    const offsets = [0.32, 0.11, -0.11, -0.32];
    const out = [0, 0, 0, 0];
    sorted.forEach((entry, rank) => { out[entry.i] = offsets[rank]; });
    return out;
  }, [buttonPitches]);

  const stateRef = useRef({
    worldX: 0,
    stepX: 80,
    presses: [] as PressRecord[],
    spikes: new Uint8Array(64),
    lastTime: 0,
    starPhase: 0,
  });

  useEffect(() => { stateRef.current.presses = presses; }, [presses]);

  useEffect(() => {
    setCasioVolume(musicVolume / 100);
  }, [musicVolume]);

  const ensureCtx = () => {
    if (!audioCtxRef.current) {
      const C = window.AudioContext || (window as any).webkitAudioContext;
      audioCtxRef.current = new C();
    }
    return audioCtxRef.current!;
  };

  // Build a small AudioBuffer slice per button from the original clip + onsets.
  // Picks the longest (capped) slice for each button.
  const buildButtonClips = (buf: AudioBuffer, onsetList: Onset[]) => {
    const ctx = ensureCtx();
    const sr = buf.sampleRate;
    const dur = buf.duration;
    const out: (AudioBuffer | null)[] = [null, null, null, null];
    const CLIP_DUR = 0.3; // mirrors python clip_duration
    for (let b = 0; b < 4; b++) {
      const myOnsets = onsetList.filter((o) => o.button === b);
      // Mirror python: take events[0] as representative, fixed 0.3s clip.
      // Fallback: evenly spaced quartile slice so every button always has audio.
      let startT: number;
      if (myOnsets.length) {
        startT = myOnsets[0].time;
      } else {
        startT = Math.min(dur - CLIP_DUR, ((b + 0.5) / 4) * dur);
        startT = Math.max(0, startT);
      }
      const endT = Math.min(dur, startT + CLIP_DUR);
      const len = Math.max(1, Math.floor((endT - startT) * sr));
      const slice = ctx.createBuffer(1, len, sr);
      const src = buf.getChannelData(0);
      const dst = slice.getChannelData(0);
      const startIdx = Math.floor(startT * sr);
      // small fade in/out to avoid clicks
      const fade = Math.min(len, Math.floor(sr * 0.01));
      for (let i = 0; i < len; i++) {
        let s = src[startIdx + i] || 0;
        if (i < fade) s *= i / fade;
        if (i > len - fade) s *= (len - i) / fade;
        dst[i] = s;
      }
      out[b] = slice;
    }
    buttonClipsRef.current = out;
    console.log("[EchoSurfer] button clips ready:", out.map((c) => c ? `${c.duration.toFixed(2)}s` : "null"));
  };

  const generatePlaceholderClip = useCallback(async (): Promise<ArrayBuffer> => {
    const sr = 44100;
    const dur = 6;
    const ctx = ensureCtx();
    const buf = ctx.createBuffer(1, sr * dur, sr);
    const ch = buf.getChannelData(0);
    const notes = [
      { t: 0.3, f: 220 }, { t: 1.0, f: 740 }, { t: 1.7, f: 330 },
      { t: 2.4, f: 494 }, { t: 3.2, f: 220 }, { t: 3.9, f: 494 }, { t: 4.6, f: 740 },
    ];
    notes.forEach(({ t, f }) => {
      const start = Math.floor(t * sr);
      for (let i = 0; i < sr * 0.35; i++) {
        const env = Math.exp(-i / (sr * 0.12));
        ch[start + i] += Math.sin((2 * Math.PI * f * i) / sr) * 0.4 * env;
      }
    });
    return audioBufferToWav(buf);
  }, []);

  const loadClip = useCallback(async (data: ArrayBuffer, name: string) => {
    setAnalysing(true);
    try {
      const ctx = ensureCtx();
      const decoded = await ctx.decodeAudioData(data.slice(0));
      audioBufferRef.current = decoded;
      const result = await analyseAudio(data);
      const limited = result.onsets.slice(0, 32);
      if (limited.length < 2) {
        toast({ title: "Couldn't detect enough beats", description: "Try a more rhythmic clip.", variant: "destructive" });
      }
      buildButtonClips(decoded, limited);
      setOnsets(limited);
      setEnvelope(result.envelope);
      setButtonPitches(result.buttonPitches);
      setClipName(name);
      setPhase("intro");
    } catch (e) {
      console.error("load clip failed", e);
      toast({ title: "Could not load that audio", variant: "destructive" });
    } finally {
      setAnalysing(false);
    }
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const [audioRes, schemeRes] = await Promise.all([
          fetch(DEFAULT_CLIP),
          fetch(DEFAULT_SCHEME),
        ]);
        if (schemeRes.ok) {
          const j = await schemeRes.json();
          setScheme(j);
        }
        if (audioRes.ok) {
          const ab = await audioRes.arrayBuffer();
          await loadClip(ab, "Interstellar theme");
          return;
        }
      } catch { /* ignore */ }
      const ab = await generatePlaceholderClip();
      await loadClip(ab, "Demo tones");
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const stopPlayback = () => {
    try { sourceRef.current?.stop(); } catch { /* ignore */ }
    sourceRef.current?.disconnect();
    sourceRef.current = null;
    analyserRef.current?.disconnect();
    analyserRef.current = null;
  };

  const playClip = (onEnded?: () => void) => {
    const ctx = ensureCtx();
    const buf = audioBufferRef.current;
    if (!buf) return;
    stopPlayback();
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 256;
    analyser.smoothingTimeConstant = 0.7;
    src.connect(analyser);
    analyser.connect(ctx.destination);
    src.onended = () => onEnded?.();
    sourceRef.current = src;
    analyserRef.current = analyser;
    src.start();
  };

  // play the per-button audio slice extracted from the uploaded clip
  const playButtonClip = (idx: number) => {
    const ctx = ensureCtx();
    const slice = buttonClipsRef.current[idx];
    if (!slice) return;
    const src = ctx.createBufferSource();
    src.buffer = slice;
    const gain = ctx.createGain();
    gain.gain.value = 0.9;
    src.connect(gain).connect(ctx.destination);
    src.start();
  };

  const handleListen = () => {
    setPhase("listening");
    playClip(() => setPhase((p) => (p === "listening" ? "ready" : p)));
  };

  const handleStart = () => {
    if (!scheme) {
      toast({ title: "No score scheme loaded yet", variant: "destructive" });
      return;
    }
    stopPlayback();
    unlockCasioAudio();
    pressEventsRef.current = [];
    statsRef.current = { perfect: 0, good: 0, okay: 0, miss: 0, points: 0, bestCombo: 0 };
    comboRef.current = 0;
    setSummary(null);
    setPhase("playing");
  };

  const finishGame = () => {
    if (!scheme) return;
    const s = statsRef.current;
    const totalPresses = s.perfect + s.good + s.okay + s.miss;
    const maxPossible = Math.max(1, totalPresses) * 100;
    const accuracy = Math.round((s.points / maxPossible) * 100);
    const correct = s.perfect + s.good + s.okay;
    const sum: ScoreSummary = {
      total: s.points,
      accuracy,
      combo: s.bestCombo,
      perfect: s.perfect,
      good: s.good,
      okay: s.okay,
      miss: s.miss,
      durationAccuracy: 100,
      avgHold: 0,
      avgExpected: 0,
      results: [],
    };
    setSummary(sum);
    setScore({ correct, total: totalPresses, accuracy });
    setPhase("results");
    void saveGameSession({
      gameName: "Echo Surfer",
      score: s.points,
      accuracyPercent: accuracy,
      errors: s.miss,
      durationSeconds: Math.round(scheme.song_length ?? 0),
      levelReached: s.bestCombo,
      roundsTotal: totalPresses,
      roundsCorrect: correct,
      sessionData: {
        perfect: s.perfect, good: s.good, okay: s.okay, miss: s.miss,
        bestCombo: s.bestCombo, clipName, trainMode, noteSpacing, cueLookahead,
      },
    });
  };

  /** Per-press feedback: classify the latest press against the nearest expected event. */
  const handleGamePress = useCallback((e: PressEvent) => {
    pressEventsRef.current.push(e);
    if (!scaledScheme) return;
    const loop = scaledScheme.song_length || 6;
    // find nearest expected occurrence of this key across loops
    let bestDelta = Infinity;
    for (const n of scaledScheme.notes) {
      const keys = expectedKeysOf(n);
      if (!keys.includes(e.key as NoteKey)) continue;
      // check this loop and adjacent
      for (let l = -1; l <= 1; l++) {
        const at = Math.floor(e.time / loop + l) * loop + n.time;
        const d = Math.abs(at - e.time) * 1000;
        if (d < bestDelta) bestDelta = d;
      }
    }
    let text = "", color = "#fde047";
    const s = statsRef.current;
    if (bestDelta <= 80) { text = "Perfect!"; color = "#fde047"; s.perfect++; s.points += 100; comboRef.current++; }
    else if (bestDelta <= 180) { text = "Good!"; color = "#86efac"; s.good++; s.points += 70; comboRef.current++; }
    else if (bestDelta <= 300) { text = "Okay"; color = "#7dd3fc"; s.okay++; s.points += 40; comboRef.current++; }
    else { text = "Miss"; color = "#fca5a5"; s.miss++; comboRef.current = 0; }
    if (comboRef.current > s.bestCombo) s.bestCombo = comboRef.current;
    if (comboRef.current >= 3 && text !== "Miss") text = `Combo x${comboRef.current}`;
    const id = Date.now() + Math.random();
    setFeedback({ id, text, color });
    setTimeout(() => setFeedback((f) => (f && f.id === id ? null : f)), 800);
  }, [scaledScheme]);

  const handlePress = (idx: 0 | 1 | 2 | 3) => {
    // Always play the actual clip slice for sensory feedback
    playButtonClip(idx);
    setActiveFlash(idx);
    setTimeout(() => setActiveFlash((a) => (a === idx ? null : a)), 180);

    if (phase !== "playing") return;

    setPresses((curr) => {
      const i = curr.length;
      // Sequence loops infinitely
      const expected = onsets[i % onsets.length].button;
      const correct = idx === expected;
      if (!correct) {
        setWrongFlash(true);
        setTimeout(() => setWrongFlash(false), 200);
      }
      const canvas = canvasRef.current;
      const H = canvas?.height ?? 360;
      const stepX = stateRef.current.stepX;
      stateRef.current.worldX += stepX;
      const y = (H / 2) + buttonLevels[idx] * H;
      const press: PressRecord = { button: idx, correct, worldX: stateRef.current.worldX, y };
      const next = [...curr, press];
      // running score
      const correctCount = next.filter((p) => p.correct).length;
      setScore({ correct: correctCount, total: next.length, accuracy: Math.round((correctCount / next.length) * 100) });
      return next;
    });
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      // During Phaser gameplay the scene owns the keys (A/B/C/D/E)
      if (phase === "playing") return;
      const map: Record<string, 0 | 1 | 2 | 3> = {
        a: 0, s: 1, d: 2, f: 3, "1": 0, "2": 1, "3": 2, "4": 3,
      };
      const idx = map[e.key.toLowerCase()];
      if (idx !== undefined) {
        e.preventDefault();
        handlePress(idx);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, onsets, buttonLevels]);

  // canvas render loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    let raf = 0;
    const initStarfield = (W: number, H: number) => {
      const stars = [];
      for (let i = 0; i < 160; i++) {
        stars.push({ x: Math.random() * W, y: Math.random() * H, r: Math.random() * 1.4 + 0.2, tw: Math.random() * Math.PI * 2 });
      }
      starsRef.current = stars;
      const galaxies = [];
      for (let i = 0; i < 4; i++) {
        galaxies.push({
          x: Math.random() * W, y: Math.random() * H * 0.7,
          r: 60 + Math.random() * 80, hue: 200 + Math.random() * 140,
        });
      }
      galaxiesRef.current = galaxies;
    };
    const resize = () => {
      const parent = canvas.parentElement!;
      canvas.width = parent.clientWidth;
      canvas.height = parent.clientHeight;
      const seqLen = Math.max(1, onsets.length);
      // visible window shows ~one full sequence cycle
      stateRef.current.stepX = (canvas.width * 0.9) / seqLen;
      initStarfield(canvas.width, canvas.height);
    };
    resize();
    window.addEventListener("resize", resize);

    const s = stateRef.current;
    s.lastTime = performance.now();

    const drawSpaceBg = (W: number, H: number, t: number) => {
      // deep space gradient
      const sky = ctx.createLinearGradient(0, 0, 0, H);
      sky.addColorStop(0, "#05060f");
      sky.addColorStop(0.5, "#0a0a22");
      sky.addColorStop(1, "#02020a");
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, W, H);

      // distant galaxy nebulae
      for (const g of galaxiesRef.current) {
        const grad = ctx.createRadialGradient(g.x, g.y, 0, g.x, g.y, g.r);
        grad.addColorStop(0, `hsla(${g.hue}, 80%, 55%, 0.28)`);
        grad.addColorStop(0.5, `hsla(${g.hue + 30}, 70%, 40%, 0.12)`);
        grad.addColorStop(1, `hsla(${g.hue}, 60%, 20%, 0)`);
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(g.x, g.y, g.r, 0, Math.PI * 2);
        ctx.fill();
      }

      // stars (twinkle)
      for (const st of starsRef.current) {
        const a = 0.4 + 0.6 * Math.abs(Math.sin(t * 0.001 + st.tw));
        ctx.fillStyle = `rgba(255,255,255,${a})`;
        ctx.beginPath();
        ctx.arc(st.x, st.y, st.r, 0, Math.PI * 2);
        ctx.fill();
      }

      // blurry glow moon (top-right)
      const mx = W * 0.82, my = H * 0.22, mr = Math.min(W, H) * 0.09;
      const moonGlow = ctx.createRadialGradient(mx, my, 0, mx, my, mr * 3);
      moonGlow.addColorStop(0, "rgba(220,230,255,0.55)");
      moonGlow.addColorStop(0.3, "rgba(180,200,255,0.18)");
      moonGlow.addColorStop(1, "rgba(180,200,255,0)");
      ctx.fillStyle = moonGlow;
      ctx.fillRect(mx - mr * 3, my - mr * 3, mr * 6, mr * 6);
      const moon = ctx.createRadialGradient(mx - mr * 0.3, my - mr * 0.3, mr * 0.2, mx, my, mr);
      moon.addColorStop(0, "rgba(255,255,255,0.95)");
      moon.addColorStop(1, "rgba(190,200,235,0.5)");
      ctx.fillStyle = moon;
      ctx.beginPath();
      ctx.arc(mx, my, mr, 0, Math.PI * 2);
      ctx.fill();
    };

    const drawSpikes = (W: number, H: number) => {
      const analyser = analyserRef.current;
      if (analyser) {
        if (s.spikes.length !== analyser.frequencyBinCount) {
          s.spikes = new Uint8Array(analyser.frequencyBinCount);
        }
        analyser.getByteFrequencyData(s.spikes);
      }
      const bars = 64;
      const totalW = W * 0.85;
      const gap = 4;
      const barW = (totalW - gap * (bars - 1)) / bars;
      const startX = (W - totalW) / 2;
      const midY = H / 2;
      for (let i = 0; i < bars; i++) {
        const v = s.spikes[Math.floor((i / bars) * s.spikes.length)] || 0;
        const h = Math.max(4, (v / 255) * H * 0.4);
        const x = startX + i * (barW + gap);
        const t = i / bars;
        const hue = 180 + t * 140;
        const grad = ctx.createLinearGradient(0, midY - h, 0, midY + h);
        grad.addColorStop(0, `hsla(${hue}, 100%, 65%, 0.95)`);
        grad.addColorStop(0.5, `hsla(${hue}, 100%, 55%, 0.7)`);
        grad.addColorStop(1, `hsla(${hue}, 100%, 65%, 0.95)`);
        ctx.fillStyle = grad;
        ctx.shadowColor = `hsl(${hue}, 100%, 60%)`;
        ctx.shadowBlur = 16;
        ctx.fillRect(x, midY - h, barW, h * 2);
      }
      ctx.shadowBlur = 0;
    };

    // Sample envelope at world x; envelope loops every (stepX * onsets.length) world units
    const sampleEnvelope = (wx: number): number => {
      if (envelope.length === 0 || onsets.length === 0) return 0.5;
      const period = s.stepX * onsets.length;
      let t = ((wx % period) + period) % period;
      const u = t / period;
      const idx = Math.min(envelope.length - 1, Math.max(0, Math.floor(u * (envelope.length - 1))));
      return envelope[idx];
    };

    const drawWaveScene = (W: number, H: number) => {
      const camX = s.worldX;
      const centerX = W / 2;
      const midY = H / 2;
      const amp = H * 0.34;

      // Bipolar ideal wave spanning entire visible width
      // amplitude = envelope value (0..1), drawn ± around midline
      const N = Math.max(60, Math.floor(W / 4));
      // top trace
      const drawSide = (sign: number, color: string, alpha: number) => {
        ctx.strokeStyle = color;
        ctx.globalAlpha = alpha;
        ctx.lineWidth = 2;
        ctx.shadowColor = color;
        ctx.shadowBlur = 14;
        ctx.beginPath();
        for (let i = 0; i <= N; i++) {
          const sx = (i / N) * W;
          const wx = sx - centerX + camX;
          const env = sampleEnvelope(wx);
          const y = midY + sign * env * amp;
          if (i === 0) ctx.moveTo(sx, y);
          else ctx.lineTo(sx, y);
        }
        ctx.stroke();
        ctx.shadowBlur = 0;
        ctx.globalAlpha = 1;
      };
      drawSide(-1, "#7dd3fc", 0.85);
      drawSide(+1, "#7dd3fc", 0.85);

      // soft fill between
      ctx.fillStyle = "rgba(125,211,252,0.08)";
      ctx.beginPath();
      for (let i = 0; i <= N; i++) {
        const sx = (i / N) * W;
        const wx = sx - centerX + camX;
        const env = sampleEnvelope(wx);
        const y = midY - env * amp;
        if (i === 0) ctx.moveTo(sx, y); else ctx.lineTo(sx, y);
      }
      for (let i = N; i >= 0; i--) {
        const sx = (i / N) * W;
        const wx = sx - centerX + camX;
        const env = sampleEnvelope(wx);
        const y = midY + env * amp;
        ctx.lineTo(sx, y);
      }
      ctx.closePath();
      ctx.fill();

      // Player traced wave
      const pressList = s.presses;
      if (pressList.length > 0) {
        ctx.strokeStyle = "#fde047";
        ctx.lineWidth = 4;
        ctx.shadowColor = "#fde047";
        ctx.shadowBlur = 18;
        ctx.lineJoin = "round";
        ctx.lineCap = "round";
        ctx.beginPath();
        const firstSx = pressList[0].worldX - camX + centerX;
        ctx.moveTo(firstSx, midY);
        pressList.forEach((p) => {
          const sx = p.worldX - camX + centerX;
          ctx.lineTo(sx, p.y);
          if (!p.correct) {
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(sx, p.y);
          }
        });
        ctx.stroke();
        ctx.shadowBlur = 0;

        pressList.forEach((p) => {
          const sx = p.worldX - camX + centerX;
          if (sx < -20 || sx > W + 20) return;
          ctx.fillStyle = p.correct ? BUTTONS[p.button].color : "#ef4444";
          ctx.shadowColor = ctx.fillStyle as string;
          ctx.shadowBlur = 12;
          ctx.beginPath();
          ctx.arc(sx, p.y, 5, 0, Math.PI * 2);
          ctx.fill();
        });
        ctx.shadowBlur = 0;
      }

      // surfer locked at center
      let surferY = midY;
      if (pressList.length > 0) surferY = pressList[pressList.length - 1].y;
      let slope = 0;
      if (pressList.length >= 2) {
        const a = pressList[pressList.length - 2];
        const b = pressList[pressList.length - 1];
        slope = (b.y - a.y) / Math.max(1, b.worldX - a.worldX);
      }
      drawSkater(centerX, surferY - 18, Math.atan(slope));

      if (wrongFlash) {
        ctx.fillStyle = "rgba(239,68,68,0.18)";
        ctx.fillRect(0, 0, W, H);
      }
    };

    const drawSkater = (x: number, y: number, rot: number) => {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(rot);
      ctx.strokeStyle = "#fff";
      ctx.lineWidth = 2.5;
      ctx.fillStyle = "#facc15";
      ctx.fillRect(-18, 6, 36, 4);
      ctx.fillStyle = "#fff";
      ctx.beginPath();
      ctx.arc(-12, 12, 2.5, 0, Math.PI * 2);
      ctx.arc(12, 12, 2.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(-6, 6); ctx.lineTo(-2, -8);
      ctx.moveTo(8, 6); ctx.lineTo(2, -8);
      ctx.moveTo(0, -8); ctx.lineTo(0, -22);
      ctx.moveTo(0, -18); ctx.lineTo(-10, -12);
      ctx.moveTo(0, -18); ctx.lineTo(10, -22);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(0, -28, 6, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    };

    const render = (now: number) => {
      s.lastTime = now;
      const W = canvas.width;
      const H = canvas.height;
      drawSpaceBg(W, H, now);
      if (phase === "listening") {
        drawSpikes(W, H);
      }
      // Other phases (ready/playing/intro/results) just show the deep-space background
      // — the old envelope graph is intentionally retired so "Skip to Start" lands on
      // the same calm space scene as the results screen.
      raf = requestAnimationFrame(render);
    };
    raf = requestAnimationFrame(render);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, [phase, onsets, envelope, wrongFlash]);

  useEffect(() => () => stopPlayback(), []);

  const onFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    const ab = await f.arrayBuffer();
    setPhase("loading");
    await loadClip(ab, f.name);
  };

  const introNarration =
    "Welcome to Echo Surfer. First, listen carefully to the music clip and try to remember the four sounds. " +
    "When you are ready, press Start. Each button plays a piece of the music — tap them in the same order as the clip. " +
    "Keep going as long as you like, then press Exit to see your score.";

  // Sympathetic vs positive feedback
  const resultsHeadline = score.accuracy >= 40 ? "Stellar surf! 🌌" : "Keep going, you've got this 💫";
  const resultsNarration =
    phase === "results"
      ? score.accuracy >= 40
        ? `Wonderful work. You matched ${score.correct} out of ${score.total} sounds, with an accuracy of ${score.accuracy} percent. Keep riding those waves.`
        : `That was a brave effort. You matched ${score.correct} out of ${score.total} sounds. Every attempt strengthens your rhythm — try again whenever you're ready.`
      : "";

  const expectedNext = phase === "playing" && onsets.length > 0
    ? onsets[presses.length % onsets.length].button
    : null;

  return (
    <main className="min-h-screen bg-background p-4 sm:p-6">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-4">
          <Link to="/" className="inline-flex items-center gap-2 text-foreground font-bold hover:text-highlight">
            <ArrowLeft className="w-5 h-5" /> Back
          </Link>
          <h1 className="text-2xl sm:text-3xl font-extrabold">Echo Surfer</h1>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={() => fileInputRef.current?.click()} className="rounded-2xl font-bold">
              <Upload className="w-4 h-4" /> Upload clip
            </Button>
            <SpeakButton text={introNarration} label="Help" />
          </div>
        </div>

        <div
          className="relative w-full rounded-3xl overflow-hidden border-4 border-border shadow-xl select-none"
          style={{ aspectRatio: "16 / 9", background: "#05060f" }}
        >
          <canvas ref={canvasRef} className="block w-full h-full" />

          {phase === "playing" && scaledScheme && (
            <EchoSurferGame
              scheme={scaledScheme}
              duration={60}
              trainMode={trainMode}
              cueLookahead={cueLookahead}
              paused={paused}
              onPress={handleGamePress}
              onFinish={finishGame}
            />
          )}

          {(phase === "loading" || analysing) && (
            <div className="absolute inset-0 flex items-center justify-center bg-foreground/60 text-white">
              <div className="flex items-center gap-3 text-lg font-bold">
                <Loader2 className="w-6 h-6 animate-spin" /> Preparing your clip…
              </div>
            </div>
          )}

          {phase === "intro" && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/55 text-white text-center p-6 gap-4">
              <h2 className="text-4xl sm:text-5xl font-extrabold drop-shadow-lg">Echo Surfer</h2>
              <p className="text-lg sm:text-xl font-bold max-w-md">
                Listen to the clip, then tap the four buttons to surf the cosmic wave.
              </p>
              <SpeakButton autoPlay variant="outline" className="bg-white/15 text-white border-white/40 hover:bg-white/25 hover:text-white" text={introNarration} />
              <div className="text-sm opacity-80">
                Clip: <span className="font-bold">{clipName}</span> · {onsets.length} sounds detected
              </div>
              <div className="flex flex-wrap gap-3 justify-center">
                <Button size="lg" onClick={handleListen} className="h-14 px-8 text-lg rounded-2xl bg-highlight hover:bg-highlight/90 text-white font-extrabold">
                  <Play className="w-5 h-5" /> Listen to clip
                </Button>
                <Button size="lg" variant="outline" onClick={() => fileInputRef.current?.click()} className="h-14 px-6 text-lg rounded-2xl bg-white/10 text-white border-white/40 hover:bg-white/20 hover:text-white font-bold">
                  <Upload className="w-5 h-5" /> Use my own clip
                </Button>
              </div>
            </div>
          )}

          {phase === "listening" && (
            <div className="absolute top-3 left-3 right-3 flex justify-between pointer-events-none">
              <div className="bg-white/85 text-foreground rounded-xl px-4 py-2 font-extrabold shadow">
                🎧 Listen carefully…
              </div>
              <div className="pointer-events-auto">
                <Button size="sm" onClick={() => { stopPlayback(); setPhase("ready"); }} className="rounded-2xl bg-highlight hover:bg-highlight/90 text-white font-extrabold">
                  Skip to Start
                </Button>
              </div>
            </div>
          )}

          {phase === "ready" && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/55 text-white text-center p-6 gap-4">
              <h2 className="text-3xl sm:text-4xl font-extrabold">Ready to surf?</h2>
              <p className="text-lg max-w-md">
                Use keys <kbd className="px-2 py-0.5 bg-white/20 rounded">A</kbd> <kbd className="px-2 py-0.5 bg-white/20 rounded">S</kbd> <kbd className="px-2 py-0.5 bg-white/20 rounded">D</kbd> <kbd className="px-2 py-0.5 bg-white/20 rounded">J</kbd> <kbd className="px-2 py-0.5 bg-white/20 rounded">K</kbd> to play notes A · B · C · D · E and shape the cosmic ribbon.
              </p>
              <div className="flex flex-wrap gap-3 justify-center">
                <Button size="lg" variant="outline" onClick={handleListen} className="h-14 px-6 text-lg rounded-2xl bg-white/10 text-white border-white/40 hover:bg-white/20 hover:text-white font-bold">
                  <RotateCcw className="w-5 h-5" /> Listen again
                </Button>
                <Button size="lg" onClick={handleStart} className="h-14 px-8 text-lg rounded-2xl bg-highlight hover:bg-highlight/90 text-white font-extrabold">
                  <Play className="w-5 h-5" /> Start surfing
                </Button>
              </div>
            </div>
          )}

          {phase === "playing" && (
            <>
              <div className="absolute top-3 right-3 pointer-events-auto flex items-center gap-2">
                <Button
                  size="icon"
                  variant="outline"
                  aria-label={paused ? "Resume" : "Pause"}
                  onClick={() => setPaused((p) => !p)}
                  className="rounded-full bg-black/60 backdrop-blur border-white/30 text-white hover:bg-black/80 hover:text-white"
                >
                  {paused ? <Play className="w-5 h-5" /> : <Pause className="w-5 h-5" />}
                </Button>
                <Popover open={settingsOpen} onOpenChange={(o) => { setSettingsOpen(o); if (o) setPaused(true); }}>
                  <PopoverTrigger asChild>
                    <Button size="icon" variant="outline" aria-label="Settings" className="rounded-full bg-black/60 backdrop-blur border-white/30 text-white hover:bg-black/80 hover:text-white">
                      <Settings className="w-5 h-5" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent align="end" className="w-72 space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold">Train Mode</span>
                      <Switch checked={trainMode} onCheckedChange={setTrainMode} />
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-sm font-bold"><span>Volume</span><span className="opacity-70">{musicVolume}%</span></div>
                      <Slider value={[musicVolume]} min={0} max={100} step={5} onValueChange={([v]) => setMusicVolume(v)} />
                    </div>
                    {trainMode && (
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm font-bold"><span>Cue Speed</span><span className="opacity-70">{cueLookahead.toFixed(1)}s</span></div>
                        <Slider value={[cueLookahead]} min={2} max={7} step={0.5} onValueChange={([v]) => setCueLookahead(v)} />
                      </div>
                    )}
                    <div className="space-y-1">
                      <div className="flex justify-between text-sm font-bold"><span>Note Spacing</span><span className="opacity-70">{noteSpacing.toFixed(1)}x</span></div>
                      <Slider value={[noteSpacing]} min={1} max={4} step={0.25} onValueChange={([v]) => setNoteSpacing(v)} />
                      <p className="text-xs text-muted-foreground">Same-chord gap is half the next-chord gap, both scale with this slider.</p>
                    </div>
                    <div className="flex items-center justify-between border-t pt-3">
                      <div>
                        <div className="text-sm font-bold">Save as defaults</div>
                        <div className="text-xs text-muted-foreground">Lock these values for future games.</div>
                      </div>
                      <Switch
                        checked={defaultsLocked}
                        onCheckedChange={(v) => (v ? saveDefaults() : clearDefaults())}
                      />
                    </div>
                  </PopoverContent>
                </Popover>
                <Button size="sm" onClick={finishGame} className="rounded-2xl font-extrabold bg-destructive hover:bg-destructive/90 text-destructive-foreground">
                  <X className="w-4 h-4" /> Exit
                </Button>
              </div>
              {paused && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/55 text-white pointer-events-none">
                  <div className="text-5xl font-extrabold drop-shadow-lg">Paused</div>
                </div>
              )}
              {feedback && (
                <div
                  key={feedback.id}
                  className="absolute left-1/2 top-1/3 -translate-x-1/2 pointer-events-none text-4xl sm:text-5xl font-extrabold drop-shadow-[0_0_18px_rgba(0,0,0,0.8)] animate-in fade-in zoom-in duration-300"
                  style={{ color: feedback.color }}
                >
                  {feedback.text}
                </div>
              )}
            </>
          )}

          {phase === "results" && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70 text-white text-center p-6 gap-3">
              <img
                src={musicKeyArt}
                alt="Cartoon music note"
                width={140}
                height={140}
                loading="lazy"
                className="w-28 h-28 sm:w-36 sm:h-36 rounded-2xl shadow-[0_0_40px_rgba(139,92,246,0.6)]"
              />
              <h2 className="text-4xl sm:text-5xl font-extrabold">{resultsHeadline}</h2>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-3 mt-3">
                <Stat label="Score" value={summary?.total ?? 0} />
                <Stat label="Accuracy" value={`${score.accuracy}%`} />
                <Stat label="Combo" value={summary?.combo ?? 0} />
                <Stat label="Perfect" value={summary?.perfect ?? 0} />
                <Stat label="Good" value={summary?.good ?? 0} />
                <Stat label="Miss" value={summary?.miss ?? 0} />
              </div>
              <SpeakButton autoPlay key={`${score.correct}-${score.total}`} text={resultsNarration} variant="outline" className="mt-2 bg-white/15 text-white border-white/40 hover:bg-white/25 hover:text-white" />
              <div className="flex gap-3 mt-3">
                <Button size="lg" variant="outline" onClick={() => setPhase("intro")} className="h-12 px-6 rounded-2xl bg-white/10 text-white border-white/40 hover:bg-white/20 hover:text-white font-bold">
                  Hear again
                </Button>
                <Button size="lg" onClick={handleStart} className="h-12 px-8 rounded-2xl bg-highlight hover:bg-highlight/90 text-white font-extrabold">
                  Play again
                </Button>
              </div>
            </div>
          )}
        </div>

        <input ref={fileInputRef} type="file" accept="audio/*" onChange={onFile} className="hidden" />

        <p className="text-center text-muted-foreground mt-4 text-sm">
          During gameplay press <kbd className="px-2 py-0.5 bg-secondary rounded">A</kbd> <kbd className="px-2 py-0.5 bg-secondary rounded">S</kbd> <kbd className="px-2 py-0.5 bg-secondary rounded">D</kbd> <kbd className="px-2 py-0.5 bg-secondary rounded">J</kbd> <kbd className="px-2 py-0.5 bg-secondary rounded">K</kbd> for notes A · B · C · D · E
        </p>
      </div>
    </main>
  );
};

const Stat = ({ label, value }: { label: string; value: number | string }) => (
  <div className="bg-white/15 rounded-2xl px-4 py-3 min-w-24">
    <div className="text-3xl font-extrabold">{value}</div>
    <div className="text-sm font-bold opacity-90">{label}</div>
  </div>
);

function audioBufferToWav(buffer: AudioBuffer): ArrayBuffer {
  const numCh = buffer.numberOfChannels;
  const sr = buffer.sampleRate;
  const len = buffer.length * numCh * 2 + 44;
  const out = new ArrayBuffer(len);
  const view = new DataView(out);
  let p = 0;
  const writeStr = (s: string) => { for (let i = 0; i < s.length; i++) view.setUint8(p++, s.charCodeAt(i)); };
  writeStr("RIFF"); view.setUint32(p, len - 8, true); p += 4;
  writeStr("WAVE"); writeStr("fmt ");
  view.setUint32(p, 16, true); p += 4;
  view.setUint16(p, 1, true); p += 2;
  view.setUint16(p, numCh, true); p += 2;
  view.setUint32(p, sr, true); p += 4;
  view.setUint32(p, sr * numCh * 2, true); p += 4;
  view.setUint16(p, numCh * 2, true); p += 2;
  view.setUint16(p, 16, true); p += 2;
  writeStr("data");
  view.setUint32(p, buffer.length * numCh * 2, true); p += 4;
  for (let i = 0; i < buffer.length; i++) {
    for (let c = 0; c < numCh; c++) {
      const s = Math.max(-1, Math.min(1, buffer.getChannelData(c)[i]));
      view.setInt16(p, s < 0 ? s * 0x8000 : s * 0x7fff, true);
      p += 2;
    }
  }
  return out;
}

export default EchoSurfer;
