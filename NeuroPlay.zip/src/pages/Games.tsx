import { Link } from "react-router-dom";
import { Brain, Grid3x3, Ear, ListChecks, Puzzle } from "lucide-react";
import { TopBar } from "@/components/TopBar";
import { Button } from "@/components/ui/button";

type GameDef = {
  id: string;
  title: string;
  description: string;
  category: string;
  route: string;
  icon: React.ComponentType<{ className?: string }>;
  iconBg: string;
  difficulty?: "Easy" | "Medium" | "Hard";
};

const GAMES: GameDef[] = [
  { id: "memory-recall", title: "Memory Recall", description: "Remember images and find them in a grid", category: "Memory", route: "/games/memory-recall", icon: Brain, iconBg: "bg-[hsl(var(--game-purple)/0.15)]", difficulty: "Medium" },
  { id: "memory-match", title: "Memory Match", description: "Match pairs from a shuffled grid", category: "Memory", route: "/games/memory-match", icon: Puzzle, iconBg: "bg-[hsl(var(--game-coral)/0.15)]", difficulty: "Easy" },
  { id: "spatial-grid", title: "Spatial Grid", description: "Reproduce the lit cell pattern", category: "Memory", route: "/games/spatial-grid", icon: Grid3x3, iconBg: "bg-[hsl(var(--game-coral)/0.15)]", difficulty: "Hard" },
  { id: "echo-surfer", title: "Echo Surfer", description: "Follow the sound patterns", category: "Cognition", route: "/games/echo-surfer", icon: Ear, iconBg: "bg-[hsl(var(--game-blue)/0.15)]", difficulty: "Easy" },
  { id: "task-arranger", title: "Task Arranger", description: "Arrange daily tasks in order", category: "Memory", route: "/games/task-arranger", icon: ListChecks, iconBg: "bg-[hsl(var(--game-green)/0.15)]", difficulty: "Medium" },
];

const Games = () => {
  return (
    <main className="min-h-screen bg-background">
      <TopBar initials="MA" />
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
        <header className="mb-6">
          <h1 className="text-[24px] font-medium leading-tight">Therapy games</h1>
          <p className="text-[13px] text-muted-foreground mt-1">{GAMES.length} games available</p>
        </header>

        <section className="bg-card border border-border rounded-md overflow-hidden">
          {GAMES.map((g) => {
            const Icon = g.icon;
            return (
              <div
                key={g.id}
                className="flex items-center gap-3 px-3 h-14 border-b border-border last:border-b-0 hover:bg-secondary/40 transition-colors"
              >
                <div className={`w-8 h-8 rounded-sm grid place-items-center shrink-0 ${g.iconBg}`}>
                  <Icon className="w-4 h-4 text-foreground" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-[13px] font-medium leading-tight truncate">{g.title}</div>
                  <div className="text-[11px] text-muted-foreground leading-tight truncate">{g.category} · {g.description}</div>
                </div>
                {g.difficulty && (
                  <span className="text-[11px] px-2 py-[2px] rounded-sm border border-border text-muted-foreground hidden sm:inline-block">
                    {g.difficulty}
                  </span>
                )}
                <Button asChild size="sm" className="h-8 px-3 text-[12px]">
                  <Link to={g.route}>Play</Link>
                </Button>
              </div>
            );
          })}
        </section>
      </div>
    </main>
  );
};

export default Games;