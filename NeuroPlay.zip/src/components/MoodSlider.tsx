import { useState } from "react";
import { Slider } from "@/components/ui/slider";
import { saveMoodLog } from "@/lib/sessionTracker";

const labels = ["Very low", "Low", "Okay", "Good", "Great"];

export const MoodSlider = () => {
  const [value, setValue] = useState([2]);
  const current = labels[value[0]];

  const commit = (v: number[]) => {
    const idx = v[0];
    void saveMoodLog(idx + 1, labels[idx]);
  };

  return (
    <div className="bg-card border border-border rounded-md p-5">
      <div className="flex items-center justify-between mb-4 gap-4 flex-wrap">
        <h2 className="text-[15px] font-medium">How are you feeling today?</h2>
        <span className="text-[13px] text-muted-foreground">
          {value[0] + 1}/5 · {current}
        </span>
      </div>
      <Slider
        value={value}
        onValueChange={setValue}
        onValueCommit={commit}
        min={0}
        max={labels.length - 1}
        step={1}
        aria-label="Mood"
      />
      <div className="flex justify-between mt-3 px-1 text-[11px] text-muted-foreground uppercase tracking-wide">
        {labels.map((l, i) => (
          <button
            key={l}
            onClick={() => { setValue([i]); commit([i]); }}
            className={i === value[0] ? "text-foreground" : "hover:text-foreground"}
          >
            {i + 1}
          </button>
        ))}
      </div>
    </div>
  );
};
