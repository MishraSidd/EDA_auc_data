import { Link, useLocation } from "react-router-dom";
import { Mic } from "lucide-react";
import { UserMenu } from "@/components/UserMenu";

const links = [
  { to: "/", label: "Dashboard" },
  { to: "/games", label: "Games", match: "/games" },
  { to: "/speech", label: "Speech", match: "/speech", icon: Mic },
  { to: "/caregiver", label: "Caregiver" },
];

export const TopBar = (_props: { initials?: string } = {}) => {
  const { pathname } = useLocation();
  const isActive = (l: { to: string; match?: string }) =>
    l.match ? pathname.startsWith(l.match) : pathname === l.to;

  return (
    <header className="h-11 bg-card border-b border-border flex items-center px-4 sm:px-6 sticky top-0 z-30">
      <Link to="/" className="flex items-center gap-2 mr-8">
        <span className="w-5 h-5 bg-primary" aria-hidden />
        <span className="text-[15px] font-medium tracking-tight">NeuroPlay</span>
      </Link>
      <nav className="flex items-center gap-5 flex-1">
        {links.map((l) => {
          const active = isActive(l);
          const Icon = (l as { icon?: typeof Mic }).icon;
          return (
            <Link
              key={l.label}
              to={l.to}
              className={`text-[13px] pb-[2px] border-b-2 transition-colors inline-flex items-center gap-1.5 ${
                active
                  ? "text-foreground border-primary"
                  : "text-muted-foreground border-transparent hover:text-foreground"
              }`}
            >
              {Icon && <Icon className="w-3.5 h-3.5" aria-hidden />}
              {l.label}
            </Link>
          );
        })}
      </nav>
      <UserMenu />
    </header>
  );
};
