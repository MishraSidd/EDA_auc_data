import { ChevronRight, LucideIcon } from "lucide-react";
import { Link } from "react-router-dom";

type Difficulty = "Easy" | "Medium" | "Hard";

interface GameRowProps {
  title: string;
  category: string;
  icon: LucideIcon;
  dotClass: string;
  difficulty: Difficulty;
  score: number | null;
  to?: string;
}

const diffStyle: Record<Difficulty, string> = {
  Easy: "border-border text-muted-foreground",
  Medium: "border-border text-foreground",
  Hard: "border-border text-foreground",
};

export const GameRow = ({
  title,
  category,
  icon: Icon,
  dotClass,
  difficulty,
  score,
  to,
}: GameRowProps) => {
  const Wrapper: any = to ? Link : "div";
  const wrapperProps = to ? { to } : {};

  return (
    <Wrapper
      {...wrapperProps}
      className="flex items-center gap-3 px-3 h-[52px] border-b border-border last:border-b-0 hover:bg-secondary/40 transition-colors"
    >
      <div
        className={`w-8 h-8 rounded-sm grid place-items-center shrink-0 ${dotClass}`}
      >
        <Icon className="w-4 h-4 text-foreground" strokeWidth={1.75} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-[13px] font-medium leading-tight truncate">{title}</div>
        <div className="text-[11px] text-muted-foreground leading-tight">{category}</div>
      </div>
      <span
        className={`text-[11px] px-2 py-[2px] rounded-sm border ${diffStyle[difficulty]} hidden sm:inline-block`}
      >
        {difficulty}
      </span>
      <div className="w-24 shrink-0">
        <div className="flex items-center justify-between text-[11px] mb-1">
          <span className="text-muted-foreground">Score</span>
          <span className="font-medium">{score == null ? "—" : `${score}%`}</span>
        </div>
        <div className="h-[3px] w-full bg-secondary rounded-sm overflow-hidden">
          <div
            className="h-full bg-primary"
            style={{ width: `${score ?? 0}%` }}
          />
        </div>
      </div>
      <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
    </Wrapper>
  );
};
