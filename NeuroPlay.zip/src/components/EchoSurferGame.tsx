import { useEffect, useRef } from "react";
import Phaser from "phaser";
import { EchoSurferScene } from "@/game/EchoSurferScene";
import type { Scheme, PressEvent } from "@/lib/scoring";

interface Props {
  scheme: Scheme;
  duration: number; // seconds of gameplay
  onPress: (e: PressEvent) => void;
  onFinish: () => void;
  onLiveScore?: (events: PressEvent[]) => void;
  trainMode?: boolean;
  cueLookahead?: number;
  paused?: boolean;
}

export function EchoSurferGame({ scheme, duration, onPress, onFinish, onLiveScore, trainMode = true, cueLookahead = 4, paused = false }: Props) {
  const hostRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Phaser.Game | null>(null);
  const pressEventsRef = useRef<PressEvent[]>([]);

  useEffect(() => {
    if (!hostRef.current) return;
    const host = hostRef.current;
    const game = new Phaser.Game({
      type: Phaser.AUTO,
      parent: host,
      backgroundColor: "#05060f",
      scale: {
        mode: Phaser.Scale.RESIZE,
        width: host.clientWidth,
        height: host.clientHeight,
      },
      scene: [EchoSurferScene],
      banner: false,
      audio: { noAudio: true },
    });
    gameRef.current = game;
    const handlePress = (event: PressEvent) => {
      pressEventsRef.current.push(event);
      onPress(event);
      onLiveScore?.(pressEventsRef.current);
    };
    game.scene.start("EchoSurferScene", { scheme, duration, onPress: handlePress, onFinish, trainMode, cueLookahead });
    return () => {
      game.destroy(true);
      gameRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Live-update train mode without restarting
  useEffect(() => {
    const g = gameRef.current;
    if (!g) return;
    const scene = g.scene.getScene("EchoSurferScene") as EchoSurferScene | undefined;
    if (scene && (scene as any).setTrainMode) (scene as any).setTrainMode(trainMode);
  }, [trainMode]);

  useEffect(() => {
    const g = gameRef.current;
    if (!g) return;
    const scene = g.scene.getScene("EchoSurferScene") as EchoSurferScene | undefined;
    if (scene && (scene as any).setCueLookahead) (scene as any).setCueLookahead(cueLookahead);
  }, [cueLookahead]);

  // Pause/resume the Phaser scene live
  useEffect(() => {
    const g = gameRef.current;
    if (!g) return;
    const scene = g.scene.getScene("EchoSurferScene") as EchoSurferScene | undefined;
    if (!scene) return;
    if (paused) (scene as any).pauseGame?.();
    else (scene as any).resumeGame?.();
  }, [paused]);

  return <div ref={hostRef} className="absolute inset-0" />;
}
