import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface TaskItemProps {
  title: string;
  time: string;
  completed?: boolean;
  onToggle?: () => void;
}

export const TaskItem = ({ title, time, completed, onToggle }: TaskItemProps) => {
  return (
    <div className="flex items-center gap-3 py-3 border-b border-border last:border-b-0">
      <button
        onClick={onToggle}
        aria-label={completed ? "Mark task incomplete" : "Mark task complete"}
        className={cn(
          "w-5 h-5 rounded-sm border shrink-0 flex items-center justify-center transition-colors",
          completed
            ? "bg-primary border-primary text-primary-foreground"
            : "bg-card border-border hover:border-foreground",
        )}
      >
        {completed && <Check className="w-3.5 h-3.5" strokeWidth={2.5} />}
      </button>
      <div className="flex-1 min-w-0 flex items-baseline justify-between gap-2">
        <p
          className={cn(
            "text-[14px] leading-tight",
            completed && "line-through text-muted-foreground",
          )}
        >
          {title}
        </p>
        <p className="text-[12px] text-muted-foreground shrink-0">{time}</p>
      </div>
    </div>
  );
};
