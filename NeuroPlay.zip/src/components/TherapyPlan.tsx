import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  Brain,
  Mic,
  Grid3x3,
  Ear,
  HandMetal,
  Clock,
  type LucideIcon,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { getUserId } from "@/features/assessment/useAdaptiveProfile";

type Priority = "high" | "medium" | "low";

interface PlanItem {
  gameId: string;
  gameTitle: string;
  route: string;
  reason: string;
  priority: Priority;
  difficulty: string;
  icon: LucideIcon;
  domain: string;
}

interface ProfileShape {
  questionnaire: Record<string, string | string[]>;
  difficulty: string;
  sessionLengthMin: number;
}

const PRIO_BG: Record<Priority, string> = {
  high: "bg-[#E1F5EE] text-[#0F6E56]",
  medium: "bg-[#FAEEDA] text-[#8A5A12]",
  low: "bg-[#EFEEEA] text-[#5f5e5a]",
};
const PRIO_DOT: Record<Priority, string> = {
  high: "bg-[#1D9E75]",
  medium: "bg-[#EF9F27]",
  low: "bg-[#9b9a96]",
};

function asArray(v: string | string[] | undefined): string[] {
  if (!v) return [];
  return Array.isArray(v) ? v : [v];
}

function difficultyFromTargetSize(t?: string): string {
  if (t === "lg") return "Easy";
  if (t === "sm") return "Hard";
  return "Medium";
}

function buildPlan(p: ProfileShape): PlanItem[] {
  const q = p.questionnaire || {};
  const condition = String(q.condition || "");
  const memory = asArray(q.memory);
  const comms = asArray(q.comms);
  const daily = asArray(q.daily);
  const fatigue = String(q.fatigue || "");
  const diff = p.difficulty;

  const hasMemoryIssue = memory.some((m) => m !== "No major issue");
  const hasFocusIssue = memory.includes("Trouble focusing");
  const hasSpeechIssue = comms.some((m) => m !== "No major issue");
  const hasMotor =
    daily.includes("Holding objects") ||
    daily.includes("Walking") ||
    daily.includes("Eating") ||
    daily.includes("Dressing");
  const isStroke = /stroke/i.test(condition);
  const isTBI = /TBI|Brain Injury/i.test(condition);
  const isHighFatigue = fatigue === "Frequently" || fatigue === "Constantly";

  const plan: PlanItem[] = [];

  if (hasMemoryIssue || isStroke) {
    plan.push({
      gameId: "memory-recall",
      gameTitle: "Memory Recall",
      route: "/games/memory-recall",
      reason: hasMemoryIssue
        ? "Directly targets your memory difficulties — start here daily"
        : "Memory training is a core part of stroke recovery",
      priority: hasMemoryIssue ? "high" : "medium",
      difficulty: diff,
      icon: Brain,
      domain: "Memory",
    });
  }

  if (hasSpeechIssue) {
    plan.push({
      gameId: "speech",
      gameTitle: "Speech Practice",
      route: "/speech",
      reason:
        "Communication is one of your affected areas — 5 words a day builds steady improvement",
      priority: "high",
      difficulty: diff,
      icon: Mic,
      domain: "Speech",
    });
  }

  if (hasFocusIssue || hasMotor) {
    plan.push({
      gameId: "spatial-grid",
      gameTitle: "Spatial Grid",
      route: "/games/spatial-grid",
      reason: hasFocusIssue
        ? "Spatial tasks directly build concentration and focus"
        : "Helps rebuild fine motor coordination and spatial awareness",
      priority: hasFocusIssue ? "high" : "medium",
      difficulty: isHighFatigue ? "Easy" : diff,
      icon: Grid3x3,
      domain: "Focus",
    });
  }

  plan.push({
    gameId: "echo-surfer",
    gameTitle: "Echo Surfer",
    route: "/games/echo-surfer",
    reason: isTBI
      ? "Auditory processing games are particularly helpful after TBI"
      : "Auditory training complements your other therapy activities",
    priority: isTBI ? "medium" : "low",
    difficulty: diff,
    icon: Ear,
    domain: "Cognition",
  });

  if (hasMotor) {
    plan.push({
      gameId: "tremor-check",
      gameTitle: "Tremor Check",
      route: "/tremor-check",
      reason:
        "Regular tremor tracking helps your care team understand your motor recovery",
      priority: "medium",
      difficulty: "Weekly",
      icon: HandMetal,
      domain: "Motor",
    });
  }

  const order: Record<Priority, number> = { high: 0, medium: 1, low: 2 };
  return plan.sort((a, b) => order[a.priority] - order[b.priority]);
}

function getSessionLength(p: ProfileShape): string {
  const fatigue = String(p.questionnaire?.fatigue || "");
  if (fatigue === "Constantly" || fatigue === "Frequently") {
    return "10–15 minutes per day recommended — short sessions work best right now";
  }
  if (fatigue === "Sometimes") return "15–20 minutes per day recommended";
  return "20–25 minutes per day — you are ready for longer sessions";
}

export default function TherapyPlan() {
  const [profile, setProfile] = useState<ProfileShape | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const userId = getUserId();
      const { data } = await supabase
        .from("assessments")
        .select("questionnaire, adaptive_profile, created_at")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })
        .limit(20);
      const rows = data ?? [];
      const withQ = rows.find(
        (r: any) =>
          r.questionnaire && Object.keys(r.questionnaire).length > 0,
      ) as any;
      if (withQ) {
        const ap = (withQ.adaptive_profile ?? {}) as any;
        setProfile({
          questionnaire: withQ.questionnaire,
          difficulty: difficultyFromTargetSize(ap.targetSize),
          sessionLengthMin: Number(ap.sessionLengthMin) || 15,
        });
      }
      setLoading(false);
    })();
  }, []);

  if (loading) {
    return (
      <section className="bg-card border border-border rounded-md p-4 mb-6">
        <div className="h-4 w-32 bg-secondary rounded animate-pulse mb-3" />
        <div className="h-12 w-full bg-secondary rounded animate-pulse" />
      </section>
    );
  }

  if (!profile || !profile.questionnaire || Object.keys(profile.questionnaire).length === 0) {
    return (
      <section className="bg-card border border-border rounded-md p-4 mb-6 flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h2 className="text-[13px] font-medium">Your therapy plan</h2>
          <p className="text-[12px] text-muted-foreground mt-1">
            Complete your health intake to see a personalised plan.
          </p>
        </div>
        <Link
          to="/onboarding"
          className="text-[13px] border border-[#1D9E75] text-[#0F6E56] bg-[#E1F5EE] hover:bg-[#9FE1CB] rounded-md px-3 py-1.5"
        >
          Complete intake
        </Link>
      </section>
    );
  }

  const plan = buildPlan(profile);
  const sessionLine = getSessionLength(profile);

  return (
    <section className="bg-card border border-border rounded-md p-4 mb-6">
      <header className="flex items-center justify-between gap-2 mb-3">
        <h2 className="text-[13px] font-medium">Your therapy plan</h2>
        <span className="text-[11px] text-muted-foreground">
          Based on your intake answers
        </span>
      </header>

      <div
        className="flex items-center gap-2 rounded-md px-3 py-2 mb-3 text-[12px]"
        style={{ background: "#E6F1FB", color: "#0C447C" }}
      >
        <Clock className="w-3.5 h-3.5 shrink-0" />
        <span>{sessionLine}</span>
      </div>

      <div className="flex items-center gap-4 text-[11px] text-muted-foreground mb-3">
        <span className="inline-flex items-center gap-1.5">
          <span className={`w-2 h-2 rounded-full ${PRIO_DOT.high}`} />
          Recommended for you
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className={`w-2 h-2 rounded-full ${PRIO_DOT.medium}`} />
          Supportive
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className={`w-2 h-2 rounded-full ${PRIO_DOT.low}`} />
          Complementary
        </span>
      </div>

      <ul className="border border-border rounded-md overflow-hidden">
        {plan.map((item) => {
          const Icon = item.icon;
          return (
            <li
              key={item.gameId}
              className="flex items-center gap-3 px-3 h-[52px] border-b border-border last:border-b-0 hover:bg-secondary/40 transition-colors"
            >
              <div
                className={`w-7 h-7 rounded-md grid place-items-center shrink-0 ${PRIO_BG[item.priority]}`}
              >
                <Icon className="w-4 h-4" strokeWidth={1.75} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-[13px] font-medium leading-tight truncate">
                  {item.gameTitle}
                </div>
                <div className="text-[11px] text-muted-foreground leading-tight truncate">
                  {item.reason}
                </div>
              </div>
              {item.difficulty && (
                <span className="text-[11px] px-2 py-[2px] rounded-sm border border-border text-muted-foreground hidden sm:inline-block">
                  {item.difficulty}
                </span>
              )}
              <Link
                to={item.route}
                className="text-[12px] text-[#0F6E56] hover:underline shrink-0"
              >
                Start →
              </Link>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
