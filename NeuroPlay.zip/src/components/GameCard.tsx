import { Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { LucideIcon } from "lucide-react";
import { Link } from "react-router-dom";

type GameColor = "coral" | "green" | "blue" | "purple";

interface GameCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  color: GameColor;
  to?: string;
}

const colorMap: Record<GameColor, string> = {
  coral: "bg-game-coral",
  green: "bg-game-green",
  blue: "bg-game-blue",
  purple: "bg-game-purple",
};

export const GameCard = ({ title, description, icon: Icon, color, to }: GameCardProps) => {
  const Wrapper: any = to ? Link : "div";
  const wrapperProps = to ? { to } : {};
  return (
    <Wrapper
      {...wrapperProps}
      className={`${colorMap[color]} text-game-foreground rounded-3xl p-6 flex flex-col gap-4 shadow-md transition-transform hover:-translate-y-1 hover:shadow-xl ${to ? "cursor-pointer" : ""}`}
    >
      <div className="flex items-start gap-3">
        <div className="bg-white/25 rounded-xl p-2 shrink-0">
          <Icon className="w-6 h-6" strokeWidth={2.25} />
        </div>
        <h3 className="text-2xl font-extrabold leading-tight">{title}</h3>
      </div>
      <p className="text-base leading-snug text-game-foreground/95">{description}</p>
      <Button
        variant="secondary"
        className="mt-auto bg-white hover:bg-white/90 text-foreground rounded-2xl h-12 text-base font-bold gap-2"
      >
        <Play className="w-5 h-5 fill-current" /> Play Now
      </Button>
    </Wrapper>
  );
};