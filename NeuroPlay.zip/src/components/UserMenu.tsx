import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { User as UserIcon, Activity, LogOut } from "lucide-react";
import { getUserId } from "@/features/assessment/useAdaptiveProfile";

export function UserMenu() {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const userId = getUserId();
  const userName = `Patient ${userId.replace(/^u_/, "").slice(0, 4).toUpperCase()}`;
  const initials = userName.split(" ").map((w) => w[0]).join("").toUpperCase().slice(0, 2);

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  function handleSignOut() {
    localStorage.removeItem("np_session_id");
    localStorage.removeItem("np_onboarded");
    setOpen(false);
    navigate("/onboarding");
  }

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-label="User menu"
        aria-haspopup="menu"
        aria-expanded={open}
        className="w-[34px] h-[34px] rounded-full grid place-items-center text-[12px] font-medium"
        style={{ background: "#E1F5EE", border: "0.5px solid #1D9E75", color: "#0F6E56" }}
      >
        {initials}
      </button>

      {open && (
        <div
          role="menu"
          className="absolute right-0 top-[calc(100%+8px)] w-[230px] rounded-lg overflow-hidden z-50"
          style={{
            background: "#ffffff",
            border: "1px solid rgba(0,0,0,0.08)",
            boxShadow: "0 8px 24px rgba(0,0,0,0.08)",
          }}
        >
          <div className="px-[14px] py-[12px]" style={{ borderBottom: "1px solid rgba(0,0,0,0.06)" }}>
            <div className="text-[13px] font-medium text-[#1a1a18] truncate">{userName}</div>
            <div className="text-[11px] text-[#9a9890]">Patient account</div>
          </div>

          <MenuItem icon={<UserIcon className="w-3.5 h-3.5" />} onClick={() => { setOpen(false); navigate("/profile"); }}>
            My profile
          </MenuItem>
          <MenuItem icon={<Activity className="w-3.5 h-3.5" />} onClick={() => { setOpen(false); navigate("/assessment/tremor"); }}>
            Tremor check
          </MenuItem>

          <div style={{ borderTop: "1px solid rgba(0,0,0,0.06)" }}>
            <button
              role="menuitem"
              onClick={handleSignOut}
              className="w-full flex items-center gap-[9px] px-[14px] py-[10px] text-[13px] text-[#A32D2D] transition-colors"
              onMouseEnter={(e) => (e.currentTarget.style.background = "#FCEBEB")}
              onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
            >
              <LogOut className="w-3.5 h-3.5" />
              Sign out
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function MenuItem({
  icon, children, onClick,
}: { icon: React.ReactNode; children: React.ReactNode; onClick: () => void }) {
  return (
    <button
      role="menuitem"
      onClick={onClick}
      className="w-full flex items-center gap-[9px] px-[14px] py-[10px] text-[13px] text-[#1a1a18] transition-colors"
      onMouseEnter={(e) => (e.currentTarget.style.background = "#f7f6f2")}
      onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
    >
      {icon}
      {children}
    </button>
  );
}