import { Volume2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSpeech } from "@/hooks/useSpeech";
import { useEffect, useRef } from "react";

interface SpeakButtonProps {
  text: string;
  autoPlay?: boolean;
  label?: string;
  className?: string;
  variant?: "default" | "secondary" | "ghost" | "outline";
  size?: "sm" | "default" | "lg" | "icon";
}

export const SpeakButton = ({
  text,
  autoPlay = false,
  label = "Listen",
  className,
  variant = "outline",
  size = "sm",
}: SpeakButtonProps) => {
  const { speak, cancel, speaking, supported } = useSpeech();
  const playedRef = useRef<string | null>(null);

  useEffect(() => {
    if (!autoPlay || !supported) return;
    if (playedRef.current === text) return;
    playedRef.current = text;
    const t = setTimeout(() => speak(text), 350);
    return () => clearTimeout(t);
  }, [autoPlay, text, supported, speak]);

  if (!supported) return null;

  return (
    <Button
      type="button"
      variant={variant}
      size={size}
      onClick={(e) => {
        e.stopPropagation();
        if (speaking) cancel();
        else speak(text);
      }}
      aria-label={speaking ? "Stop reading instructions" : "Read instructions aloud"}
      className={`gap-2 rounded-md font-medium ${className ?? ""}`}
    >
      {speaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
      {speaking ? "Stop" : label}
    </Button>
  );
};
