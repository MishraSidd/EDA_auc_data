## Goal
Extend NeuroPlay with a professional adult-focused onboarding + adaptive assessment system, a tremor (∞-draw) assessment, and a caregiver analytics view — without breaking existing routes, games, or the recently shipped clinical UI.

## Scope (modular extensions only)

Existing preserved as-is: `/`, `/v2`, `/games/*` (Echo Surfer, Memory Match, Memory Recall, Spatial Grid, Speech Recovery, Task Arranger), `/report`, `/speech/*`, current TopBar, design tokens, Supabase tables, edge functions.

### New routes (added to `src/App.tsx`)
- `/onboarding` → 7-step questionnaire
- `/assessment/tremor` → infinity-draw tremor capture
- `/caregiver` → caregiver analytics dashboard (re-uses report data + new metrics)

The Home Dashboard gets a single non-destructive "Start assessment" entry card that links to `/onboarding` if the user hasn't completed it yet (flag stored locally + in DB). No layouts removed.

### New files
- `src/features/onboarding/OnboardingFlow.tsx` — stepper, chip selection, progress bar
- `src/features/onboarding/questions.ts` — 7 questions (exact copy from spec)
- `src/features/assessment/scoringEngine.ts` — pure functions computing the 6 internal metrics + adaptive difficulty profile
- `src/features/assessment/TremorDraw.tsx` — canvas + pointer/touch capture, optional DeviceMotion listener, returns smoothness/deviation/velocity stats
- `src/features/assessment/tremorAnalysis.ts` — pure math (path smoothness, direction deviation, velocity variation)
- `src/features/caregiver/CaregiverDashboard.tsx` — reuses `weekly_reports`, `game_sessions`, plus new `assessments` table; Recharts line charts already in project
- `src/pages/Onboarding.tsx`, `src/pages/TremorAssessment.tsx`, `src/pages/Caregiver.tsx` — thin route wrappers
- `src/features/assessment/useAdaptiveProfile.ts` — hook that reads latest assessment row + exposes `{ previewMs, distractorCount, targetSize, sessionLengthHint }`

### Memory Recall changes (minimal, additive)
`src/games/MemoryRecallGame.tsx` already implements the requested 3 images / 3s preview / 2s pause / 20-image grid loop. Wire it to `useAdaptiveProfile()`:
- preview duration = profile.previewMs (default 3000)
- distractor count derived from profile.distractorCount (default 17)
- target tile size scales with profile.targetSize
No childish styling exists already — keep current clinical look, just remove the leftover `font-bold` / `rounded-2xl` overrides on the Ready/Done screens to match the new tokens.

### Backend (one migration)
New table `assessments`:
- id uuid pk, user_id text, created_at timestamptz default now()
- questionnaire jsonb (raw answers)
- motor_stability int, cognitive_focus int, communication_confidence int, fatigue_sensitivity int, memory_index int, adaptation_level int
- tremor_smoothness numeric, tremor_deviation numeric, tremor_velocity_var numeric
- adaptive_profile jsonb

RLS: public read + public insert with `user_id IS NOT NULL` (matches existing pattern in `daily_tasks`, `game_sessions`, `mood_logs`).

No edits to existing tables. No edge functions added — scoring is pure client logic per the prior request pattern.

### Scoring engine (pure logic, no AI)
Weighted formulas (all 0–100, rounded):
```text
motor_stability        = base(side, daily) - tremor_penalty
cognitive_focus        = base(memory, comms) + game_session_avg_accuracy*0.3
communication_confid.  = base(comms) + speech_attempts_avg*0.4
fatigue_sensitivity    = map(fatigue_freq) -> 25/50/75/100  (higher = more sensitive)
memory_index           = recall_game_accuracy_avg
adaptation_level       = clamp((cognitive+motor+memory)/3 - fatigue*0.2, 0, 100)
```
Adaptive profile derived from these (preview ms, distractor count, target size, session length).

### Design system
Reuse existing clinical tokens (`--background #f7f6f2`, primary teal `#0F6E56`, Inter 500 headings, 1px borders, 6px radius). The user asks for "dark elegant UI / sage / muted teal / charcoal / warm gray" — current palette is light-clinical. Interpretation: keep the established palette (already approved last turn) and lean into muted-teal/charcoal accents within it; do NOT swap the global theme to dark, since that would overwrite teammate work and the just-approved redesign. New screens use the same tokens, large 56px touch targets, generous spacing (`py-8`, `gap-6`), `text-[15px]` body, `text-[24px]/500` headings.

### Verification
- Build passes
- `/`, `/v2`, `/report`, every `/games/*` route still render unchanged
- `/onboarding` completes 7 steps → POSTs to `assessments` → redirects to `/` with a "Personalized" badge
- `/assessment/tremor` captures ≥200 points and stores result
- `/caregiver` renders charts from existing tables + new metrics

## Out of scope
- No medical diagnosis text anywhere; all metrics labeled as "rehabilitation indicators"
- No changes to existing games' core scoring
- No new edge functions
- No auth changes
